"""Read-only reuse of construction replies already paid for (no network, $0).

`PaidReplayCache` serves an exact request again only if the shared guarded
session holds a *completed* workload construction dispatch with the identical
request key (the key covers model, messages, temperature and max_tokens). It
never writes to the session and never touches billing. `CacheChain` tries the
frozen reproduction cache first, then the replay, and keeps per-layer counts.

Because v2 leaves every attack, seed, linked copy, principal control and probe
question byte-identical to v1, their v1 Stage-1 replies are reused unchanged.
"""

from __future__ import annotations

import json
import sqlite3
from collections import Counter
from pathlib import Path

from ams.research.dynamic.models import check
from ams.research.recovery.offline import OfflineMiss


class PaidReplayCache:
    def __init__(self, dispatch_db: Path):
        check(Path(dispatch_db).is_file(), f"Missing dispatch ledger {dispatch_db}")
        conn = sqlite3.connect(f"file:{Path(dispatch_db).resolve()}?mode=ro", uri=True)
        conn.execute("PRAGMA query_only=ON")
        self.replies, self.counts = {}, Counter()
        for key, result in conn.execute(
            "SELECT request_key,result FROM dispatches "
            "WHERE stage LIKE 'workload_%' AND status='completed' AND result_hash IS NOT NULL"
        ):
            response = json.loads(result)["response"]
            check(response is not None, "Completed dispatch without a response")
            previous = self.replies.setdefault(key, response)
            check(previous["text"] == response["text"], "Conflicting replies for one request")
        conn.close()

    def get(self, key: str, kind: str, provider: str, model: str):
        if kind == "chat" and provider == "openrouter" and key in self.replies:
            response = self.replies[key]
            check(response.get("model") == model, "Replayed reply model mismatch")
            self.counts["paid_replay_hit"] += 1
            return {**response, "provider": provider}, {"source": "paid_replay"}
        raise OfflineMiss("No paid replay")


class CacheChain:
    def __init__(self, *layers):
        self.layers = [layer for layer in layers if layer is not None]
        self.counts = Counter()

    def get(self, key: str, kind: str, provider: str, model: str):
        for i, layer in enumerate(self.layers):
            try:
                found = layer.get(key, kind, provider, model)
            except OfflineMiss:
                continue
            self.counts[f"layer{i}_{kind}_hit"] += 1
            return found
        self.counts[f"{kind}_miss"] += 1
        raise OfflineMiss(f"No cached {kind} response")
