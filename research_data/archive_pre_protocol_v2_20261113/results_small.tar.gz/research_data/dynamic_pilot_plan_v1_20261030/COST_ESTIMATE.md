# Conditional API-cost estimate

Planning only. No paid calls are made.

Prices: USD 0.15/M input and 0.60/M output, checked 2026-10-30. [Official model page](https://openrouter.ai/openai/gpt-4o-mini/overview).

Input lengths and conflict frequency are assumptions, not measured token usage. Outputs use frozen completion ceilings. Provider-cache discounts are not assumed.

| Scope | Working range incl. 20% retry allowance | Stress: two attempts + 25% headroom |
| --- | ---: | ---: |
| development | $5.323911–$5.925531 | $42.489840 |
| locked_primary | $7.985866–$8.888297 | $63.734760 |
| all_selected | $13.309776–$14.813828 | $106.224600 |

Proposed combined stop cap: **$125.00**. It is not activated and is not a promise that every worst-case request will fit.

The stress case uses six conflict calls per k=4 retrieval. The full 128,000-token context reservation for every possible attempt is a separate, much larger bound, listed in the JSON. A future run must stop at the cap rather than assume completion.

Exact cohort IDs, token lengths, cache hits and human-review costs are unresolved. No fresh extraction, real verifier, tuning grid or optional baseline is included. Missing frozen memory replay aborts; replacing records requires new versions/review.

Classifier outputs are frozen once per exact query; no-memory and write controls are shared only for identical conditions. Memory-answer and judge caching is not discounted. Logical verification tickets remain equal even with shared oracle lookup.

QA scoring uses validated aliases and blinded human adjudication; their labor and dataset annotation labor are unknown costs. Taxes, credit purchase fees and local compute are excluded. Refresh pricing and inspect exact prompts before paid use.
