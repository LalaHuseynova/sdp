"""Invented controls/mock HTTP test gates and isolation, never human annotation."""

import copy
import json
from collections import Counter
from pathlib import Path

import httpx
import pytest

from ams.research.ai_pilot import span_review as s
from ams.research.dynamic.models import LedgerError, canonical
from ams.research.pilot_finish.reviewer import StructuredSDK, StructuredSession, freeze
from test_llm_review import completion
from test_llm_review import plan as parent_plan  # noqa: F401
from test_question_calibration import offline  # noqa: F401
from test_real_utility_review import prepared_fixture


def test_exact_spans_preserve_markdown_unicode_and_original_offsets():
    text = "# Ledger\r\n\r\n- **Reserve:** 5.9\u202fGB.\nOther amount: 8 GB.\n"
    body = s.support_body(text, "Which reserve is stated?")
    segment = next(x for x in body["segments"] if "Reserve" in x["text"])
    raw = {"status": "answerable", "answer": "5.9 GB", "evidence_ids": [segment["id"]],
           "reason": "Selected original reserve line."}
    extraction, proof = s.decode_support(text, body, raw)
    assert extraction["evidence"] == "- **Reserve:** 5.9\u202fGB."
    assert s.base.support_decision(extraction, ["5.9 GB"]) == "confirmed"
    for span in proof["selected_spans"]:
        assert text[span["start"]:span["end"]] == span["text"]
    assert raw["evidence_ids"] == [segment["id"]]


@pytest.mark.parametrize("change", [
    {"evidence_ids": ["invented"]}, {"evidence_ids": ["s0000", "s0000"]},
    {"evidence_ids": []}, {"evidence_ids": ["s0000", "s0001"]},
    {"status": "uncertain", "answer": "5.9 GB"}, {"evidence": "cleaned quote"},
])
def test_invented_duplicate_missing_and_extra_evidence_cannot_pass(change):
    text = "Amount: 5.9 GB.\nAnother amount: 8 GB."
    raw = {"status": "answerable", "answer": "5.9 GB", "evidence_ids": ["s0000"],
           "reason": "Original first line."}
    with pytest.raises(LedgerError):
        s.decode_support(text, s.support_body(text, "What amount?"), {**raw, **change})


def test_wrong_line_or_changed_units_never_confirms_a_reference():
    text = "Amount: 5.9 GB.\nDifferent item: 8 MB."
    body = s.support_body(text, "What amount?")
    raw = {"status": "answerable", "answer": "5.9 GB", "evidence_ids": ["s0001"],
           "reason": "Deliberately wrong segment fixture."}
    extracted, _ = s.decode_support(text, body, raw)
    assert s.base.support_decision(extracted, ["5.9 GB"]) == "uncertain"
    extracted, _ = s.decode_support(text, body, {**raw, "answer": "8 MB"})
    assert s.base.support_decision(extracted, ["8 Mb"]) == "not_confirmed"


@pytest.mark.parametrize("kind,expected", [
    ("descriptive_report", True), ("action_or_external_disclosure", False),
    ("principal_preference_or_authority", False), ("unclear", None),
])
def test_requested_use_is_separate_from_reviewers_role_and_other_flags(kind, expected):
    raw = {"requested_use": kind, "question_clear": False, "useful_for_task": False,
           "reason": "Classification must stand separately."}
    assert s.decode_quality(raw)["safe_descriptive_use"] is expected
    with pytest.raises(LedgerError):
        s.decode_quality({**raw, "safe_descriptive_use": True})


def test_private_references_and_control_expectations_do_not_change_model_inputs():
    frames = s.controls()
    changed = copy.deepcopy(frames)
    for f in changed:
        if "aliases" in f:
            f["aliases"] = ["Private replacement value"]
            f["expected"] = {k: "uncertain" for k in f["expected"]}
        else:
            f["expected_quality"] = {"requested_use": "unclear"}
    jobs, _ = s.make_jobs(frames)
    assert jobs == s.make_jobs(changed)[0]
    assert len(jobs) == 84
    assert Counter(j["checker_task"] for j in jobs) == {
        "support_segments": 48, "leakage": 24, "quality_use": 12}
    for j in jobs:
        body = json.loads(j["request"]["messages"][1]["content"])
        allowed = {"support_segments": {"segments", "question"},
                   "leakage": {"question"},
                   "quality_use": {"source", "memory", "question"}}[j["checker_task"]]
        assert set(body) == allowed


@pytest.mark.parametrize(
    "failure", [None, "use_classification", "invalid_application_span", "budget_stop",
                "cached_application"]
)
def test_stage_gate_real_application_replay_and_no_gold_promotion(request, monkeypatch, failure):
    original, cfg, _, _ = request.getfixturevalue("parent_plan")
    repo = original.parent
    prepared, reviewed = prepared_fixture(repo)
    before = (reviewed/"automated_proposals.jsonl").read_bytes()
    _, _, _, candidates, _ = s.previous.collect([reviewed], prepared)
    q = copy.deepcopy(candidates["q_0"])
    q["question"] = "According to the statement with 5.6% growth, what overall revenue is stated?"
    q["candidate_id"] = "new_invented_candidate"
    frame = {"case_id": "invented_application", "role": "candidate", "contribution_id": "p_0",
             "use_id": "use_0", "source": "# Report\nOverall Revenue was $7.8 million, a 5.6% increase YoY.",
             "memory": "Overall Revenue was $7.8 million, a 5.6% increase YoY.",
             "question": q["question"], "aliases": ["$7.8 million"], "candidate_copy": q}
    frames = [*s.controls(), frame]
    parent = repo/"previous_failed_review"
    parent.mkdir()
    for n in ["review_manifest.json", "results_manifest.json", "frames_manifest.json", "private_frames.json"]:
        (parent/n).write_text("{}")
    parent_cfg = {**cfg, "prepared": str(prepared), "reviews": [str(reviewed)]}
    monkeypatch.setattr(s, "frames_from_parent", lambda p: (parent_cfg, frames))
    monkeypatch.setattr(s, "ENTRY_NANODOLLARS", 0)
    if failure == "budget_stop":
        monkeypatch.setattr(s, "CAP_NANODOLLARS", 0)
    for relative in ["scripts/review_exact_spans.py", "reports/SPAN_REVIEWER_20261101_PROTOCOL.md"]:
        p = repo/relative; p.parent.mkdir(parents=True, exist_ok=True); p.write_text("# Fixture\n")
    if failure == "cached_application":
        old_job = next(j for j in s.make_jobs(frames)[0]
                       if j["stage"] == "application" and j["checker_task"] == "leakage")
        old_plan = repo/"completed_question_only"
        freeze(old_plan, {"session_id": cfg["session_id"],
                          "session_directory": cfg["session_directory"]}, [old_job], [])
        raw = {"status": "answer_not_given", "answer": "", "evidence": "",
               "reason": "Invented already-paid question-only fixture."}
        with StructuredSession(Path(cfg["session_directory"])) as session:
            session.arm_annotation_mock(old_plan, httpx.MockTransport(lambda r: completion(raw)))
            session._sdk = StructuredSDK(session._sdk, session)
            session.complete_review(old_job)
    plan = repo/"new_review"
    s.prepare(repo, parent, plan)
    _, jobs, _, links = s.verify_plan(plan)
    by_messages = {canonical(j["request"]["messages"]): j for j in jobs}
    by_link = {l["call_id"]: (f, part) for f in frames
               for part, l in links[f["case_id"]].items()}
    seen = []

    def handler(request):
        data = json.loads(request.content)
        j = by_messages[canonical(data["messages"])]
        f, part = by_link[j["call_id"]]
        body = json.loads(data["messages"][1]["content"])
        seen.append(j["stage"])
        if part == "quality":
            expected = f.get("expected_quality", {})
            raw = {"requested_use": expected.get("requested_use", "descriptive_report"),
                   "question_clear": expected.get("question_clear", True),
                   "useful_for_task": expected.get("useful_for_task", True),
                   "reason": "Invented fixture quality class."}
            if failure == "use_classification" and raw["requested_use"] == "action_or_external_disclosure":
                raw.update(requested_use="descriptive_report", question_clear=False,
                           useful_for_task=False)
        elif part == "leakage":
            present = f.get("expected", {}).get("leakage") == "present"
            raw = {"status": "answer_given" if present else "answer_not_given",
                   "answer": f["aliases"][0] if present else "",
                   "evidence": f["question"] if present else "", "reason": "Fixture exposure."}
        else:
            expected = f.get("expected", {}).get(part, "confirmed")
            positive = expected == "confirmed"
            raw = {"status": "answerable" if positive else (
                "uncertain" if expected == "uncertain" else "not_stated"),
                   "answer": f["aliases"][0] if positive else "", "evidence_ids": [],
                   "reason": "Invented control extraction fixture."}
            if positive:
                raw["evidence_ids"] = [next(v["id"] for v in body["segments"]
                    if s.base.normalized(f["aliases"][0]) in s.base.normalized(v["text"]))]
            if failure == "invalid_application_span" and j["stage"] == "application" and part == "source":
                raw["evidence_ids"] = ["not_an_original_segment"]
        return completion(raw)

    transport = httpx.MockTransport(handler)
    def arm(self, plan, key):
        self.arm_annotation_mock(plan, transport)
        self.provider_preflight = {"mock": True}
    monkeypatch.setattr(StructuredSession, "arm_annotation", arm)
    monkeypatch.setenv("OPENROUTER_API_KEY", "offline-only")
    result = s.run(plan)
    assert result["qualification_passed"] is (failure not in {"use_classification", "budget_stop"})
    assert result["AI_question_admitted"] is (failure in {None, "cached_application"})
    assert len(seen) == (0 if failure == "budget_stop" else (
        84 if failure == "use_classification" else (87 if failure == "cached_application" else 88)))
    assert result["physical_new_requests"] == len(seen)
    assert result["preexisting_replies_reused"] == (1 if failure == "cached_application" else 0)
    if failure in {"use_classification", "budget_stop"}:
        assert "application" not in seen
    assert result["human_verified_labels"] == result["human_validated_questions"] == 0
    assert result["source_labels_changed"] == result["defense_experiments"] == 0
    count = len(seen)
    assert s.run(plan) == result and len(seen) == count
    view = repo/"derived_view"
    s.combined_view(plan, view)
    rows = [json.loads(x) for x in (plan/"automated_proposals.jsonl").read_text().splitlines()]
    assert all(p["human_validated"] is False and p["eligible_as_gold"] is False
               and p["can_update_live_trust"] is False and p["records"] == [] for p in rows)
    assert (reviewed/"automated_proposals.jsonl").read_bytes() == before
    assert (view/"automated_proposals.jsonl").read_bytes().startswith(before)
    if failure != "budget_stop":
        with pytest.raises(LedgerError, match="already consumed"):
            s.prepare(repo, parent, repo/"forbidden_repeat")
    assert not (repo/"forbidden_repeat").exists()
