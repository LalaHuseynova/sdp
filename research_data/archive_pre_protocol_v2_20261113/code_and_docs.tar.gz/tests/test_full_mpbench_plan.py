"""Offline regression checks for frozen plans and paid-execution boundaries."""

from __future__ import annotations

import contextlib
import io
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import prepare_full_mpbench as prepare  # noqa: E402 - import repo experiment scripts
import run_full_mpbench as runner  # noqa: E402 - import repo experiment scripts
import run_mpbench as mpbench_runner  # noqa: E402 - import repo experiment scripts


class FullMPBenchPlanTests(unittest.TestCase):
    def make_plan(self, directory):
        with patch.dict(os.environ, {}, clear=True):
            job = prepare.build_jobs(["4omini"], ["no_defence"])[0]
        config_path = Path(directory) / "config.yaml"
        config_path.write_text(yaml.safe_dump(job["config"]))
        job.update(
            config_path=str(config_path),
            config_sha256=prepare.sha256(config_path),
            command=["never-execute", "--require-full", "--yes"],
        )
        official = json.loads((ROOT / "reports/mpbench_official_byte_validation.json").read_text())
        plan = {
            "repository": str(ROOT),
            "source_sha256": {},
            "dataset": {
                "counts": {
                    "ingestions": 6240,
                    "attack_ingestions": 3241,
                    "attack_reads": 2999,
                    "benign_reads": 2997,
                },
                "official_validation": official,
            },
            "jobs": [job],
        }
        path = Path(directory) / "plan.json"
        path.write_text(json.dumps(plan))
        return plan, path

    def test_all_published_jobs_preserve_method_settings_and_share_full_pool(self):
        with patch.dict(os.environ, {}, clear=True):
            jobs = prepare.build_jobs(list(prepare.BACKBONES), list(prepare.METHODS))
        self.assertEqual(len(jobs), 32)
        for job in jobs:
            cfg = job["config"]
            original = yaml.safe_load((ROOT / job["source_config"]).read_text())
            for key, value in original.items():
                if key not in ("name", "models", "pool_size", "runtime", "defences"):
                    self.assertEqual(cfg[key], value)
            self.assertEqual(cfg["pool_size"], 6240)
            self.assertNotIn("limit", cfg)
            self.assertEqual(cfg["models"]["embed"], "local:")
            self.assertEqual(cfg["models"]["judge"], "openrouter:openai/gpt-4o-mini")
            self.assertFalse(cfg["reproduction"]["model_substitution"])

    def test_env_models_are_resolved_and_substitutions_explicit(self):
        env = {"SAFE_MEM_MODEL_4OMINI": "qwen/qwen3.8-flash", "SAFE_MEM_WORKERS": "3"}
        with patch.dict(os.environ, env, clear=True):
            cfg = prepare.build_jobs(["4omini"], ["safe_mem"])[0]["config"]
        self.assertEqual(cfg["models"]["memory"], "openrouter:qwen/qwen3.8-flash")
        self.assertTrue(cfg["reproduction"]["model_substitution"])
        self.assertEqual(cfg["runtime"]["workers"], 3)
        with patch.dict(os.environ, {"SAFE_MEM_MEMORY_MODEL": "openai/gpt-4o-mini"}, clear=True):
            with self.assertRaisesRegex(ValueError, "exactly one backbone"):
                prepare.build_jobs(["4omini", "gpt56"], ["safe_mem"])

    def test_review_mode_never_launches_a_process_or_loads_credentials(self):
        with tempfile.TemporaryDirectory() as directory:
            _, path = self.make_plan(directory)
            with (
                patch.object(runner.subprocess, "Popen", side_effect=AssertionError("paid launch")),
                patch.object(runner, "load_env", side_effect=AssertionError("credentials")),
                contextlib.redirect_stdout(io.StringIO()),
            ):
                self.assertEqual(runner.main(["--plan", str(path)]), 0)

    def test_execution_without_finite_positive_approval_is_rejected_before_credentials(self):
        with tempfile.TemporaryDirectory() as directory:
            _, path = self.make_plan(directory)
            for value in (None, "nan", "inf", "-inf", "0", "-1"):
                args = ["--plan", str(path), "--execute"]
                if value is not None:
                    args.append(f"--approved-budget-usd={value}")
                with (
                    self.subTest(value=value),
                    patch.object(runner, "load_env", side_effect=AssertionError("credentials")),
                    contextlib.redirect_stdout(io.StringIO()),
                    contextlib.redirect_stderr(io.StringIO()),
                    self.assertRaises(SystemExit) as caught,
                ):
                    runner.main(args)
                self.assertEqual(caught.exception.code, 2)

    def test_changed_config_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            plan, _ = self.make_plan(directory)
            Path(plan["jobs"][0]["config_path"]).write_text("pool_size: 1\n")
            with self.assertRaisesRegex(ValueError, "configuration changed"):
                runner.validate_plan(plan)

    def test_original_runner_rejects_subsets_and_small_pools_before_clients(self):
        for extra in (["--limit", "80"], ["--pool-size", "1"]):
            with (
                self.subTest(extra=extra),
                patch.object(
                    mpbench_runner, "RunContext", side_effect=AssertionError("client construction")
                ),
                patch.object(mpbench_runner, "load_env"),
                contextlib.redirect_stderr(io.StringIO()),
                self.assertRaises(SystemExit) as caught,
            ):
                mpbench_runner.main(
                    [
                        "--config",
                        str(ROOT / "configs/openrouter_mpbench_safemem.yaml"),
                        "--require-full",
                        "--yes",
                        *extra,
                    ]
                )
            self.assertEqual(caught.exception.code, 2)

    def test_budget_cannot_start_another_job_after_threshold(self):
        with tempfile.TemporaryDirectory() as directory:
            budget = runner.LedgerBudget(Path(directory))
            budget.cost = 1.0
            with patch.object(
                runner.subprocess, "Popen", side_effect=AssertionError("paid launch")
            ):
                code, reason = runner.run_job({}, Path(directory), "unused", budget, 1.0)
            self.assertEqual(code, 2)
            self.assertIn("before launching", reason)

    def test_budget_counts_only_complete_uncached_paid_log_rows_once(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "usage.jsonl"
            row = {
                "provider": "openrouter",
                "model": "openai/gpt-4o-mini",
                "cached": False,
                "cost_usd": 0.25,
            }
            encoded = json.dumps(row)
            path.write_text(encoded[:10])
            budget = runner.LedgerBudget(Path(directory))
            budget.poll()
            self.assertEqual(budget.cost, 0)
            with path.open("a") as out:
                out.write(encoded[10:] + "\n")
                out.write(json.dumps({**row, "cached": True, "cost_usd": 99}) + "\n")
                out.write(json.dumps({**row, "provider": "local", "cost_usd": 99}) + "\n")
            budget.poll()
            budget.poll()
            self.assertEqual(budget.cost, 0.25)
            self.assertEqual(budget.calls, 1)

    def test_available_prompt_fingerprints_are_populated(self):
        fingerprints = prepare.prompt_fingerprints()
        self.assertIn("memory_extract/v1", fingerprints)
        self.assertIn("retention_sentence/v1", fingerprints)
        self.assertGreater(len(fingerprints), 10)


if __name__ == "__main__":
    unittest.main()
