"""Invented temporary review declarations only; no genuine human votes are created."""

import copy
import json
import re
from pathlib import Path

import pytest

from ams.research import focused_review as f
from ams.research.dynamic.models import LedgerError, canonical, digest
from ams.research.recovery.offline import sha_file
from test_question_calibration import offline  # noqa: F401
from test_real_utility_review import prepared_fixture


@pytest.fixture
def setup(tmp_path):
    prepared, reviewed = prepared_fixture(tmp_path)
    packets, _, _, candidates, _ = f.collect([reviewed], prepared)
    packet = packets["p_0"]
    for p in packets.values():
        for r in p["records"]:
            r["content_hash"] = digest(r["text"])
        for a in p["artifacts"]:
            a["content_hash"] = digest(a["text"])
    (prepared/"private/review_packets.jsonl").write_text("".join(canonical(p)+"\n" for p in packets.values()))
    (prepared/"private/evaluator_case_index.jsonl").write_text("".join(canonical({
        "contribution_id": pid, "context_id": "file_and_doc", "group_id": "group-"+pid,
        "stratum": "explicit_benign" if pid == "p_0" else "suggestive_benign"})+"\n" for pid in packets))
    q = copy.deepcopy(candidates["q_0"])
    q.update(candidate_id="new_frozen_fixture_question",
             question="According to the statement with 5.6% growth, what overall revenue is stated?")
    package = tmp_path/"package"; (package/"controller_only").mkdir(parents=True)
    (package/"controller_only/candidate.json").write_text(canonical(q))
    (package/"controller_only/packet.json").write_text(canonical(packet))
    files = {str(p.relative_to(package)): sha_file(p) for p in package.rglob("*.json")}
    (package/"manifest.json").write_text(canonical({"files": files, "hash": digest(files)}))
    root = tmp_path/"workflow"
    f.prepare(package, root)
    return root, prepared, reviewed, package


def write(root, label, body):
    p = root.parent/(label+".json")
    p.write_text(canonical(body))
    return p


def first(root, role, reviewer=None):
    b = f.blank(root, "first", role)
    _, q, packet, record = f.load(root)
    a = next(a for a in packet["artifacts"] if a["artifact_id"] == q["support_artifact_id"])
    quote = record["text"]; start = a["text"].index(quote)
    b.update(reviewer_id=reviewer or f"invented-person-{role}", independent_human_review=True,
             status="complete", answer_from_source=q["answers"][0], answer_from_memory=q["answers"][0],
             source_evidence_spans=[{"artifact_id": a["artifact_id"], "start": start,
                                     "end": start+len(quote), "quote": quote}],
             memory_evidence_spans=[{"record_id": record["record_id"], "start": 0,
                                     "end": len(quote), "quote": quote}],
             origin="external", origin_rationale="Invented fixture source-role evidence.",
             rationale="Invented unit-test first pass.", **{k: True for k in f.FIRST_FLAGS})
    return b


def seal_first(root, role, **changes):
    body = {**first(root, role), **changes}
    f.seal(root, "first", role, write(root, f"first-input-{role}", body))
    return body


def second(root, role, **changes):
    b = f.blank(root, "second", role)
    b.update(reviewer_id=f.sealed(root, "first", role)["payload"]["reviewer_id"],
             status="complete", independent_human_review=True,
             rationale="Invented unit-test second pass.", **{k: True for k in f.QA_KEYS})
    b.update(changes)
    return b


def complete(root, first_changes=None, second_changes=None):
    for role in [1, 2]:
        seal_first(root, role, **((first_changes or {}).get(role, {})))
    f.release(root)
    for role in [1, 2]:
        b = second(root, role, **((second_changes or {}).get(role, {})))
        f.seal(root, "second", role, write(root, f"second-input-{role}", b))


def coordinator(root):
    cfg, _, _, _ = f.load(root)
    records = [f.sealed(root, "first", n) for n in [1, 2]] + [f.sealed(root, "second", n) for n in [1, 2]]
    adj = f.sealed(root, "adjudication", 3)
    if adj:
        records.append(adj)
    ids = [f.sealed(root, "first", n)["payload"]["reviewer_id"] for n in [1, 2]]
    if adj:
        ids.append(adj["payload"]["reviewer_id"])
    return {"schema": f.SCHEMA, "candidate_hash": cfg["candidate_hash"], "status": "complete",
            "coordinator_id": "invented-test-coordinator", "reviewer_ids": ids,
            "genuine_human_reviews_confirmed": True, "independent_people_confirmed": True,
            "first_pass_blinding_confirmed": True, "sealed_record_hashes": [r["record_hash"] for r in records],
            "rationale": "Invented unit fixture; not actual human validation."}


def test_blank_pages_hide_references_and_never_claim_human_completion(setup):
    root, _, _, _ = setup
    status = f.status(root)
    assert status["sealed_first_passes"] == status["sealed_second_passes"] == 0
    assert status["reference_released"] is False and status["execution_enabled"] is False
    html = (root/"forms/reviewer_1/first_pass.html").read_text()
    data = json.loads(re.search(r'<script id="review-data" type="application/json">(.*?)</script>', html, re.S).group(1))
    assert not {"reference_answers", "answers", "AI_verdict", "Y_case", "expected_memory"} & set(data)
    assert data["template"]["independent_human_review"] is False
    assert "connect-src 'none'" in html and 'id="human" type="checkbox" required' in html
    assert "innerHTML" not in html and "fetch(" not in html
    assert not (root/"forms/reviewer_2/second_pass.html").exists()
    with pytest.raises(LedgerError, match="Both independent first"):
        f.release(root)
    assert not (root/"sealed/reference_release.json").exists()


@pytest.mark.parametrize("mutation", ["pending", "not_human", "identity", "stale_hash", "bad_span", "boolean_span", "wrong_role", "extra", "numeric_flag"])
def test_invalid_or_blank_submissions_fail_before_sealing(setup, mutation):
    root, _, _, _ = setup
    b = first(root, 1)
    if mutation == "pending": b["status"] = "pending"
    elif mutation == "not_human": b["independent_human_review"] = False
    elif mutation == "identity": b["reviewer_id"] = ""
    elif mutation == "stale_hash": b["candidate_hash"] = digest("different question")
    elif mutation == "bad_span": b["source_evidence_spans"][0]["quote"] = "fabricated evidence"
    elif mutation == "boolean_span": b["source_evidence_spans"][0]["start"] = True
    elif mutation == "wrong_role": b["origin"] = "principal"
    elif mutation == "extra": b["Y_case"] = True
    else: b["question_clear"] = 1
    with pytest.raises((LedgerError, ValueError)):
        f.seal(root, "first", 1, write(root, "invalid", b))
    assert not (root/"sealed/first_1.json").exists()


def test_identity_aliases_cannot_create_independence_and_seals_cannot_be_overwritten(setup):
    root, _, _, _ = setup
    seal_first(root, 1, reviewer_id="  Alice  ")
    old = (root/"sealed/first_1.json").read_bytes()
    b = first(root, 2, reviewer="ALICE")
    with pytest.raises(LedgerError, match="not distinct"):
        f.seal(root, "first", 2, write(root, "duplicate-person", b))
    b = first(root, 1, reviewer="  Alice  ")
    f.seal(root, "first", 1, write(root, "same-again", b))
    b["rationale"] = "Changed after sealing."
    with pytest.raises(LedgerError, match="cannot be overwritten"):
        f.seal(root, "first", 1, write(root, "overwrite", b))
    assert (root/"sealed/first_1.json").read_bytes() == old


def test_two_pass_import_is_qa_only_and_needs_a_coordinator_declaration(setup):
    root, _, _, _ = setup
    complete(root)
    assert f.status(root)["status"] == "awaiting_coordinator_acceptance"
    form = root.parent/"blank-coordinator.json"
    f.coordinator_form(root, form)
    raw = json.loads(form.read_text())
    assert raw["status"] == "pending" and raw["genuine_human_reviews_confirmed"] is False
    assert raw["sealed_record_hashes"] and raw["coordinator_id"] == ""
    c = coordinator(root); c["independent_people_confirmed"] = False
    with pytest.raises(LedgerError, match="genuine process"):
        f.accept(root, write(root, "bad-coordinator", c), root.parent/"not-imported")
    assert not (root.parent/"not-imported").exists()
    result = f.accept(root, write(root, "coordinator", coordinator(root)), root.parent/"accepted")
    assert result["accepted_human_QA_candidates"] == 1
    assert result["human_verified_source_bundles"] == result["human_verified_memory_labels"] == 0
    assert result["eligible_as_gold"] is result["can_update_live_trust"] is result["execution_enabled"] is False
    assert "software cannot prove" in result["identity_authentication"]
    assert f.import_result(root.parent/"accepted") == result
    with pytest.raises(LedgerError, match="genuine disagreement"):
        f.adjudication_form(root)


@pytest.mark.parametrize("problem", ["uncertainty", "wrong_first_answer", "negative_QA"])
def test_uncertain_negative_or_reference_biased_reviews_are_preserved_without_admission(setup, problem):
    root, _, _, _ = setup
    first_changes, second_changes = {}, {}
    if problem == "uncertainty":
        first_changes = {n: {"question_clear": None} for n in [1, 2]}
        second_changes = {n: {"question_clear": None} for n in [1, 2]}
    elif problem == "wrong_first_answer":
        first_changes = {n: {"answer_from_source": "$9.1 million", "answer_from_memory": "$9.1 million"} for n in [1, 2]}
    else:
        second_changes = {n: {"useful_for_task": False} for n in [1, 2]}
    complete(root, first_changes, second_changes)
    r = f.accept(root, write(root, "coordinator", coordinator(root)), root.parent/"rejected")
    assert r["accepted_human_QA_candidates"] == 0 and r["reasons"]
    assert r["human_verified_memory_labels"] == 0
    assert f.sealed(root, "first", 1)["payload"].get("answer_from_source")


def test_genuine_disagreement_requires_distinct_evidenced_adjudication(setup):
    root, _, _, _ = setup
    complete(root, second_changes={2: {"supported_answer": False}})
    assert f.status(root)["status"] == "adjudication_required"
    with pytest.raises(LedgerError, match="incomplete"):
        f.accept(root, write(root, "coordinator", coordinator(root)), root.parent/"premature")
    f.adjudication_form(root)
    b = f.blank(root, "adjudication", 3)
    facts = first(root, 1)
    for k in f.EVIDENCE_KEYS: b[k] = facts[k]
    b.update(status="complete", independent_human_review=True, reviewer_id="invented-person-3",
             rationale="Invented adjudication with source evidence.", **{k: True for k in f.QA_KEYS})
    wrong = {**b, "reviewer_id": "invented-person-1"}
    with pytest.raises(LedgerError, match="distinct person"):
        f.seal(root, "adjudication", 3, write(root, "same-person-adjudication", wrong))
    f.seal(root, "adjudication", 3, write(root, "adjudication", b))
    result = f.accept(root, write(root, "coordinator-final", coordinator(root)), root.parent/"adjudicated")
    assert result["accepted_human_QA_candidates"] == 1 and result["adjudicator_id"] == "invented-person-3"
    assert result["human_verified_memory_labels"] == 0


def test_reference_release_and_second_pass_are_bound_to_sealed_person_and_content(setup):
    root, _, _, _ = setup
    seal_first(root, 1)
    with pytest.raises(LedgerError, match="Both independent first"):
        f.release(root)
    seal_first(root, 2); f.release(root)
    b = second(root, 1, first_pass_hash=digest("not this first pass"))
    with pytest.raises(LedgerError, match="commitment"):
        f.seal(root, "second", 1, write(root, "wrong-first", b))
    b = second(root, 1, reviewer_id="someone else")
    with pytest.raises(LedgerError, match="Changed reviewer"):
        f.seal(root, "second", 1, write(root, "wrong-person", b))
    item = f.sealed(root, "first", 1)
    item["payload"]["rationale"] = "Tampered."
    (root/"sealed/first_1.json").write_text(canonical(item))
    with pytest.raises(LedgerError, match="modified"):
        f.status(root)


def test_readiness_preserves_source_labels_and_tracks_scoped_human_QA_separately(setup):
    root, prepared, reviewed, _ = setup
    old = (reviewed/"automated_proposals.jsonl").read_bytes()
    pending = f.readiness(root, prepared, [reviewed], root.parent/"pending-readiness")
    assert pending["human_validated_questions"] == 0 and pending["human_verified_labels"] == 0
    assert not (root.parent/"pending-readiness/readiness.json").exists()
    complete(root)
    accepted = root.parent/"accepted"
    f.accept(root, write(root, "coordinator", coordinator(root)), accepted)
    report = f.readiness(root, prepared, [reviewed], root.parent/"reviewed-readiness", accepted)
    assert report["human_validated_questions"] == report["accepted_human_QA_candidates"] == 1
    assert report["human_verified_labels"] == 0 and report["human_validated_pilot_ready"] is False
    assert report["automatic_freeze_enabled"] is report["defense_execution_enabled"] is False
    explicit = next(s for s in report["strata"] if s["context"] == "file_and_doc" and s["original_case_stratum"] == "explicit_benign")
    assert explicit["shortfall"] == 0
    assert report["exploratory_data_ready"] is False  # Fixture intentionally lacks the other quotas.
    assert (reviewed/"automated_proposals.jsonl").read_bytes() == old
    _, records, *_ = f.collect([root.parent/"reviewed-readiness/selection_view"], prepared)
    assert len(records) == 9


def test_embedded_source_html_is_inert_and_package_changes_are_rejected(setup):
    root, _, _, package = setup
    from ams.research.focused_review_page import page
    malicious = '</script><img src="https://invalid.example/" onerror="alert(1)">'
    html = page({"artifacts": [{"text": malicious}], "template": {}})
    assert malicious not in html and '\\u003c/script\\u003e' in html
    assert "textContent=a.text" in html
    path = package/"controller_only/packet.json"
    path.write_text(path.read_text()+" ")
    with pytest.raises(LedgerError, match="changed"):
        f.status(root)


def test_span_offsets_are_unicode_characters_not_utf16_units():
    source = "📦 Α: amount is $7.8 million."
    memory = "☃ Amount is $7.8 million."
    quote = "$7.8 million"
    body = {"origin": "external", "origin_rationale": "Invented Unicode fixture.",
            "answer_from_source": quote, "answer_from_memory": quote,
            "source_evidence_spans": [{"artifact_id": "external", "start": source.index(quote),
                "end": source.index(quote)+len(quote), "quote": quote}],
            "memory_evidence_spans": [{"record_id": "record", "start": memory.index(quote),
                "end": memory.index(quote)+len(quote), "quote": quote}]}
    packet = {"artifacts": [{"artifact_id": "external", "role": "external", "text": source}]}
    record = {"record_id": "record", "text": memory}
    f.span_checks(body, packet, record)
    body["source_evidence_spans"][0]["start"] += 1
    with pytest.raises(LedgerError, match="Unicode span"):
        f.span_checks(body, packet, record)


def test_concurrent_writers_are_refused_without_changing_a_review(setup):
    root, _, _, _ = setup
    with f.locked(root):
        with pytest.raises(LedgerError, match="Another reviewer-process"):
            with f.locked(root):
                pytest.fail("Acquired a second writer lock")
    assert f.status(root)["sealed_first_passes"] == 0
