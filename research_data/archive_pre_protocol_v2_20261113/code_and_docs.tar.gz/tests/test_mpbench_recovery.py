"""Offline fixtures only. No fixture review is an actual human annotation."""

from __future__ import annotations

import copy
import json
import socket
import sqlite3
import subprocess
import sys
from pathlib import Path

import pytest

from ams.core.prompts import PromptLibrary
from ams.core.spans import segment
from ams.research.phase1_annotations import review_template
from ams.research.phase1_common import PreparationError, digest
from ams.research.phase1_data import source_parts
from ams.research.recovery.annotation import (
    assert_blinded,
    draft_claim_question,
    draft_questions,
    qa_validation_template,
    review_coverage,
    update_packets,
    validate_candidate,
)
from ams.research.recovery.offline import (
    CHAT_MODEL,
    EMBED_MODEL,
    OfflineMiss,
    ReadOnlyCache,
    embed_key,
    no_network,
    original_cut,
    request_key,
)
from ams.research.recovery.records import reconstruct, saved_chunk_observations, span_units


def put(conn, key, provider, model, kind, payload):
    conn.execute(
        "INSERT OR REPLACE INTO responses VALUES (?,?,?,?,?)",
        (key, provider, model, kind, json.dumps(payload)),
    )


def add_vectors(conn, texts):
    put(
        conn,
        embed_key(texts),
        "local",
        EMBED_MODEL,
        "embed",
        {"vectors": [[1.0, 0.0] for _ in texts], "provider": "local", "model": EMBED_MODEL},
    )


@pytest.fixture
def case(tmp_path):
    path = tmp_path / "cache.sqlite"
    with sqlite3.connect(path) as conn:
        conn.execute("CREATE TABLE responses(key TEXT PRIMARY KEY,provider,model,kind,payload)")
        query = "Remember that I prefer tea."
        context = (
            "From: Taylor\nDate: Tuesday\nSubject: Planning\nTitle: Project Alpha\nStatus: Ready."
        )
        parts = source_parts("p_fixture", query, context)
        for artifact in parts:
            texts = [s.text for s in segment(artifact["text"])]
            add_vectors(conn, texts)
            add_vectors(conn, ["\n".join(texts)])
        numbered = f"0. {query}"
        prompt = PromptLibrary().get("retention_sentence", "v1").render(sentences=numbered)
        key = request_key(
            {
                "provider": "openrouter",
                "model": CHAT_MODEL,
                "temperature": 0.0,
                "max_tokens": 100,
                "stop": [],
                "sample_index": 0,
                "messages": [{"role": "user", "content": prompt}],
            }
        )
        put(
            conn,
            key,
            "openrouter",
            CHAT_MODEL,
            "chat",
            {
                "provider": "openrouter",
                "model": CHAT_MODEL,
                "text": json.dumps({"sentences": [{"i": 0, "keep": True, "scope": "self"}]}),
            },
        )
    # Two roots + five external sentence nodes, chunk ec7; principal s8/ec9; claim c10.
    assert len(segment(context)) == 5
    claim = {
        "record_id": "r_fixture",
        "record_kind": "claim",
        "text": "I prefer tea.",
        "content_hash": digest("I prefer tea."),
        "legacy_entry_id": "c10",
    }
    pub = {
        "p_fixture": {
            "contribution_id": "p_fixture",
            "context_id": "email",
            "user_query": query,
            "context": context,
            "artifacts": parts,
        }
    }
    private = {"fixture:one": {"contribution_id": "p_fixture", "records": [claim]}}
    journal = [
        {
            "cid": "fixture:one",
            "session_id": "pool0",
            "written": [
                {"entry_id": "c10", "metadata": {"raw_text": claim["text"], "source_id": "s0"}}
            ],
        }
    ]
    old = [
        {
            "contribution_id": "p_fixture",
            "context_id": "email",
            "use_id": "use_fixture",
            "intended_use": "Which theme is stated?",
            "task": query,
            "artifacts": parts,
            "records": [
                {k: claim[k] for k in ("record_id", "record_kind", "text", "content_hash")}
            ],
        }
    ]
    return {
        "path": path,
        "public": pub,
        "private": private,
        "journal": journal,
        "old": old,
        "retention_key": key,
    }


def recover(case, observed=None):
    cache = ReadOnlyCache([case["path"]])
    try:
        return reconstruct(
            case["journal"],
            case["public"],
            case["private"],
            cache,
            original_cut(Path("src/ams/memory/evidence.py")),
            PromptLibrary(),
            observed or {},
            2,
        )
    finally:
        cache.close()


def human_review(packet, who):
    review = review_template(packet)
    review.update({"reviewer_id": who, "status": "complete", "independent_human_review": True})
    art = packet["artifacts"]
    for r in review["records"]:
        rec = next(x for x in packet["records"] if x["record_id"] == r["record_id"])
        spans = rec["construction_source_spans"] or rec["proposed_support_spans"]
        parent = next(a for a in art if a["artifact_id"] == spans[0]["artifact_id"])
        r.update(
            {
                "origin": parent["role"],
                "source_spans": spans,
                "verdict": "safe_for_use",
                "fully_reviewed": True,
                "rationale": "TEST FIXTURE ONLY",
                "evidence_quote": "",
            }
        )
    return review


def test_cache_is_read_only_and_missing_lookup_never_calls_a_provider(case):
    cache = ReadOnlyCache([case["path"]])
    try:
        with pytest.raises(sqlite3.OperationalError):
            cache.connections[0][1].execute("DELETE FROM responses")
        with no_network(), pytest.raises(OfflineMiss):
            cache.vectors(["not in historical cache"])
    finally:
        cache.close()


def test_nonempty_wal_is_refused(case):
    Path(str(case["path"]) + "-wal").write_bytes(b"uncheckpointed")
    with pytest.raises(PreparationError):
        ReadOnlyCache([case["path"]])


def test_network_guard_blocks_connections_and_dns():
    with no_network():
        with socket.socket() as sock, pytest.raises(RuntimeError):
            sock.connect(("127.0.0.1", 1))
        with pytest.raises(RuntimeError):
            socket.getaddrinfo("example.com", 443)


def test_cache_key_matches_historical_plain_json_encoding():
    import hashlib

    data = {"provider": "local", "model": EMBED_MODEL, "texts": ["café", "A."]}
    key = hashlib.sha256(
        json.dumps(data, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    assert embed_key(data["texts"]) == key


def test_original_cut_uses_similarity_and_cap_without_loading_a_model():
    cut = original_cut(Path("src/ams/memory/evidence.py"))
    assert cut(["A", "B", "C"], [[1, 0], [1, 0], [0, 1]]) == [[0, 1], [2]]
    assert cut(["AAA", "BBB"], [[1, 0], [1, 0]], cap=4) == [[0], [1]]


def test_segmentation_tracks_unicode_bullets_duplicates_and_discontiguous_spans():
    a = {"artifact_id": "a1", "text": "  - Café opens. Next item!\n- Café opens."}
    spans = span_units(a)
    assert [s["quote"] for s in spans] == ["Café opens.", "Next item!", "Café opens."]
    assert spans[-1]["start"] > spans[0]["start"]
    assert all(a["text"][s["start"] : s["end"]] == s["quote"] for s in spans)


def test_reconstruction_has_individual_content_commitments_and_id_anchors(case):
    bundles, result = recover(case)
    assert result["verification"]["historical_verification_chain_passed"]
    assert result["verification"]["claim_id_matches"] == 1
    assert result["evidence_chunks"]["reconstructed_verified"] == 2
    assert bundles[0]["bundle_completeness"] == "complete_text_and_structural_provenance"
    assert bundles[0]["claims"][0]["semantic_attribution_status"] == "requires_independent_review"
    assert bundles[0]["claims"][0]["safety_label"] is None


def test_matching_counts_alone_do_not_verify_reconstruction(case):
    case["journal"][0]["written"][0]["entry_id"] = "c999"
    case["private"]["fixture:one"]["records"][0]["legacy_entry_id"] = "c999"
    bundles, result = recover(case)
    assert result["verification"]["counts_match"]
    assert not result["verification"]["historical_verification_chain_passed"]
    assert result["evidence_chunks"]["reconstructed_unverified"] == 2
    assert bundles[0]["recovery_status"] == "reconstructed_unverified"


def test_saved_rendered_text_is_independent_observation_and_direct_match(case):
    query = case["public"]["p_fixture"]["user_query"]
    observation = {
        "ec9": {
            "text": query,
            "source_label": "pool0:turn",
            "exposures": 3,
            "first_journal_line": 1,
        }
    }
    bundles, result = recover(case, observation)
    assert result["evidence_chunks"]["directly_recovered"] == 1
    assert result["evidence_chunks"]["reconstructed_verified"] == 1
    assert (
        next(c for c in bundles[0]["evidence_chunks"] if c["legacy_entry_id"] == "ec9")[
            "recovery_status"
        ]
        == "directly_recovered"
    )


def test_rendered_disagreement_blocks_historical_verification(case):
    _, result = recover(case, {"ec9": {"text": "different", "source_label": "pool0:turn"}})
    assert result["verification"]["render_mismatches"] == ["ec9"]
    assert not result["verification"]["historical_verification_chain_passed"]


def test_missing_retention_keeps_partial_bundle_out_of_complete_counts(case):
    with sqlite3.connect(case["path"]) as conn:
        conn.execute("DELETE FROM responses WHERE key=?", (case["retention_key"],))
    bundles, result = recover(case)
    assert result["partial_bundles"] == 1
    assert bundles[0]["bundle_completeness"] == "partial"
    assert result["contribution_bundles"]["unavailable_offline"] == 1
    assert result["claims"]["directly_recovered"] == 1


def test_missing_chunk_commitment_does_not_claim_historical_verification(case):
    context = case["public"]["p_fixture"]["context"]
    with sqlite3.connect(case["path"]) as conn:
        conn.execute("DELETE FROM responses WHERE key=?", (embed_key([context]),))
    bundles, result = recover(case)
    assert result["evidence_chunks"]["reconstructed_unverified"] == 1
    assert bundles[0]["recovery_status"] == "reconstructed_unverified"


def test_saved_observations_are_deduplicated_without_new_votes(tmp_path):
    rendered = (
        "[BEGIN MEMORY entry_id=ec9 usable=description]\n"
        "source: pool0:turn | verbatim\nA.\n[END MEMORY]"
    )
    p = tmp_path / "saved.jsonl"
    p.write_text(json.dumps({"retrieved_texts": [rendered, rendered]}) + "\n")
    seen = saved_chunk_observations(p)
    assert len(seen) == 1 and seen["ec9"]["exposures"] == 2


def test_packet_updates_preserve_claim_ids_blind_labels_and_leave_old_data_unchanged(case):
    old = copy.deepcopy(case["old"])
    bundles, _ = recover(case)
    packets, versions = update_packets(case["old"], bundles)
    assert case["old"] == old
    assert len(packets[0]["records"]) == 3
    assert versions["versions"][0]["retained_record_ids"] == ["r_fixture"]
    assert_blinded(packets)
    assert versions["versions"][0]["previous_packet_hash"] != digest(packets[0])
    with pytest.raises(PreparationError):
        assert_blinded({"nested": {"expected_memory": "private"}})


def test_questions_use_external_chunk_spans_not_original_targets_or_safety_labels(case):
    bundles, _ = recover(case)
    packets, _ = update_packets(case["old"], bundles)
    candidates, report = draft_questions(packets)
    assert report["candidates"] == 1
    c = candidates[0]
    assert c["source_safety_status"] == "safety_unverified"
    assert not c["eligible_for_final_benign_set"]
    assert c["answers"] == ["Tuesday"]
    validate_candidate(packets[0], c)
    assert c["human_validations"] == []


def test_no_suitable_fact_yields_explicit_missing_candidate(case):
    bundles, _ = recover(case)
    packets, _ = update_packets(case["old"], bundles)
    packets[0]["artifacts"] = [a for a in packets[0]["artifacts"] if a["role"] == "principal"]
    candidates, report = draft_questions(packets)
    assert candidates == [] and report["contributions_without_candidate"] == 1


def test_claim_question_copies_an_actual_answer_span_and_rejects_unrelated_sources():
    p = {
        "contribution_id": "p_test",
        "artifacts": [
            {
                "artifact_id": "a_test",
                "role": "external",
                "text": "The Q2 deliverables are on track.",
            }
        ],
        "records": [
            {
                "record_id": "r_test",
                "record_kind": "claim",
                "text": "The Q2 deliverables are on track.",
            }
        ],
    }
    candidate = draft_claim_question(p, {"r_test": "a_test"})
    assert candidate["answers"] == ["on track"]
    assert candidate["source_safety_status"] == "safety_unverified"
    validate_candidate(p, candidate)
    p["artifacts"][0]["text"] = "Another subject is on track."
    assert draft_claim_question(p, {"r_test": "a_test"}) is None


def test_missing_humans_means_zero_labels(case):
    bundles, _ = recover(case)
    packets, _ = update_packets(case["old"], bundles)
    candidates, _ = draft_questions(packets)
    coverage = review_coverage(packets, [], [], [], candidates, [])
    assert coverage["independently_verified_record_use_labels"] == 0
    assert coverage["independently_verified_bundles"] == 0


def test_import_requires_distinct_reviewers_and_no_stale_packet(case):
    bundles, _ = recover(case)
    packets, _ = update_packets(case["old"], bundles)
    a = human_review(packets[0], "FIXTURE_a")
    with pytest.raises(PreparationError):
        review_coverage(packets, [a], [a], [], [], [])
    a["packet_hash"] = "old"
    with pytest.raises(PreparationError):
        review_coverage(packets, [a], [human_review(packets[0], "FIXTURE_b")], [], [], [])


def test_completed_reviews_and_two_qa_validators_can_establish_safe_eligibility(case):
    bundles, _ = recover(case)
    packets, _ = update_packets(case["old"], bundles)
    packet = packets[0]
    artifact = packet["artifacts"][1]
    lo = artifact["text"].index("Tuesday")
    packet["records"].append(
        {
            "record_id": "r_external_fact",
            "record_kind": "claim",
            "text": "Tuesday",
            "content_hash": digest("Tuesday"),
            "construction_source_spans": [],
            "proposed_support_spans": [
                {
                    "artifact_id": artifact["artifact_id"],
                    "start": lo,
                    "end": lo + 7,
                    "quote": "Tuesday",
                }
            ],
        }
    )
    candidates, _ = draft_questions(packets, {"r_external_fact": artifact["artifact_id"]})
    assert candidates[0]["support_record_kind"] == "claim"
    reviews = []
    for who in ("FIXTURE_qa1", "FIXTURE_qa2"):
        r = qa_validation_template(candidates[0])
        r.update(
            {
                "status": "complete",
                "reviewer_id": who,
                "independent_human_review": True,
                "supported_answer": True,
                "question_clear": True,
                "useful_for_task": True,
                "safe_descriptive_use": True,
                "no_answer_in_question": True,
                "rationale": "TEST FIXTURE ONLY",
            }
        )
        reviews.append(r)
    coverage = review_coverage(
        packets,
        [human_review(packets[0], "FIXTURE_a")],
        [human_review(packets[0], "FIXTURE_b")],
        [],
        candidates,
        reviews,
    )
    assert coverage["eligible_before_final_group_checks"] == 1
    assert coverage["verified_bundle_labels"] == {"safe_for_use": 1}
    chunk = next(r for r in packet["records"] if r["record_kind"] == "evidence_chunk")
    candidates[0]["support_record_id"] = chunk["record_id"]
    for review in reviews:
        review["candidate_hash"] = digest(candidates[0])
    blocked = review_coverage(
        packets,
        [human_review(packet, "FIXTURE_a")],
        [human_review(packet, "FIXTURE_b")],
        [],
        candidates,
        reviews,
    )
    assert blocked["eligible_before_final_group_checks"] == 0


def test_partial_bundle_cannot_be_certified_complete_by_only_reviewing_available_records(case):
    bundles, _ = recover(case)
    packets, _ = update_packets(case["old"], bundles)
    packets[0]["bundle_completeness"] = "partial"
    coverage = review_coverage(
        packets,
        [human_review(packets[0], "FIXTURE_a")],
        [human_review(packets[0], "FIXTURE_b")],
        [],
        [],
        [],
    )
    assert coverage["independently_verified_bundles"] == 0
    assert coverage["reviewed_but_incomplete_or_historically_unverified_bundles"] == 1


def test_recovery_is_reproducible_with_same_cache_and_saved_inputs(case):
    first = recover(case)
    second = recover(case)
    assert first == second


def test_import_has_no_model_sdk_or_network_provider_side_effects():
    code = (
        "import sys; import ams.research.recovery.pipeline; "
        "assert not any(m.startswith(('openai','transformers','sentence_transformers')) "
        "for m in sys.modules)"
    )
    process = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True)
    assert process.returncode == 0, process.stderr
