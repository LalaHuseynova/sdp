"""Automated annotation tests with invented packets and mock HTTP only."""

from __future__ import annotations

import copy
import json
import socket
from pathlib import Path

import httpx
import pytest

from ams.research.dynamic.models import LedgerError, digest
from ams.research.execution.session import ExecutionSession
from ams.research.llm_review.design import SESSION, prepare, verify
from ams.research.llm_review.pipeline import run
from ams.research.llm_review.transport import AnnotationSession
from ams.research.llm_review.validation import strict_json, validate
from ams.research.phase1_annotations import validate_review


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def deny(*args, **kwargs):
        raise AssertionError("Only mock HTTP allowed in reviewer tests")

    for name in ("connect", "connect_ex"):
        monkeypatch.setattr(socket.socket, name, deny)
    monkeypatch.setattr(socket, "create_connection", deny)
    monkeypatch.setattr(socket, "getaddrinfo", deny)


def packet(n):
    return {
        "contribution_id": f"p_{n}",
        "context_id": "email" if n < 16 else "file_and_doc",
        "use_id": f"use_{n}",
        "task": "Report the stated planning color.",
        "intended_use": f"What color was stated in note {n}?",
        "artifacts": [
            {"artifact_id": "principal", "role": "principal", "text": "Report the stated color."},
            {"artifact_id": "external", "role": "external", "text": "The planning color is blue."},
        ],
        "records": [
            {
                "record_id": f"r_{n}",
                "record_kind": "claim",
                "text": "The planning color is blue.",
                "content_hash": digest("The planning color is blue."),
            }
        ],
        "expected_memory": "HIDDEN_TARGET",
        "Y_case": True,
        "automated_warnings": ["hidden_hint"],
    }


@pytest.fixture
def plan(tmp_path):
    repo = tmp_path / "repo"
    repo.mkdir()
    prepared = repo / "prepared"
    private = prepared / "private"
    private.mkdir(parents=True)
    packets = [packet(n) for n in range(32)]
    (private / "group_selections.json").write_text(
        json.dumps(
            [
                {
                    "bag_id": "D00",
                    "split_intent": "development",
                    "source_ids": [p["contribution_id"] for p in packets],
                }
            ]
        )
    )
    (private / "review_packets.jsonl").write_text("".join(json.dumps(p) + "\n" for p in packets))
    (private / "question_drafts.jsonl").write_text("")
    for name in [
        "scripts/review_mpbench_llm.py",
        "src/ams/research/execution/session.py",
        "src/ams/llm/budget.py",
        "src/ams/llm/providers/openai_client.py",
        "src/ams/llm/openrouter_budget.py",
    ]:
        p = repo / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("# fixture dependency\n")
    ExecutionSession.create(repo / SESSION, plan_hash="invented-plan").close()
    out = repo / "plan"
    prepared_info = prepare(repo, prepared, out)
    cfg, jobs = verify(out)
    return out, cfg, jobs, prepared_info


def proposal(job):
    data = json.loads(job["request"]["messages"][1]["content"])
    return {
        "records": [
            {
                "record_id": r["record_id"],
                "verdict": "safe_for_use",
                "origin": "external",
                "source_quotes": [
                    {"artifact_id": "external", "quote": "The planning color is blue."}
                ],
                "evidence_quote": "",
                "rationale": "Supported descriptive use.",
            }
            for r in data["records"]
        ],
        "questions": [],
    }


def response(job, **kwargs):
    return {"text": json.dumps(proposal(job)), "raw_finish_reason": "stop", **kwargs}


def completion(body, cost="0.0001"):
    usage = {"prompt_tokens": 10, "completion_tokens": 20, "total_tokens": 30}
    if cost is not None:
        usage["cost"] = cost
    return httpx.Response(
        200,
        json={
            "id": "gen-offline-review-test",
            "model": "openai/gpt-4o-mini",
            "object": "chat.completion",
            "created": 1,
            "choices": [
                {
                    "index": 0,
                    "finish_reason": "stop",
                    "message": {"role": "assistant", "content": json.dumps(body)},
                }
            ],
            "usage": usage,
        },
    )


def test_blinding_exact_scope_and_cost_reservation(plan):
    out, cfg, jobs, info = plan
    assert len(jobs) == 32 and info["memory_records"] == 32
    assert cfg["review_task_reservation_ceiling_usd"] == "0.8503296"
    assert cfg["human_verified"] is False and cfg["scientific_pilot_enabled"] is False
    for j in jobs:
        data = json.loads(j["request"]["messages"][1]["content"])
        assert "Y_case" not in data and "expected_memory" not in data
        assert "HIDDEN_TARGET" not in str(data) and "hidden_hint" not in str(data)
    with pytest.raises(LedgerError):
        prepare(out.parent, out.parent / "prepared", out)


def test_automated_output_cannot_be_human_gold(plan):
    _, _, jobs, _ = plan
    out = validate(jobs[0], response(jobs[0]))
    assert out["annotation_source"] == "llm" and out["independent_human_review"] is False
    assert out["eligible_as_gold"] is False and out["can_update_live_trust"] is False
    assert out["records"][0]["source_identity_authenticated"] is False
    with pytest.raises(ValueError):
        validate_review(packet(0), out)


@pytest.mark.parametrize(
    "mutation",
    [
        "missing",
        "duplicate",
        "unknown",
        "wrong_quote",
        "role",
        "unsafe_no_evidence",
        "promote_human",
        "truncated",
        "bad_json",
    ],
)
def test_invalid_or_truncated_review_never_becomes_complete(plan, mutation):
    _, _, jobs, _ = plan
    j = jobs[0]
    body = proposal(j)
    if mutation == "missing":
        body["records"] = []
    elif mutation == "duplicate":
        body["records"] *= 2
    elif mutation == "unknown":
        body["records"][0]["record_id"] = "missing"
    elif mutation == "wrong_quote":
        body["records"][0]["source_quotes"][0]["quote"] = "invented text"
    elif mutation == "role":
        body["records"][0]["origin"] = "principal"
    elif mutation == "unsafe_no_evidence":
        body["records"][0]["verdict"] = "unsafe"
    elif mutation == "promote_human":
        body["human_validated"] = True
    r = response(j, text=json.dumps(body))
    if mutation == "truncated":
        r["raw_finish_reason"] = "length"
    if mutation == "bad_json":
        r["text"] = "not json"
    with pytest.raises((ValueError, KeyError)):
        validate(j, r)


def test_duplicate_json_fields_fail_closed():
    with pytest.raises(LedgerError):
        strict_json('{"records":[],"records":[],"questions":[]}')


def test_annotation_dispatch_reuses_shared_guard_and_receipt(plan):
    out, cfg, jobs, _ = plan
    seen = []

    def handler(request):
        seen.append(json.loads(request.content))
        return completion(proposal(jobs[0]))

    with AnnotationSession(Path(cfg["session_directory"])) as session:
        session.arm_annotation_mock(out, httpx.MockTransport(handler))
        result = session.complete_review(jobs[0])
        assert result["actual_paid_usd"] == "0"  # simulated charge only
        assert session.guard.snapshot()["limit_usd"] == 30
        assert session.guard.snapshot()["used_nanodollars"] == 100000
        assert session.complete_review(jobs[0]) == result
        assert len(seen) == 1 and seen[0]["max_tokens"] == 12288
        assert (
            session.db.execute("SELECT count(*) FROM annotation_native_responses").fetchone()[0]
            == 1
        )
        with pytest.raises(ValueError):
            session.complete("other", "answer", None)
        with pytest.raises(ValueError):
            session.arm_live(scientific_plan=out, api_key="fixture")
        bad = copy.deepcopy(jobs[1])
        bad["request"]["max_tokens"] = 16384
        with pytest.raises(LedgerError):
            session.complete_review(bad)
    with AnnotationSession(Path(cfg["session_directory"])) as session:
        session.authorize(out)
        assert session.complete_review(jobs[0]) == result
    assert len(seen) == 1


def test_unknown_billing_preserves_raw_reply_and_halts(plan):
    out, cfg, jobs, _ = plan
    with AnnotationSession(Path(cfg["session_directory"])) as session:
        session.arm_annotation_mock(
            out, httpx.MockTransport(lambda _: completion(proposal(jobs[0]), cost=None))
        )
        result = session.complete_review(jobs[0])
        assert result["error"] and result["actual_paid_usd"] is None
        assert session.guard.snapshot()["held_nanodollars"] == 26572800
        assert session.guard.snapshot()["blocked"]
        assert (
            session.db.execute("SELECT count(*) FROM annotation_native_responses").fetchone()[0]
            == 1
        )
        with pytest.raises(LedgerError):
            session.complete_review(jobs[1])


def test_full_mock_review_then_resume_makes_no_more_requests(plan):
    out, cfg, jobs, _ = plan
    seen = []

    def handler(request):
        n = len(seen)
        seen.append(1)
        return completion(proposal(jobs[n]))

    summary = run(out, mock_transport=httpx.MockTransport(handler))
    assert summary["schema_valid_complete_packets"] == 32
    assert summary["record_verdict_counts"] == {"safe_for_use": 32}
    assert summary["actual_review_cost_usd"] == "0" and summary["human_verified_labels"] == 0
    assert summary["defense_ASR"] == "not_measured"
    assert summary["shared_project_budget"]["used_nanodollars"] == 3200000
    assert run(out) == summary and len(seen) == 32


def test_corrupted_plan_refuses_before_paid_dispatch(plan):
    out, _, _, _ = plan
    (out / "settings.json").write_text("{}")
    with pytest.raises(LedgerError):
        verify(out)


def compact(job):
    refs = job["references"]
    source = next(s for s, v in refs["sources"].items() if v["role"] == "external")
    return {
        "records": [
            {
                "id": mid,
                "verdict": "safe_for_use",
                "origin": "external",
                "sources": [source],
                "evidence": [],
                "reason": "Supported descriptive use.",
            }
            for mid in refs["records"]
        ],
        "questions": [],
    }


def test_small_batch_aliases_are_not_semantic_or_human_validation(plan, tmp_path):
    from ams.research.llm_review import batches

    parent, _, _, _ = plan
    out = tmp_path / "small"
    info = batches.prepare(parent, out)
    cfg, jobs = batches.verify(out)
    assert info["records"] == 32 and len(jobs) == 32
    proposal = batches.validate_batch(
        jobs[0], {"text": json.dumps(compact(jobs[0])), "raw_finish_reason": "stop"}
    )
    assert proposal["whole_bundle_complete"] is False
    assert proposal["AI_assessed_bundle"] == "not_assessed_in_partial_batch"
    assert proposal["human_validated"] is False
    assert proposal["records"][0]["record_id"] in jobs[0]["record_versions"]
    assert proposal["records"][0]["source_identity_authenticated"] is False
    assert proposal["records"][0]["source_spans"][0]["quote"] == "The planning color is blue."


@pytest.mark.parametrize(
    "mutation",
    ["unknown_id", "unknown_source", "missing", "unsafe_no_evidence", "extra_human", "truncated"],
)
def test_compact_batch_errors_are_rejected(plan, tmp_path, mutation):
    from ams.research.llm_review import batches

    parent, _, _, _ = plan
    out = tmp_path / "small"
    batches.prepare(parent, out)
    _, jobs = batches.verify(out)
    body = compact(jobs[0])
    response = {"text": "", "raw_finish_reason": "stop"}
    if mutation == "unknown_id":
        body["records"][0]["id"] = "unknown"
    elif mutation == "unknown_source":
        body["records"][0]["sources"] = ["not_a_source"]
    elif mutation == "missing":
        body["records"] = []
    elif mutation == "unsafe_no_evidence":
        body["records"][0]["verdict"] = "unsafe"
    elif mutation == "extra_human":
        body["human_validated"] = True
    else:
        response["raw_finish_reason"] = "length"
    response["text"] = json.dumps(body)
    with pytest.raises((ValueError, KeyError)):
        batches.validate_batch(jobs[0], response)


def test_small_batch_mock_run_preserves_one_shared_budget(plan, tmp_path):
    from ams.research.llm_review import batches

    parent, cfg, _, _ = plan
    out = tmp_path / "small"
    batches.prepare(parent, out)
    _, jobs = batches.verify(out)
    seen = []

    def handler(_):
        index = len(seen)
        seen.append(1)
        return completion(compact(jobs[index]))

    summary = batches.run(out, mock_transport=httpx.MockTransport(handler))
    assert summary["complete_automated_bundles"] == 32
    assert summary["mechanically_valid_record_proposals"] == 32
    assert summary["human_verified_labels"] == 0 and summary["defense_ASR"] == "not_measured"
    assert summary["shared_project_budget"]["limit_usd"] == 30
    assert summary["shared_project_budget"]["used_nanodollars"] == 3200000
    assert batches.run(out) == summary and len(seen) == 32


def test_analysis_reports_quota_shortfalls_without_inventing_accuracy_or_QA(plan, tmp_path):
    import importlib.util

    from ams.research.llm_review import batches

    parent, _, _, _ = plan
    out = tmp_path / "small"
    batches.prepare(parent, out)
    _, jobs = batches.verify(out)
    seen = []

    def handler(_):
        n = len(seen)
        seen.append(1)
        return completion(compact(jobs[n]))

    batches.run(out, mock_transport=httpx.MockTransport(handler))
    prepared = parent.parent / "prepared"
    rows = []
    for n in range(32):
        within = n % 16
        rows.append(
            {
                "contribution_id": f"p_{n}",
                "context_id": "email" if n < 16 else "file_and_doc",
                "stratum": "attack"
                if within < 10
                else "explicit_benign"
                if within == 10
                else "suggestive_benign",
            }
        )
    (prepared / "private/evaluator_case_index.jsonl").write_text(
        "".join(json.dumps(r) + "\n" for r in rows)
    )
    module_path = Path(__file__).resolve().parents[1] / "scripts/analyse_llm_review.py"
    spec = importlib.util.spec_from_file_location("annotation_analysis_fixture", module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    report = module.analyse(out, prepared, tmp_path / "analysis")
    assert report["human_verified_labels"] == 0 and report["human_validated_questions"] == 0
    assert report["accuracy_FPR_FNR_ASR"] == "not_measured"
    assert report["AI_safe_contributions_with_AI_accepted_claim_backed_QA"] == 0
    for ctx in ("email", "file_and_doc"):
        quotas = report["per_context"][ctx]["quotas"]
        assert quotas[0]["nominal_shortfall"] == 8
        assert quotas[1]["QA_conditioned_shortfall"] == 2
        assert quotas[2]["QA_conditioned_shortfall"] == 1
        assert quotas[3]["QA_conditioned_shortfall"] == 5
