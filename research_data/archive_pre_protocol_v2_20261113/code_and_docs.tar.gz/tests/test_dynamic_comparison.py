"""Comparison bookkeeping on invented data; no real experiment or human review."""

import copy
import json

import pytest

from ams.research import comparison as c
from ams.research.dynamic.models import LedgerError, canonical, digest
from ams.research.dynamic.policies import Policy
from test_ai_exploratory_freeze import (
    test_balanced_invented_freeze_never_becomes_human_gold_or_live_execution as build_frozen,
)
from test_question_calibration import offline  # noqa: F401


def fixture(groups=1, regimes=1):
    cells = []
    kinds = ["attack", "attack", "retention", "restraint", "restraint", "restraint", "source_qa", "benign_unscored"]
    for group in range(groups):
        inputs = [f"input-{group}-{i}" for i in range(len(kinds))]
        for regime in range(regimes):
            episode = f"episode-{group}-{regime}"
            probes = [{"probe_id": f"probe-{i}", "input_id": inputs[i], "metric": kind,
                       "question_hash": digest(["question", group, i]),
                       "reference_hash": None if kind == "benign_unscored" else digest(["reference", group, i]),
                       "relation": ["root_batch", "same_context_other_batch", "other_context", "unrelated"][i % 4]}
                      for i, kind in enumerate(kinds)]
            cells.append({"episode_id": episode, "group_id": f"g{group}", "scenario": f"regime-{regime}",
                          "memory_input_hash": digest(["ingestion", group, regime]),
                          "feedback_hash": digest(["five audits", group, regime]), "audit_tickets": 5,
                          "input_ids": inputs, "template_group_ids": ["template-"+x for x in inputs],
                          "probes": probes})
    spec = {"schema": c.SCHEMA, "basis": "test_fixture", "model": "openai/gpt-4o-mini",
            "policy_hashes": {a: Policy(a).fingerprint for a in c.TRANSFER},
            "cells": cells, "execution_enabled": False}
    rows = []
    for cell in cells:
        for arm in c.ARMS:
            for i, p in enumerate(cell["probes"]):
                outcome = True
                if p["metric"] == "attack":
                    outcome = i == 1 if arm == "S" else (i == 0 if arm == "no_memory" else True)
                elif p["metric"] == "restraint":
                    outcome = i == 5
                elif p["metric"] in {"retention", "source_qa"}:
                    outcome = arm != "no_memory"
                if p["metric"] == "benign_unscored":
                    outcome = None
                rows.append({"episode_id": cell["episode_id"], "probe_id": p["probe_id"], "arm": arm,
                             "model": spec["model"], "question_hash": p["question_hash"], "reference_hash": p["reference_hash"],
                             "memory_input_hash": None if arm == "no_memory" else cell["memory_input_hash"],
                             "initial_memory_hash": None if arm == "no_memory" else digest(["native", cell["group_id"]]),
                             "policy_hash": spec["policy_hashes"].get(arm),
                             "available_feedback_hash": cell["feedback_hash"] if arm in c.TRANSFER else None,
                             "audit_tickets": 5 if arm in c.TRANSFER else 0,
                             "equivalent_verification": {"calls": 0, "input_tokens": 0, "output_tokens": 0, "usd": "0"},
                             "answer_status": "answered", "judge_status": "complete" if outcome is not None else "not_applicable",
                             "outcome": outcome, "answer_hash": digest(["saved response", cell["episode_id"], arm, i]),
                             "judge_hash": digest(["saved judgment", cell["episode_id"], arm, i]) if outcome is not None else None})
    return spec, rows


def test_exact_metrics_keep_retention_restraint_qa_and_attribution_separate():
    spec, rows = fixture()
    r = c.analyse(spec, rows, resamples=100)
    metrics = r["regimes"]["regime-0"]["S"]["metrics"]
    assert (metrics["asr"]["numerator"], metrics["asr"]["denominator"]) == (1, 2)
    assert metrics["retention"]["value"] == 1
    assert metrics["restraint"]["value"] == pytest.approx(2/3)
    assert metrics["combined_benign"]["value"] == .75
    assert metrics["source_qa"]["value"] == 1
    # Equal marginal ASRs can still have a nonzero paired attributable ASR.
    assert r["regimes"]["regime-0"]["no_memory"]["metrics"]["asr"]["value"] == .5
    assert metrics["attributable_asr"]["value"] == .5
    assert r["status"] == "complete_saved_outcomes"
    assert r["scientifically_human_validated"] is False
    assert "INVENTED TEST FIXTURE" in c.markdown(r)


@pytest.mark.parametrize("problem", ["missing", "runtime_error", "budget_stopped", "judge_error", "pending_judge"])
def test_missing_failures_and_unjudged_outputs_cannot_reduce_reported_asr(problem):
    spec, rows = fixture()
    i = next(i for i, r in enumerate(rows) if r["arm"] == "S" and r["probe_id"] == "probe-1")
    if problem == "missing":
        rows.pop(i)
    else:
        row = rows[i]
        row.update(outcome=None, judge_hash=None, judge_status="error" if problem in {"judge_error", "runtime_error"} else "pending")
        if problem in {"runtime_error", "budget_stopped"}:
            row.update(answer_status=problem, answer_hash=None)
    r = c.analyse(spec, rows, resamples=20)
    metric = r["regimes"]["regime-0"]["S"]["metrics"]["asr"]
    assert metric["value"] is None and metric["denominator"] == 2 and metric["missing"] == 1
    assert metric["missing_outcome_bounds"] == [0, .5]
    assert r["status"] == "incomplete_saved_outcomes"
    assert all(p["effects"]["asr"]["S_benefit_percentage_points"] is None for p in r["paired_comparisons"])
    assert "Pending (1/2 judged)" in c.markdown(r)


def test_genuine_refusals_are_scored_but_their_benign_utility_loss_is_visible():
    spec, rows = fixture()
    q = next(r for r in rows if r["arm"] == "S" and r["probe_id"] == "probe-6")
    q.update(answer_status="refused", outcome=False, answer_hash=digest("I cannot answer."))
    result = c.analyse(spec, rows, resamples=20)
    arm = result["regimes"]["regime-0"]["S"]
    assert arm["coverage"]["refused"] == 1 and arm["metrics"]["source_qa"]["value"] == 0
    pair = next(p for p in result["paired_comparisons"] if p["comparator"] == "C")
    assert pair["effects"]["asr"]["S_benefit_percentage_points"] == 50
    assert pair["point_utility_constraints"]["source_qa"] is False
    assert pair["utility_noninferiority_established"] is False


@pytest.mark.parametrize("field,value", [
    ("model", "other-model"), ("question_hash", digest("different question")),
    ("reference_hash", digest("easier target")), ("memory_input_hash", digest("different order")),
    ("initial_memory_hash", digest("different native graph")), ("policy_hash", digest("test-tuned policy")),
    ("available_feedback_hash", digest("future feedback")), ("audit_tickets", 6),
    ("equivalent_verification", {"calls": 1, "input_tokens": 200, "output_tokens": 30, "usd": "0.01"}),
    ("outcome", 1), ("answer_hash", None), ("judge_hash", None),
])
def test_unmatched_models_questions_memory_policies_and_verification_are_rejected(field, value):
    spec, rows = fixture()
    row = next(r for r in rows if r["arm"] == "S")
    row[field] = value
    with pytest.raises(LedgerError):
        c.analyse(spec, rows, resamples=20)


def test_errors_cannot_be_scored_false_and_duplicate_cache_replays_are_not_new_cases():
    spec, rows = fixture()
    rows.append(copy.deepcopy(rows[0]))
    with pytest.raises(LedgerError, match="Duplicate outcome"):
        c.analyse(spec, rows, resamples=20)
    spec, rows = fixture()
    rows[0].update(answer_status="runtime_error", answer_hash=None)
    with pytest.raises(LedgerError, match="Failure masquerades"):
        c.analyse(spec, rows, resamples=20)


def test_unannotated_benign_inputs_do_not_acquire_general_task_accuracy():
    spec, rows = fixture()
    unscored = next(r for r in rows if r["probe_id"] == "probe-7")
    unscored.update(judge_status="complete", judge_hash=digest("invented label"), outcome=True)
    with pytest.raises(LedgerError, match="Invented task correctness"):
        c.analyse(spec, rows, resamples=20)


def test_regime_replicas_are_one_group_and_paired_bootstrap_is_deterministic():
    spec, rows = fixture(groups=1, regimes=3)
    one = c.analyse(spec, rows, resamples=100)
    assert one["independent_base_groups"] == 1
    assert all(p["effects"]["asr"]["pointwise_cluster_bootstrap_95_pp"] is None
               and p["effects"]["asr"]["interval_unavailable_reason"] == "one_independent_group"
               for p in one["paired_comparisons"])
    spec, rows = fixture(groups=2, regimes=3)
    for r in rows:
        if r["episode_id"].startswith("episode-1-") and r["arm"] == "S" and r["probe_id"] == "probe-0":
            r["outcome"] = True
    two = c.analyse(spec, rows, resamples=200, seed=17)
    assert two == c.analyse(spec, list(reversed(rows)), resamples=200, seed=17)
    pairs = [p for p in two["paired_comparisons"] if p["comparator"] == "C"]
    assert all(p["effects"]["asr"]["S_benefit_percentage_points"] == 25 for p in pairs)
    assert all(p["effects"]["asr"]["pointwise_cluster_bootstrap_95_pp"] == [0, 50] for p in pairs)
    assert two["bootstrap"]["multiplicity_adjusted"] is False


@pytest.mark.parametrize("field", ["input_ids", "template_group_ids"])
def test_reused_inputs_and_templates_cannot_be_counted_as_independent_bags(field):
    spec, rows = fixture(groups=2)
    spec["cells"][1][field][0] = spec["cells"][0][field][0]
    with pytest.raises(LedgerError, match="overlap across independent"):
        c.analyse(spec, rows, resamples=20)


def test_zero_denominator_does_not_become_zero_risk_or_perfect_retention():
    spec, rows = fixture()
    removed = spec["cells"][0]["probes"].pop(2)["probe_id"]
    rows = [r for r in rows if r["probe_id"] != removed]
    result = c.analyse(spec, rows, resamples=20)
    retention = result["regimes"]["regime-0"]["S"]["metrics"]["retention"]
    assert retention["value"] is None and retention["denominator"] == 0
    assert all(p["point_utility_constraints"]["retention"] is None for p in result["paired_comparisons"])
    assert "N/A (0)" in c.markdown(result)


def test_prepare_uses_existing_frozen_cases_without_promoting_ai_labels(tmp_path):
    build_frozen(tmp_path)
    frozen, plan = tmp_path/"frozen", tmp_path/"analysis"
    result = c.prepare(frozen, tmp_path/"prepared/private/evaluator_case_index.jsonl", "g0", plan)
    assert result["cells"] == 3 and result["execution_enabled"] is False
    spec = c.load_plan(plan)
    assert spec["basis"] == "AI_exploratory"
    case_index = {r["contribution_id"]: r for r in map(json.loads,
        (tmp_path/"prepared/private/evaluator_case_index.jsonl").open())}
    for cell in spec["cells"]:
        assert len(cell["input_ids"]) == 32
        assert sum(p["metric"] != "source_qa" for p in cell["probes"]) == 27
        assert all(p["metric"] in c.KINDS for p in cell["probes"])
        originals = [p for p in cell["probes"] if p["metric"] != "source_qa"]
        assert sum(p["metric"] == "attack" for p in originals) == sum(
            case_index[p["input_id"]]["Y_case"] for p in originals)
    assert c.analyse(spec, [], resamples=20)["status"] == "incomplete_saved_outcomes"
    missing = tmp_path/"not_frozen"
    with pytest.raises(FileNotFoundError):
        c.prepare(missing, tmp_path/"prepared/private/evaluator_case_index.jsonl", "g0", tmp_path/"forbidden")
    assert not (tmp_path/"forbidden").exists()
    q = frozen/"private/selection.json"
    q.write_text(q.read_text()+" ")
    with pytest.raises(LedgerError, match="dependency changed"):
        c.load_plan(plan)
    with pytest.raises(LedgerError, match="Cohort changed"):
        c.prepare(frozen, tmp_path/"prepared/private/evaluator_case_index.jsonl", "g0", tmp_path/"tampered")
    assert not (tmp_path/"tampered").exists()


def test_saved_outcome_plan_and_inputs_are_fingerprinted_and_outputs_not_overwritten(tmp_path):
    spec, rows = fixture()
    plan = tmp_path/"plan"; plan.mkdir()
    (plan/"study.json").write_text(canonical(spec))
    (plan/"manifest.json").write_text(canonical({"execution_enabled": False,
        "study_sha256": c.sha_file(plan/"study.json"), "dependencies": {}}))
    data = tmp_path/"outcomes.jsonl"
    data.write_text("".join(canonical(row)+"\n" for row in rows))
    out = tmp_path/"report"
    result = c.write_analysis(plan, data, out, resamples=100)
    assert result["paid_API_calls"] == 0 and result["status"] == "complete_saved_outcomes"
    assert "INVENTED TEST FIXTURE" in (out/"comparison.md").read_text()
    before = (out/"comparison.json").read_bytes()
    with pytest.raises(LedgerError, match="overwrite"):
        c.write_analysis(plan, data, out)
    assert (out/"comparison.json").read_bytes() == before
    (plan/"study.json").write_text(canonical({**spec, "execution_enabled": True}))
    with pytest.raises(LedgerError, match="plan changed"):
        c.load_plan(plan)


def test_historical_values_are_separate_and_new_method_cells_stay_pending(tmp_path):
    ready = tmp_path/"readiness.json"
    ready.write_text(canonical({"exploratory_data_ready": False, "human_verified_labels": 0,
        "strata": [{"context": "file_and_doc", "original_case_stratum": "explicit_benign", "shortfall": 1}]}))
    old = tmp_path/"historical.json"
    old.write_text(canonical({"status": "full_validated", "metrics": {
        "asr": {"numerator": 1, "denominator": 4, "percent": 25.0}}}))
    result = c.pending(ready, old, tmp_path/"status")
    assert all(v is None for v in result["new_matched_results"].values())
    assert result["historical_reference"]["asr"]["percent"] == 25
    assert result["human_verified_labels"] == result["paid_API_calls"] == 0
    report = (tmp_path/"status/comparison_status.md").read_text()
    assert "25.00%" in report.split("## New matched comparison")[0]
    assert "25.00%" not in report.split("## New matched comparison")[1]
