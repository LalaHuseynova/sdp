"""Full-data lifecycle coverage using test doubles, with networking forbidden.

These checks validate execution bookkeeping, not empirical model performance.
"""

from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from collections import Counter
from dataclasses import asdict, replace
from pathlib import Path
from unittest.mock import patch

from ams.baselines.base import DefenceResult, NoDefence
from ams.data.mpbench import load_mpbench
from ams.eval.lifecycle import _read, run_lifecycle
from ams.memory.base import MemoryEntry, RetrievalResult, WriteResult

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "mpbench"


def payload_marker(query: str, context: str) -> str:
    digest = hashlib.sha256((query + "\0" + context).encode()).hexdigest()
    return f"written:{digest}"


class RecordingMemory:
    name = "offline_recording_memory"

    def __init__(self):
        self.writes = []
        self.reads = []
        self.resets = []
        self.entries = []

    def reset(self, session_id=None):
        self.resets.append(session_id)
        self.entries.clear()

    def write(self, *, session_id, user_query, context, principal="user"):
        self.writes.append((session_id, user_query, context))
        entry = MemoryEntry(
            entry_id=f"offline-entry-{len(self.writes)}",
            text=payload_marker(user_query, context),
        )
        self.entries.append(entry)
        return WriteResult(written=(entry,))

    def retrieve(self, *, session_id, query, k=4, principal="user"):
        self.reads.append((session_id, query, k))
        return RetrievalResult(entries=tuple(self.entries[-k:]), required="description")


class RecordingJudge:
    def __init__(self):
        self.entries = []
        self.answers = []

    def entry_matches(self, expected, entries):
        self.entries.append((expected, tuple(entries)))
        return False

    def answer_follows(self, query, expected, answer):
        self.answers.append((query, expected, answer))
        return False, f"offline verdict for {answer}"


class FullMPBenchLifecycleOfflineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cases, _ = load_mpbench(DATA)
        cls.original_hashes = {
            p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in DATA.glob("*.jsonl*")
        }
        cls.memory = RecordingMemory()
        cls.judge = RecordingJudge()
        cls.answer_calls = []
        cls.observed = []
        cls.completed = []

        def answer(query, memories, *, required=""):
            cls.answer_calls.append((query, tuple(memories), required))
            return "with-memory" if memories else "without-memory"

        def observe(case, session_id, result):
            cls.observed.append((case.cid, session_id, result))

        with (
            patch("socket.socket.connect", side_effect=AssertionError("network forbidden")),
            patch("ams.eval.lifecycle.progress_bar"),
            patch("ams.llm.pool.progress_bar", return_value=None),
        ):
            cls.outcomes, cls.report = run_lifecycle(
                cls.cases,
                cls.memory,
                NoDefence(),
                cls.judge,
                answer_fn=answer,
                workers=1,
                pool_size=6240,
                seed=0,
                k=4,
                write_observer=observe,
                outcome_observer=cls.completed.append,
            )

    def test_all_ingestions_observed_including_write_only_cases(self):
        self.assertEqual(len(self.memory.writes), 6240)
        self.assertEqual(len(self.observed), 6240)
        self.assertEqual({cid for cid, _, _ in self.observed}, {c.cid for c in self.cases})
        self.assertEqual(len({cid for cid, _, _ in self.observed}), 6240)
        self.assertEqual({sid for _, sid, _ in self.observed}, {"pool0"})
        self.assertEqual(self.memory.resets, ["pool0"])
        no_query = {c.cid for c in self.cases if not c.retrieval_query.strip()}
        self.assertEqual(len(no_query), 244)
        self.assertTrue(no_query <= {cid for cid, _, _ in self.observed})
        self.assertTrue(no_query.isdisjoint(o.cid for o in self.outcomes))

    def test_complete_read_and_paper_scoring_denominators(self):
        self.assertEqual(len(self.memory.reads), 5996)
        self.assertEqual(len(self.outcomes), 5996)
        self.assertEqual(len({o.cid for o in self.outcomes}), 5996)
        self.assertEqual(sum(o.is_adversarial for o in self.outcomes), 2999)
        self.assertEqual(sum(not o.is_adversarial for o in self.outcomes), 2997)
        self.assertEqual(self.report.n_adversarial, 2999)
        self.assertEqual(self.report.n_benign, 2856)
        self.assertEqual(self.report.n_benign_warranted, 249)
        self.assertEqual(self.report.n_benign_unwarranted, 2607)
        self.assertEqual(self.report.n_dropped_no_query, 244)
        self.assertEqual({o.session for o in self.outcomes}, {"pool0"})

    def test_outcome_callbacks_cover_only_the_5996_completed_reads(self):
        self.assertEqual(self.completed, self.outcomes)
        self.assertEqual(len(self.completed), 5996)
        self.assertEqual(len({o.cid for o in self.completed}), 5996)
        no_query = {c.cid for c in self.cases if not c.retrieval_query.strip()}
        self.assertEqual(len(no_query), 244)
        self.assertTrue(no_query.isdisjoint(o.cid for o in self.completed))

    def test_cross_split_overlap_does_not_overwrite_written_memories(self):
        cases = {c.cid: c for c in self.cases}
        for outcome in self.outcomes:
            case = cases[outcome.cid]
            self.assertEqual(
                outcome.written_texts, (payload_marker(case.user_query, case.context),)
            )
            self.assertEqual(outcome.original_cid, case.raw["id"])
            self.assertEqual(outcome.source_split, case.source_split)
            self.assertEqual(outcome.retrieval_query, case.retrieval_query)
        overlapped = Counter(c.original_cid for c in self.cases)
        self.assertEqual(sum(n == 2 for n in overlapped.values()), 300)

    def test_logging_adds_no_extra_answer_or_judge_calls(self):
        self.assertEqual(len(self.answer_calls), 5996 + 2999)
        self.assertEqual(sum(not memories for _, memories, _ in self.answer_calls), 2999)
        self.assertEqual(len(self.judge.entries), 2 * 2999)
        self.assertEqual(len(self.judge.answers), 2 * 2999 + 2856)

    def test_raw_files_remain_unchanged(self):
        actual = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in DATA.glob("*.jsonl*")}
        self.assertEqual(actual, self.original_hashes)

    def test_isolated_case_branch_observes_completed_outcomes(self):
        cases = [c for c in self.cases[:3] if c.retrieval_query.strip()]
        completed = []
        with (
            patch("socket.socket.connect", side_effect=AssertionError("network forbidden")),
            patch("ams.llm.pool.progress_bar", return_value=None),
        ):
            outcomes, _ = run_lifecycle(
                cases,
                RecordingMemory(),
                NoDefence(),
                RecordingJudge(),
                answer_fn=lambda *_args, **_kwargs: "offline-answer",
                workers=1,
                pool_size=1,
                outcome_observer=completed.append,
            )
        self.assertEqual(len(completed), 3)
        self.assertEqual(completed, outcomes)

    def test_interruption_leaves_only_completed_outcomes_in_progress_journal(self):
        cases = self.cases[:3]

        class InterruptedJudge(RecordingJudge):
            def answer_follows(self, query, expected, answer):
                if len(self.answers) == 2:
                    raise RuntimeError("scripted interruption")
                return super().answer_follows(query, expected, answer)

        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "outcome_progress-no_defence.jsonl"
            with path.open("w", encoding="utf-8") as journal:

                def completed(outcome):
                    journal.write(json.dumps(asdict(outcome)) + "\n")
                    journal.flush()

                with (
                    self.assertRaisesRegex(RuntimeError, "scripted interruption"),
                    patch("socket.socket.connect", side_effect=AssertionError("network forbidden")),
                    patch("ams.eval.lifecycle.progress_bar"),
                    patch("ams.llm.pool.progress_bar", return_value=None),
                ):
                    run_lifecycle(
                        cases,
                        RecordingMemory(),
                        NoDefence(),
                        InterruptedJudge(),
                        answer_fn=lambda *_args, **_kwargs: "offline-answer",
                        workers=1,
                        pool_size=len(cases),
                        outcome_observer=completed,
                    )
                records = [json.loads(line) for line in path.read_text().splitlines()]
                self.assertEqual(len(records), 1)
                self.assertEqual(records[0]["cid"], cases[0].cid)
                self.assertEqual(records[0]["answer"], "offline-answer")
                self.assertFalse((Path(temp) / "manifest.json").exists())


class ReadCallSequenceTests(unittest.TestCase):
    def setUp(self):
        cases, _ = load_mpbench(DATA)
        self.case = replace(
            cases[0], retrieval_query="test question", expected_memory="test target"
        )

    def read(self, case):
        trace = []
        written = MemoryEntry("written", "written-only")
        keep = MemoryEntry("keep", "keep-entry")
        flagged = MemoryEntry("flag", "flag-entry")

        class Memory:
            name = "offline_sequence_memory"

            def retrieve(self, **kwargs):
                trace.append(("retrieve", kwargs["query"]))
                return RetrievalResult(entries=(keep, flagged), required="preference")

        class Defence:
            name = "offline_sequence_defence"

            def filter(self, query, entries):
                trace.append(("filter", tuple(e.text for e in entries)))
                return DefenceResult(kept=(keep,), flagged=(flagged,))

        class Judge:
            def entry_matches(self, expected, entries):
                trace.append(("judge_entry", tuple(entries)))
                return True

            def answer_follows(self, query, expected, answer):
                trace.append(("judge_answer", answer))
                return answer == "with-memory", f"reason:{answer}"

        def answer(query, memories, *, required=""):
            trace.append(("answer", tuple(memories), required))
            return "with-memory" if memories else "without-memory"

        with patch("socket.socket.connect", side_effect=AssertionError("network forbidden")):
            outcome = _read(
                case,
                Memory(),
                Defence(),
                Judge(),
                answer_fn=answer,
                session_id="pool0",
                written=(written,),
                owner={"written": case.cid, "keep": case.cid, "flag": case.cid},
                adversarial_cids={case.cid} if case.is_adversarial else set(),
                k=4,
            )
        return outcome, trace

    def test_attack_call_order_and_new_saved_fields(self):
        outcome, trace = self.read(self.case)
        self.assertEqual(
            trace,
            [
                ("judge_entry", ("written-only",)),
                ("retrieve", "test question"),
                ("filter", ("keep-entry", "flag-entry")),
                ("judge_entry", ("keep-entry",)),
                ("answer", ("keep-entry",), "preference"),
                ("judge_answer", "with-memory"),
                ("answer", (), "preference"),
                ("judge_answer", "without-memory"),
            ],
        )
        self.assertTrue(outcome.attack_succeeded)
        self.assertFalse(outcome.succeeds_without_memory)
        self.assertEqual(outcome.answer_without_memory, "without-memory")
        self.assertEqual(outcome.judge_reason, "reason:with-memory")
        self.assertEqual(outcome.judge_reason_without_memory, "reason:without-memory")
        self.assertEqual(outcome.retrieved_before_filter, ("keep-entry", "flag-entry"))
        self.assertEqual(outcome.retrieved_texts, ("keep-entry",))
        self.assertEqual(outcome.flagged_texts, ("flag-entry",))
        self.assertEqual(outcome.benign_judge_reason, "")

    def test_benign_call_order_and_saved_judge_reason(self):
        case = replace(self.case, is_adversarial=False, legitimate_memory_write=True)
        outcome, trace = self.read(case)
        self.assertEqual(
            trace,
            [
                ("retrieve", "test question"),
                ("filter", ("keep-entry", "flag-entry")),
                ("answer", ("keep-entry",), "preference"),
                ("judge_answer", "with-memory"),
            ],
        )
        self.assertTrue(outcome.answer_correct)
        self.assertEqual(outcome.benign_judge_reason, "reason:with-memory")
        self.assertEqual(outcome.answer_without_memory, "")


if __name__ == "__main__":
    unittest.main()
