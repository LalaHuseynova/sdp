"""Missing-item review checks: invented records and mock HTTP, no paid requests."""

from __future__ import annotations

import copy
import json
import socket
from pathlib import Path
from types import SimpleNamespace

import httpx
import pytest

from ams.research.dynamic.models import LedgerError, digest
from ams.research.llm_followup.analysis import analyse
from ams.research.llm_followup.pipeline import FollowupSession, decode, run
from ams.research.llm_followup.plan import prepare, verify
from ams.research.llm_review.batches import finish as finish_parent
from ams.research.llm_review.batches import prepare as prepare_batches
from ams.research.llm_review.batches import verify as verify_batches
from test_llm_review import completion
from test_llm_review import plan as parent_plan  # noqa: F401


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def deny(*args, **kwargs):
        raise AssertionError("Follow-up tests permit mock HTTP only")

    monkeypatch.setattr(socket.socket, "connect", deny)
    monkeypatch.setattr(socket.socket, "connect_ex", deny)
    monkeypatch.setattr(socket, "create_connection", deny)
    monkeypatch.setattr(socket, "getaddrinfo", deny)


@pytest.fixture
def followup(request):
    first, _cfg, _jobs, _info = request.getfixturevalue("parent_plan")
    parent = first.parent / "batches"
    prepare_batches(first, parent)
    cfg, jobs = verify_batches(parent)
    directory = parent / "responses"
    directory.mkdir()
    replies = []
    for i, j in enumerate(jobs):
        ref = next(k for k, s in j["references"]["sources"].items() if s["role"] == "external")
        body = {
            "records": [
                {
                    "id": "m0",
                    "verdict": "safe_for_use",
                    "origin": "external",
                    "sources": [ref],
                    "evidence": [],
                    "reason": "Invented test source support.",
                }
            ],
            "questions": [],
        }
        if i < 2:
            body["records"][0]["sources"] = ["s9999"]
        r = {
            "response": {"text": json.dumps(body), "raw_finish_reason": "stop"},
            "error": None,
            "actual_paid_usd": "0",
        }
        replies.append(r)
        (directory / (j["call_id"] + ".json")).write_text(json.dumps(r))
    finish_parent(parent, cfg, jobs, replies, SimpleNamespace(summary=lambda: {"budget": {}}))
    out = first.parent / "followup"
    prepare(parent, out)
    cfg, jobs = verify(out)
    return out, cfg, jobs, parent


def good_body():
    return {
        "verdict": "safe_for_use",
        "origin": "external",
        "source_units": [1],
        "evidence_units": [],
        "reason": "Supported descriptive use in invented fixture.",
    }


def test_only_missing_items_are_frozen_and_blinded(followup):
    out, cfg, jobs, _parent = followup
    assert len(jobs) == 2 and cfg["accepted_parent_batches_reused"] == 30
    assert cfg["review_task_reservation_ceiling_usd"] == "0.0531456"
    for j in jobs:
        body = json.loads(j["request"]["messages"][1]["content"])
        assert "expected_memory" not in str(body) and "HIDDEN_TARGET" not in str(body)
        assert "previous_verdict" not in body and "s9999" not in str(body)
    with pytest.raises(LedgerError):
        prepare(out.parent / "batches", out)


@pytest.mark.parametrize(
    "mutation", ["negative", "boolean", "large", "duplicate", "role", "unsafe", "human"]
)
def test_invalid_items_remain_rejected(followup, mutation):
    _out, _cfg, jobs, _parent = followup
    body = good_body()
    if mutation == "negative":
        body["source_units"] = [-1]
    elif mutation == "boolean":
        body["source_units"] = [True]
    elif mutation == "large":
        body["source_units"] = [999]
    elif mutation == "duplicate":
        body["source_units"] = [1, 1]
    elif mutation == "role":
        body["origin"] = "principal"
    elif mutation == "unsafe":
        body["verdict"] = "unsafe"
    else:
        body["human_validated"] = True
    with pytest.raises(LedgerError):
        decode(jobs[0], {"text": json.dumps(body), "raw_finish_reason": "stop"})


def test_safe_uncertain_and_supported_unsafe_are_not_relabelled(followup):
    _out, _cfg, jobs, _parent = followup
    for verdict in ("safe_for_use", "unsafe", "uncertain"):
        body = {**good_body(), "verdict": verdict}
        if verdict == "unsafe":
            body["evidence_units"] = [0]
        p = decode(jobs[0], {"text": json.dumps(body), "raw_finish_reason": "stop"})
        assert p["records"][0]["verdict"] == verdict
        assert p["whole_bundle_complete"] is False
        assert p["eligible_as_gold"] is False and p["can_update_live_trust"] is False


def test_question_uncertainty_and_wrong_types(followup):
    _out, _cfg, jobs, _parent = followup
    j = copy.deepcopy(jobs[0])
    q = {
        "candidate_id": "q",
        "question": "What color is stated?",
        "answers": ["blue"],
        "support_record_id": "r",
        "support_artifact_id": "external",
        "quote": "The planning color is blue.",
    }
    data = json.loads(j["request"]["messages"][1]["content"])
    data.update(record=None, question=q, record_evidence_units=[])
    j.update(kind="question", record_versions={}, candidate_versions={"q": digest(q)})
    j["request"]["messages"][1]["content"] = json.dumps(data)
    j["validation_view"].update(records=[], questions=[q])
    p = decode(
        j,
        {
            "text": json.dumps(
                {"checks": [True, None, False, True, True], "reason": "Question needs checking."}
            ),
            "raw_finish_reason": "stop",
        },
    )
    assert p["questions"][0]["question_clear"] is None
    with pytest.raises(LedgerError):
        decode(
            j,
            {
                "text": json.dumps({"checks": [1] * 5, "reason": "Invalid test."}),
                "raw_finish_reason": "stop",
            },
        )


def test_shared_budget_merge_idempotency_and_offline_analysis(followup):
    out, cfg, jobs, _parent = followup
    seen = []

    def handler(request):
        seen.append(json.loads(request.content))
        return completion(good_body())

    result = run(out, httpx.MockTransport(handler))
    assert len(seen) == len(jobs) == 2
    assert result["mechanically_valid_record_proposals"] == 32
    assert result["complete_automated_bundles"] == 32
    assert result["human_verified_labels"] == 0 and result["defense_ASR"] == "not_measured"
    assert result["followup_actual_cost_usd"] == "0"  # Mock only.
    assert result["shared_project_budget"]["limit_usd"] == 30
    with FollowupSession(Path(cfg["session_directory"])) as session:
        before = session.guard.snapshot()["used_nanodollars"]
        session.authorize(out)
        assert session.complete_review(jobs[0])["response"]
        assert session.guard.snapshot()["used_nanodollars"] == before
        with pytest.raises(ValueError):
            session.complete("not-annotation", "answer", None)
    assert run(out, httpx.MockTransport(handler)) == result and len(seen) == 2
    prepared = out.parent / "prepared"
    private = prepared / "private"
    rows = [
        {
            "contribution_id": f"p_{n}",
            "context_id": "email" if n < 16 else "file_and_doc",
            "stratum": "attack" if n % 2 else "suggestive_benign",
        }
        for n in range(32)
    ]
    (private / "evaluator_case_index.jsonl").write_text("".join(json.dumps(r) + "\n" for r in rows))
    analysis = analyse(out, prepared, out.parent / "analysis")
    assert analysis["exploratory_label_and_QA_quotas_satisfied"] is False
    assert analysis["independent_quality_sample_inputs"] == 8
    assert analysis["independent_quality_sample_completed"] == 0
    assert analysis["accuracy_FPR_FNR_ASR"] == "not_measured"
    assert analysis["automatic_execution_unlock"] is False
