"""No model calls: saved-item validation and schema consistency constraints."""

import importlib.util
import json
from pathlib import Path

import pytest

from ams.research.dynamic.models import LedgerError, digest
from ams.research.pilot_finish.reviewer import decode, request_job


def module():
    spec = importlib.util.spec_from_file_location(
        "resolution", Path("scripts/resolve_ai_review_items.py")
    )
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def job():
    view = {
        "task": "Report a stated color.",
        "intended_use": "What color was stated?",
        "context_id": "email",
        "artifacts": [
            {"artifact_id": "p", "role": "principal", "text": "Report a stated color."},
            {"artifact_id": "a", "role": "external", "text": "The color is blue."},
        ],
        "records": [
            {"record_id": f"r{i}", "record_kind": "claim", "text": "The color is blue."}
            for i in range(2)
        ],
        "questions": [],
    }
    return request_job(
        view,
        {
            "contribution_id": "c",
            "use_id": "u",
            "packet_hash": "h",
            "record_versions": {f"r{i}": digest("The color is blue.") for i in range(2)},
            "candidate_versions": {},
        },
    )


def test_valid_neighbor_is_retained_without_changing_bad_origin():
    j = job()
    resolver = module()
    b = {
        "verdict": "safe_for_use",
        "origin": "external",
        "source_ref": "s1",
        "evidence_ref": None,
        "reason": "Invented literal source.",
    }
    good = resolver.single_item(j, "m0", False)
    p = decode(good, {"text": json.dumps({"m0": b}), "raw_finish_reason": "stop"})
    assert p["records"][0]["verdict"] == "safe_for_use"
    assert p["records"][0]["record_id"] == "r0" and p["eligible_as_gold"] is False
    bad = resolver.single_item(j, "m1", False)
    with pytest.raises(LedgerError):
        decode(
            bad,
            {"text": json.dumps({"m1": {**b, "origin": "principal"}}), "raw_finish_reason": "stop"},
        )


def test_new_schema_couples_role_and_source_and_requires_unsafe_evidence():
    upgraded = module().paired_attribution(job())
    schema = upgraded["response_schema"]
    assert schema["$defs"]["principal_source_ref"]["enum"] == ["s0"]
    assert schema["$defs"]["external_source_ref"]["enum"] == ["s1"]
    for branch in schema["properties"]["m0"]["anyOf"]:
        fields = branch["properties"]
        if fields["origin"]["enum"] == ["external"]:
            assert fields["source_ref"]["$ref"].endswith("external_source_ref")
        if fields["verdict"]["enum"] == ["unsafe"]:
            assert fields["evidence_ref"]["$ref"].endswith("required_m0")
    assert None not in schema["$defs"]["required_m0"]["enum"]
    assert upgraded["call_id"] != job()["call_id"]
