"""Offline Step 11 planning checks; never create actual reviews or execute a pilot."""

from __future__ import annotations

import json
import socket
import subprocess
import sys
from decimal import Decimal
from pathlib import Path

import pytest

from ams.research.dynamic.models import LedgerError
from ams.research.planning.costs import counts, estimate, money, price_snapshot
from ams.research.planning.pipeline import (
    assess_readiness,
    prepare,
    require_scientific_freeze,
    review_status,
    verify,
)
from ams.research.planning.study import CONFIG_HASH, inventory, validate_config
from ams.research.recovery.offline import no_network

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "configs/research/dynamic_pilot_v1.json"
PRICING = ROOT / "configs/research/dynamic_pricing_20261030.json"
PREPARED = ROOT / "research_data/mpbench_provisional_v1_20261029"


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def deny(*args, **kwargs):
        raise AssertionError("Planning cannot access providers or download models")

    monkeypatch.setattr(socket.socket, "connect", deny)
    monkeypatch.setattr(socket.socket, "connect_ex", deny)
    monkeypatch.setattr(socket, "create_connection", deny)
    monkeypatch.setattr(socket, "getaddrinfo", deny)


@pytest.fixture
def settings():
    return json.loads(CONFIG.read_text())


@pytest.fixture
def pricing():
    return json.loads(PRICING.read_text())


@pytest.fixture(scope="module")
def bundle(tmp_path_factory):
    out = tmp_path_factory.mktemp("planning") / "bundle"
    with no_network():
        report = prepare(PREPARED, CONFIG, PRICING, out)
    return out, report


def test_protocol_primary_and_development_counts_are_not_confused(settings):
    lo = counts(12, settings, 12, 15)
    hi = counts(12, settings, 16, 19)
    assert lo["trajectories"] == 144 and lo["original_questions"] == 3888
    assert lo["grounded_questions"] == 1728 and hi["grounded_questions"] == 2304
    assert lo["memory_answers"] == 5616 and hi["memory_answers"] == 6192
    assert lo["no_memory_answers"] == 432
    assert lo["logical_audit_tickets_all_arms"] == 720
    assert lo["shared_audit_jobs"] == lo["logical_audit_tickets_per_arm"] == 180
    assert counts(8, settings, 16, 19)["trajectories"] == 96
    assert counts(20, settings, 16, 19)["memory_answers"] == 10320


def test_costs_cover_all_required_stages_and_keep_oracle_and_human_cost_separate(settings, pricing):
    result = estimate(settings, pricing)
    high = result["scopes"]["all_selected"]["working_high"]
    stages = {r["stage"]: r for r in high["stages"]}
    assert stages["memory_answers"]["cold_logical_calls_budgeted"] == 10320
    assert stages["no_memory_answers"]["cold_logical_calls_budgeted"] == 720
    assert stages["classifier_response_catalog"]["cold_logical_calls_budgeted"] == 960
    assert stages["original_answer_judgments"]["cold_logical_calls_budgeted"] == 6480
    assert stages["retrieved_entry_judgments"]["cold_logical_calls_budgeted"] == 4560
    assert stages["written_entry_judgments"]["cold_logical_calls_budgeted"] == 400
    assert stages["no_memory_attack_judgments"]["cold_logical_calls_budgeted"] == 400
    assert result["zero_paid_stages"]["oracle_verification"].startswith("preannotated")
    assert "human_annotation_labor" in result["unknown_costs"]
    assert not result["cap_activated"] and not result["measured_token_estimate"]


def test_decimal_costs_retry_headroom_and_full_context_bound_are_explicit(settings, pricing):
    result = estimate(settings, pricing)
    total = result["scopes"]["all_selected"]
    assert total["working_low"]["with_retries_usd"] == "13.309776"
    assert total["working_high"]["with_retries_usd"] == "14.813828"
    assert total["stress"]["with_headroom_usd"] == "106.224600"
    assert total["stress"]["counts"]["conflict_checks"] == 61920
    assert sum(s["max_physical_attempts"] for s in total["stress"]["stages"]) == 171520
    assert Decimal(total["stress"]["full_context_all_attempts_reservation_usd"]) > Decimal("125")
    assert total["stress"]["proposed_cap_covers_this_scenario"]
    assert not total["stress"]["completion_within_cap_guaranteed"]


@pytest.mark.parametrize("value", [True, "NaN", "Infinity", "-1", "not-money"])
def test_invalid_money_never_becomes_free(value):
    with pytest.raises(LedgerError):
        money(value)


@pytest.mark.parametrize(
    "change",
    [
        {"model": "unknown-model"},
        {"provider": "unknown"},
        {"input_usd_per_million": "0"},
        {"output_usd_per_million": "nan"},
    ],
)
def test_unknown_or_unpriced_model_fails_closed(pricing, change):
    with pytest.raises(LedgerError):
        price_snapshot({**pricing, **change})


@pytest.mark.parametrize(
    "field,value",
    [
        ("locked_bags", 11),
        ("chat_model", "different-model"),
        ("execution_enabled", True),
        ("audits_per_trajectory", 10),
        ("bootstrap_resamples", 99),
    ],
)
def test_unannounced_design_or_execution_changes_are_rejected(settings, field, value):
    with pytest.raises(LedgerError, match="amended"):
        validate_config({**settings, field: value})


def test_inventory_is_a_frozen_template_not_a_false_dataset_lock(settings):
    result = inventory(settings)
    assert result["engineering_settings_frozen"] and not result["scientific_dataset_frozen"]
    assert len(result["grid_slots"]) == 240
    assert sum(r["split_intent"] == "locked_pilot" for r in result["grid_slots"]) == 144
    assert all(row["selected_case_ids"] is None for row in result["grid_slots"])
    assert result["required_independently_safe_contributions"] == 320
    assert result["required_independently_unsafe_contributions"] == 320
    assert result["required_validated_grounded_questions"] == 320
    assert result["policies"]["R"]["weight"] == 0
    assert result["policies"]["S"]["threshold"] == 0.25
    assert result["policies"]["S"]["weight"] == 0.5
    assert {r["Y_case"] for r in result["required_per_bag_per_context"]} == {
        "adversarial",
        "benign",
    }
    assert {r["case_stratum"] for r in result["required_per_bag_per_context"]} == {
        "attack",
        "explicit_benign",
        "suggestive_benign",
    }


def test_preparation_uses_actual_review_forms_and_preserves_existing_data(bundle):
    out, report = bundle
    assert report["status"] == "engineering_freeze_only_not_scientific_lock"
    assert report["settings_hash"] == CONFIG_HASH
    assert report["review_coverage"]["independently_verified_bundles"] == 0
    assert report["review_coverage"]["human_validated_qa"] == 0
    assert report["review_coverage"]["missing_two_safety_reviews"] == 2114
    assert report["existing_provisional_validation"]["overlays_checked"] == 120
    assert report["paid_cost_usd"] == 0
    assert not report["readiness"]["scientific_pilot_ready"]
    result = verify(out)
    assert result["status"] == "passed" and not result["paid_dispatch_enabled"]


def test_counts_or_provisional_status_do_not_unlock_scientific_execution():
    status = {
        "verified_bundle_labels": {"safe_for_use": 320, "unsafe": 320},
        "safe_source_validated_qa": 320,
    }
    ready = assess_readiness(status)
    assert not ready["scientific_pilot_ready"] and not ready["paid_dispatch_enabled"]
    assert "validated_Z_balanced_group_manifests_not_created_or_frozen" in ready["blockers"]


def test_scientific_freeze_command_explains_blockers_and_cannot_launch(bundle):
    out, _ = bundle
    with pytest.raises(LedgerError, match="Scientific freeze unavailable"):
        require_scientific_freeze(out)
    proc = subprocess.run(
        [
            sys.executable,
            str(ROOT / "scripts/prepare_dynamic_pilot.py"),
            "require-scientific-freeze",
            "--bundle",
            str(out),
        ],
        capture_output=True,
        text=True,
    )
    assert proc.returncode == 2 and "independent_safety" in proc.stdout
    assert not list(out.glob("*.sqlite"))


def test_modified_planning_payload_is_not_accepted(bundle, tmp_path):
    import shutil

    out, _ = bundle
    copy = tmp_path / "copy"
    shutil.copytree(out, copy)
    (copy / "settings.json").write_text("{}")
    with pytest.raises(LedgerError, match="payload modified"):
        verify(copy)


def test_existing_plan_is_never_overwritten(bundle):
    out, _ = bundle
    with pytest.raises(LedgerError, match="overwrite"):
        prepare(PREPARED, CONFIG, PRICING, out)


def test_missing_review_files_are_not_completed_reviews(tmp_path):
    # An empty packet universe is just a unit fixture, not a new human-review output.
    prepared = tmp_path / "prepared"
    (prepared / "private").mkdir(parents=True)
    (prepared / "private/review_packets.jsonl").write_text("")
    (prepared / "private/question_drafts.jsonl").write_text("")
    status, inputs = review_status(prepared, tmp_path / "missing-reviews")
    assert status["independently_verified_bundles"] == 0
    assert any(value is None for value in inputs.values())


def test_no_execution_argument_or_credential_side_effect_is_available(tmp_path):
    proc = subprocess.run(
        [
            sys.executable,
            str(ROOT / "scripts/prepare_dynamic_pilot.py"),
            "prepare",
            "--out",
            str(tmp_path / "must-not-exist"),
            "--execute",
        ],
        capture_output=True,
        text=True,
    )
    assert proc.returncode == 2
    assert not (tmp_path / "must-not-exist").exists()


def test_reported_rates_are_source_linked_and_model_specific(pricing):
    assert price_snapshot(pricing) == (Decimal("0.15"), Decimal("0.60"))
    assert pricing["model_page"].startswith("https://openrouter.ai/openai/gpt-4o-mini")
    assert pricing["recheck_before_paid_execution"]
