"""Whitespace equivalence cannot delete negation, change units or paraphrase facts."""

import importlib.util


def module():
    spec = importlib.util.spec_from_file_location(
        "formatting", "scripts/recover_ai_question_formatting.py"
    )
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def test_narrow_space_support_keeps_exact_original_offsets():
    source = "Revenue: $12.4\u202fmillion, up 8.2%."
    span = module().find_normalized(source, "$12.4 million")
    assert source[span[0] : span[1]] == "$12.4\u202fmillion"


def test_support_does_not_change_value_unit_negation_or_word_boundaries():
    f = module().find_normalized
    assert f("Revenue: $12.4 million", "$12.5 million") is None
    assert f("Revenue: $12.4 million", "$12.4 billion") is None
    assert f("Do not approve the plan", "Do approve the plan") is None
    assert f("A notable finding", "not able") is None
