"""Mock-transport/artificial fixtures only; never human reviews or real results."""

import copy
import json

import httpx
import pytest

from ams.research import comparison
from ams.research.dynamic import Policy
from ams.research.dynamic.models import LedgerError, digest, event_dict
from ams.research.execution.session import ExecutionSession, new_json
from ams.research.native.pipeline import write_gzip
from ams.research.provisional_run import preparation as p
from ams.research.provisional_run import runner as r
from ams.research.provisional_run.transport import ProvisionalSession
from ams.research.sequential.state import RuntimeState
from test_dynamic_execution import reply, req
from test_dynamic_native import build as build_native
from test_dynamic_native import example, offline  # noqa: F401


def context(example):  # noqa: F811
    snapshot, crosswalk = build_native(example)
    state = RuntimeState.load(snapshot)
    source = example["source"]
    packet = {**source, "use_id": "use_fixture", "intended_use": example["query"], "records": []}
    artifacts = {a["artifact_id"]: a for a in source["artifacts"]}
    links = {link["record_id"]: link for link in crosswalk["record_links"]}
    records = {}
    for b in state.bindings.records:
        artifact = artifacts[links[b.record_id]["structural_artifact_id"]]
        records[b.record_id] = {
            "record_id": b.record_id,
            "content_hash": b.content_hash,
            "origin": "principal" if b.origin_class == "principal" else "external",
            "source_spans": [
                {
                    "artifact_id": artifact["artifact_id"],
                    "start": 0,
                    "end": len(artifact["text"]),
                    "quote": artifact["text"],
                }
            ],
            "verdict": "safe_for_use",
            "source_identity_authenticated": False,
            "evidence_quote": "",
        }
    overlay = {
        source["contribution_id"]: {
            "context_id": "email",
            "batch_id": "batch_fixture",
            "contributor_id": "contributor_fixture",
        }
    }
    return state, crosswalk, {source["contribution_id"]: packet}, records, overlay


def fixture_plan(tmp_path, example):  # noqa: F811
    state, crosswalk, packets, records, overlay = context(example)
    p.initialize(state, crosswalk, packets, records, overlay, bytes(range(32)))
    pid = example["source"]["contribution_id"]
    calls = {rid: "fixture_saved_review" for rid in records}
    receipts = {
        "fixture_saved_review": {
            "usage": {"input_tokens": 10, "output_tokens": 5},
            "receipt": {"actual_nanodollars": 123000},
        }
    }
    jobs = [{"contribution_id": pid, "ticket_id": f"t{i}"} for i in range(5)]
    audits, details = p.audits_for(state, jobs, {pid: pid}, packets, records, calls, receipts)
    root = tmp_path / "plan"
    root.mkdir()
    (root / "private").mkdir()
    session = tmp_path / "session"
    with ExecutionSession.create(session, plan_hash="artificial") as s:
        session_id = s.config["session_id"]
    cells = []
    for scenario in ["strong_localized", "strong_distributed", "uninformative"]:
        eid = "ep_" + scenario
        q = {
            "query_id": "q_fixture",
            "text": example["query"],
            "input_id": pid,
            "use_id": "use_fixture",
            "expected_memory": "a fictitious target",
            "metric": "attack",
        }
        episode = {
            "episode_id": eid,
            "session_id": crosswalk["session_id"],
            "queries": [q],
            "audits": [event_dict(a) for a in audits],
            "initial_memory_hash": p.nonpolicy(state.dump()),
            "equivalent_verification": {
                "calls": 5,
                "input_tokens": 50,
                "output_tokens": 25,
                "usd": "0.000615",
            },
        }
        write_gzip(root / "private" / (eid + ".json.gz"), state.dump())
        new_json(root / "private" / (eid + ".json"), episode)
        cells.append(
            {
                "episode_id": eid,
                "group_id": "D00",
                "scenario": scenario,
                "memory_input_hash": "a" * 64,
                "feedback_hash": digest(episode["audits"]),
                "audit_tickets": 5,
                "input_ids": [pid],
                "template_group_ids": ["fixture_component"],
                "probes": [
                    {
                        "probe_id": "q_fixture",
                        "input_id": pid,
                        "metric": "attack",
                        "question_hash": digest(q["text"]),
                        "reference_hash": digest(q["expected_memory"]),
                        "relation": "root_batch",
                    }
                ],
            }
        )
    spec = {
        "schema": comparison.SCHEMA,
        "basis": "test_fixture",
        "model": "openai/gpt-4o-mini",
        "policy_hashes": {a: Policy(a).fingerprint for a in "RCMS"},
        "cells": cells,
        "execution_enabled": False,
    }
    cfg = {
        "schema": p.SCHEMA,
        "basis": p.BASIS,
        "scope": "AI_provisional_comparison",
        "session_id": session_id,
        "session_directory": str(session.resolve()),
        "human_validated": False,
        "scientific_human_validated": False,
        "execution_scope_enabled": True,
        "total_project_limit_usd": "30.00",
        "additional_task_limit_usd": "5.00",
        "budget_start_used_usd": "0",
        "automatic_retries": 0,
    }
    new_json(root / "study.json", spec)
    new_json(root / "settings.json", cfg)
    files = {str(f.relative_to(root)): p.sha_file(f) for f in root.rglob("*") if f.is_file()}
    new_json(
        root / "manifest.json",
        {
            "schema": p.SCHEMA,
            "files": files,
            "hash": digest(files),
            "dependencies": {},
            "scientific_execution_enabled": False,
        },
    )
    return root, session


def test_provenance_binding_ignores_safety_verdicts_and_preserves_principal(example):  # noqa: F811
    state, cw, packets, records, overlay = context(example)
    original = state.dump()
    decisions = p.initialize(state, cw, packets, records, overlay, bytes(range(32)))
    altered = copy.deepcopy(records)
    for value in altered.values():
        value["verdict"] = "unsafe"
    other = RuntimeState.load(original)
    p.initialize(other, cw, packets, altered, overlay, bytes(range(32)))
    assert other.dump() == state.dump()
    assert state.evidence.usage.tickets == 0 and not state.evidence.observations()
    assert any(x["origin_group"] == "principal" for x in decisions)
    assert all(not x["natural_identity_authenticated"] for x in decisions)
    assert all(
        root.contributor_id is None
        for root in state.evidence.roots.values()
        if root.attribution == "principal"
    )


def test_unresolved_claim_origins_do_not_receive_contributor_penalties(example):  # noqa: F811
    state, cw, packets, records, overlay = context(example)
    for b in state.bindings.records:
        if b.origin_class == "ambiguous":
            records[b.record_id].update(origin="ambiguous", source_spans=[])
    decisions = p.initialize(state, cw, packets, records, overlay, bytes(range(32)))
    assert sum(d["origin_group"] == "unknown" for d in decisions) == 2
    assert all(
        x.contributor_id is None
        for x in state.evidence.roots.values()
        if x.attribution == "unknown"
    )


def test_changed_source_span_fails_before_any_model_call(example):  # noqa: F811
    state, cw, packets, records, overlay = context(example)
    next(iter(records.values()))["source_spans"][0]["quote"] += " invented"
    with pytest.raises(LedgerError, match="provenance span"):
        p.initialize(state, cw, packets, records, overlay, bytes(range(32)))


def test_exact_request_sharing_scope_limit_and_forbidden_fallback(tmp_path, example):  # noqa: F811
    plan, path = fixture_plan(tmp_path, example)
    seen = []

    def handler(request):
        seen.append(json.loads(request.content))
        return reply(text="Fixture answer")

    with ProvisionalSession(path) as s:
        s.arm_provisional_mock(plan, httpx.MockTransport(handler))
        first = s.dispatch("answer", req())
        assert s.dispatch("answer", req()) == first and len(seen) == 1
        assert seen[0]["provider"]["max_price"] == {
            "prompt": 0.15,
            "completion": 0.60,
            "request": 0,
        }
        with pytest.raises(LedgerError, match="stage"):
            s.dispatch("classifier_catalog", req(max_tokens=24))
        with pytest.raises(ValueError, match="scope-bound"):
            s.complete("x", "answer", req())
        with pytest.raises(ValueError, match="scientific execution"):
            s.arm_live(scientific_plan=plan, api_key="not-a-key")
        s.scope["additional_task_limit_usd"] = "0.001"
        with pytest.raises(LedgerError, match="USD 5"):
            s.dispatch("answer", req(messages=(r.Message("user", "another fixture"),)))
    assert len(seen) == 1


def test_unknown_billing_halts_and_cannot_be_retried(tmp_path, example):  # noqa: F811
    plan, path = fixture_plan(tmp_path, example)
    seen = []

    def handler(request):
        seen.append(request)
        return reply(cost=None)

    with ProvisionalSession(path) as s:
        s.arm_provisional_mock(plan, httpx.MockTransport(handler))
        with pytest.raises(LedgerError, match="Dispatch failed"):
            s.dispatch("answer", req())
        assert s.guard.snapshot()["blocked"] is True
        assert s.guard.snapshot()["held_nanodollars"] > 0
        with pytest.raises(LedgerError):
            s.dispatch("answer", req())
    assert len(seen) == 1


def test_compact_controller_complete_and_restart_have_no_duplicate_charges(tmp_path, example):  # noqa: F811
    plan, path = fixture_plan(tmp_path, example)
    seen = []

    def handler(request):
        body = json.loads(request.content)
        seen.append(body)
        return reply(
            text="NO\nInvented judgment" if body["max_tokens"] == 120 else "Invented answer"
        )

    out = tmp_path / "outcomes"
    result = r.run(plan, out, mock=httpx.MockTransport(handler))
    assert result["status"] == "complete_saved_outcomes" and result["outcomes"] == 18
    calls = len(seen)
    # Same source, question, selected context and response intentionally share
    # exact physical requests across this artificial fixture's methods/regimes.
    assert calls < 18
    second = r.run(plan, out, mock=httpx.MockTransport(handler))
    assert second["status"] == result["status"] and len(seen) == calls
    assert second["costs"]["project_used_usd"] == result["costs"]["project_used_usd"]
    actual = json.loads((out / "comparison.json").read_text())
    assert actual["basis"] == "test_fixture" and actual["scientifically_human_validated"] is False


def test_journal_rejects_divergence_and_modified_outcomes(tmp_path):
    journal = r.Journal(tmp_path / "journal", "fixture-scope")
    try:
        journal.commit("q", {"answer": "first"})
        journal.commit("q", {"answer": "first"})
        with pytest.raises(LedgerError, match="diverged"):
            journal.commit("q", {"answer": "different"})
        journal.db.execute("UPDATE outcomes SET body='{}'")
        with pytest.raises(LedgerError, match="modified"):
            journal.rows()
    finally:
        journal.db.close()


def test_crash_after_paid_reply_before_commit_recovers_without_duplicate_request(
    tmp_path,
    example,  # noqa: F811
    monkeypatch,
):
    plan, path = fixture_plan(tmp_path, example)
    seen = []

    def handler(request):
        body = json.loads(request.content)
        key = digest(body)
        assert key not in seen
        seen.append(key)
        return reply(
            text="NO\nInvented judgment" if body["max_tokens"] == 120 else "Invented answer"
        )

    class Crash(BaseException):
        pass

    original = r.Journal.commit
    monkeypatch.setattr(r.Journal, "commit", lambda *args: (_ for _ in ()).throw(Crash()))
    with pytest.raises(Crash):
        r.run(plan, tmp_path / "results", mock=httpx.MockTransport(handler))
    assert seen
    monkeypatch.setattr(r.Journal, "commit", original)
    result = r.run(plan, tmp_path / "results", mock=httpx.MockTransport(handler))
    assert result["status"] == "complete_saved_outcomes"


def test_missing_classifier_never_uses_the_paid_transport(tmp_path, example):  # noqa: F811
    plan, path = fixture_plan(tmp_path, example)
    state, crosswalk, _, _, _ = context(example)
    state.memory.use_type.client.chats.clear()
    state.memory.use_type._cache.clear()
    with ProvisionalSession(path) as session:
        session.arm_provisional_mock(
            plan, httpx.MockTransport(lambda request: pytest.fail("Unexpected paid fallback"))
        )
        refs = r.resolve_models(state, session)
        with pytest.raises(LedgerError, match="classifier/embedding miss"):
            r.answer_query(state, crosswalk["session_id"], example["query"], "use_fixture", refs)
        assert not refs
