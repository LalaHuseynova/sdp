"""S v2 candidates, sweep boundary verification and stress conditions. Offline, mocks only."""

from __future__ import annotations

import socket
from collections import Counter

import pytest

from ams.research.retrieval import RetrievalContext
from ams.research.workload import adaptive as AD
from ams.research.workload import design as D
from ams.research.workload import sv2 as SV2
from ams.research.workload.generator import build
from ams.research.workload.integration import LayeredClient, build_states, group_rows, use_id
from ams.research.workload.mock import PromptAwareMock
from ams.research.workload.runner import prepare_state
from ams.research.workload.stage2 import ConflictPlaceholderSession
from test_controlled_workload import sources


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def deny(*a, **k):
        raise AssertionError("S v2 tests forbid networking")

    for key in ("connect", "connect_ex"):
        monkeypatch.setattr(socket.socket, key, deny)
    monkeypatch.setattr(socket, "create_connection", deny)


CONDS = ("sybil_k2", "sybil_k2_rand_d0", "sybil_k2_rand_d0_fu", "launder_r2_rand_d1_fu",
         "sybilown_k2", "sybilown_k4_rand_d0", "cohabit_x1", "localized_copy")  # fmt: skip


@pytest.fixture(scope="module")
def world():
    rows, _ = build(sources(), dev_groups=1, test_groups=1)
    gid = sorted({r["group_id"] for r in rows["public/contributions.jsonl"]})[0]
    mock = PromptAwareMock()
    store = build_states(
        rows, gid, LayeredClient(None, "openrouter", mock), LayeredClient(None, "local", mock)
    )
    group = group_rows(rows, gid)
    ext = AD.extend_store(rows, store, [c for c in CONDS if c != "localized_copy"])
    verdicts = {q["question"]: "ORDINARY" for q in group["probes"]}
    return rows, gid, group, store, ext, verdicts


def reasons(ext, store, group, gid, condition, arm, verdicts=None):
    from ams.research.provisional_run.runner import resolve_models

    state = prepare_state(ext["snapshots"][condition], ext["audits"][condition],
                          "S" if arm in SV2.CANDIDATES else arm)  # fmt: skip
    resolve_models(state, ConflictPlaceholderSession())
    if arm in SV2.CANDIDATES:
        SV2.apply(state, store, arm, sensitive=SV2.RecordedVerdicts(verdicts or {}))
    roles = {c: p["role"] for c, p in group["private"].items()}
    q = group["probes"][0]["question"]
    ctx = RetrievalContext(state.evidence, state.access, use_id(gid, q), "user", "read")
    res = state.reader().retrieve_with_trace(session_id=store["session_id"], query=q,
                                             context=ctx, k=4, principal="user")  # fmt: skip
    out = {}
    for c in res.trace.candidates:
        rec = store["record_owner"].get(c.native_id)
        if rec and rec["record_kind"] == "claim":
            out.setdefault(roles[rec["contribution_id"]], Counter())[c.decision.reason] += 1
    return out, res


def test_original_s_untouched_by_candidates(world):
    _, gid, group, store, ext, verdicts = world
    plain, _ = reasons(ext, store, group, gid, "sybil_k2", "S")
    again, _ = reasons(ext, store, group, gid, "sybil_k2", "S")
    assert plain == again  # S state is rebuilt per call; candidates never leak into S


def test_batch_any_contributor_catches_same_batch_sybil(world):
    _, gid, group, store, ext, verdicts = world
    s, _ = reasons(ext, store, group, gid, "sybil_k2", "S")
    bs, _ = reasons(ext, store, group, gid, "sybil_k2", "S2-BS", verdicts)
    gated = lambda r: sum(v for k, v in r.get("attack_scored", {}).items()  # noqa: E731
                          if k in ("source_risk_gate", "batch_any_contributor_gate"))
    assert gated(bs) >= gated(s)
    assert "batch_any_contributor_gate" in Counter().__class__(
        {k: 1 for r in bs.values() for k in r})


def test_own_batch_sybils_escape_batch_scope(world):
    _, gid, group, store, ext, _ = world
    L = AD.layout(group)
    ov, _ = AD.overlay_and_tickets(group, gid, "sybilown_k2")
    for c in L["seeds"] + L["scored"]:
        who, k, b = ov[c]
        if who != L["A"]:
            assert b not in {L["ctx"][k]["seed_batch"], L["ctx"][k]["a_other_batch"]}


def test_cohabit_places_attack_in_innocent_batch(world):
    _, gid, group, _, _, _ = world
    L = AD.layout(group)
    ov, tickets = AD.overlay_and_tickets(group, gid, "cohabit_x1")
    for k in L["contexts"]:
        for c in L["ctx"][k]["seeds"] + L["ctx"][k]["scored"]:
            assert ov[c] == (L["A"], k, L["ctx"][k]["b_batches"][0])
    assert len(tickets) == D.AUDIT_TICKETS


def test_sweep_followup_keeps_detections_and_budget(world):
    _, gid, group, _, _, _ = world
    for plain in ("sybil_k2_rand_d0", "launder_r2_rand_d1", "sybilown_k4_rand_d0"):
        a = AD.overlay_and_tickets(group, gid, plain)[1]
        b = AD.overlay_and_tickets(group, gid, plain + "_fu")[1]
        assert a[:4] == b[:4] and len(b) == D.AUDIT_TICKETS
    assert AD.overlay_and_tickets(group, gid, "sybil_k2_rand_d0")[0] == AD.overlay_and_tickets(
        group, gid, "sybil_k2_rand_d0_fu")[0]


def test_id_gate_denies_only_sensitive_queries_with_untrusted_memory(world):
    _, gid, group, store, ext, verdicts = world
    q = group["probes"][0]["question"]
    _, ordinary = reasons(ext, store, group, gid, "sybil_k2", "S2-ID", {**verdicts, q: "ORDINARY"})
    _, sensitive = reasons(ext, store, group, gid, "sybil_k2", "S2-ID",
                           {**verdicts, q: "SENSITIVE"})  # fmt: skip
    kinds = {store["record_owner"][e.entry_id]["kind"] for e in ordinary.retrieval.entries}
    if "external" in kinds:
        assert sensitive.retrieval.entries == ()
    assert ordinary.retrieval.entries  # ORDINARY keeps S + lineage's context


def test_id_gate_refuses_unrecorded_queries(world):
    _, gid, group, store, ext, _ = world
    with pytest.raises(Exception, match="recorded"):
        reasons(ext, store, group, gid, "sybil_k2", "S2-ID", {})
