"""Offline SDK/HTTP boundary tests for the approved experiment's software budget.

These tests use the real OpenAI SDK with httpx.MockTransport, blocked sockets,
and temporary SQLite databases. They make no external requests or account changes.
"""

from __future__ import annotations

import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import httpx
from openai import OpenAI

from ams.llm.budget import BudgetAccountingError, BudgetExhausted, BudgetGuard
from ams.llm.cache import ResponseCache
from ams.llm.pool import ManagedClient, RetryPolicy
from ams.llm.providers.openai_client import OpenAIClient
from ams.llm.types import ChatRequest, EmbedRequest, Message

MODEL = "openai/gpt-4o-mini"


def completion(*, cost="0.000123", byok=False, generation="gen-offline-budget-test"):
    usage = {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}
    if cost is not None:
        usage["cost"] = cost
    if byok:
        usage["is_byok"] = True
    return {
        "id": generation,
        "object": "chat.completion",
        "created": 1,
        "model": MODEL,
        "choices": [
            {
                "index": 0,
                "finish_reason": "stop",
                "message": {"role": "assistant", "content": "Original answer."},
            }
        ],
        "usage": usage,
    }


class OpenRouterBudgetTransportTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)
        self.path = self.directory / "budget.sqlite"
        self.guard = BudgetGuard(self.path, 27)
        self.requests = []
        block = patch("socket.socket.connect", side_effect=AssertionError("Network forbidden"))
        block.start()
        self.addCleanup(block.stop)

    @staticmethod
    def request(**overrides):
        values = {
            "messages": (
                Message("system", "Original SAFE-Mem instructions."),
                Message("user", "Original memory and evaluation question."),
            ),
            "model": MODEL,
            "temperature": 0.0,
            "max_tokens": 900,
            "stop": ("END",),
        }
        values.update(overrides)
        return ChatRequest(**values)

    def adapter(self, handler, *, guard=None, base_url="https://openrouter.ai/api/v1"):
        def capture(request):
            self.requests.append(json.loads(request.content))
            return handler(request)

        sdk = OpenAI(
            api_key="offline-test-key",
            base_url=base_url,
            max_retries=5,
            http_client=httpx.Client(transport=httpx.MockTransport(capture)),
        )
        self.addCleanup(sdk.close)
        result = OpenAIClient(
            provider="openrouter", sdk_client=sdk, budget_guard=guard or self.guard
        )
        self.addCleanup(result._client.close)
        return result

    @staticmethod
    def managed(adapter):
        return ManagedClient(adapter, retry=RetryPolicy(max_attempts=3), sleep=lambda _: None)

    def test_reservation_precedes_http_and_original_generation_inputs_are_preserved(self):
        seen = []

        def handle(_):
            snapshot = self.guard.snapshot()
            self.assertEqual(snapshot["counts"]["pending"], 1)
            self.assertEqual(snapshot["held_nanodollars"], 19_740_000)
            self.assertEqual(snapshot["used_nanodollars"], 0)
            seen.append(snapshot)
            return httpx.Response(200, json=completion())

        adapter = self.adapter(handle)
        original = self.request()
        response = adapter.complete(original)
        self.assertEqual(adapter._client.max_retries, 0)
        self.assertEqual(len(seen), 1)
        payload = self.requests[0]
        self.assertEqual(payload["model"], original.model)
        self.assertEqual(
            payload["messages"],
            [{"role": message.role, "content": message.content} for message in original.messages],
        )
        self.assertEqual(payload["temperature"], original.temperature)
        self.assertEqual(payload["max_tokens"], original.max_tokens)
        self.assertEqual(payload["stop"], list(original.stop))
        self.assertNotIn("reasoning", payload)
        self.assertEqual(
            payload["provider"],
            {
                "max_price": {"prompt": 0.15, "completion": 0.60, "request": 0},
                "allow_fallbacks": False,
                "require_parameters": True,
            },
        )
        self.assertEqual(
            {plugin["id"] for plugin in payload["plugins"]},
            {"web", "file-parser", "response-healing"},
        )
        self.assertTrue(all(plugin["enabled"] is False for plugin in payload["plugins"]))
        self.assertEqual(response.text, "Original answer.")

    def test_authoritative_cost_generation_id_and_native_tokens_are_saved(self):
        adapter = self.adapter(lambda _: httpx.Response(200, json=completion()))
        response = adapter.complete(self.request())
        self.assertAlmostEqual(response.usage.cost_usd, 0.000123)
        self.assertEqual(response.usage.input_tokens, 10)
        self.assertEqual(response.usage.output_tokens, 5)
        snapshot = self.guard.snapshot()
        self.assertEqual(snapshot["used_nanodollars"], 123_000)
        self.assertEqual(snapshot["held_nanodollars"], 0)
        with sqlite3.connect(self.path) as conn:
            metadata = json.loads(conn.execute("SELECT metadata FROM reservations").fetchone()[0])
        self.assertEqual(
            metadata,
            {
                "generation_id": "gen-offline-budget-test",
                "model": MODEL,
                "input_tokens": 10,
                "output_tokens": 5,
            },
        )

    def test_hidden_sdk_retries_are_disabled_even_for_retryable_http_status(self):
        adapter = self.adapter(
            lambda _: httpx.Response(
                503,
                json={"error": {"message": "Offline service error", "code": 503}},
                headers={"retry-after": "0"},
            )
        )
        from ams.llm.base import ProviderError

        with self.assertRaises(ProviderError):
            adapter.complete(self.request())
        self.assertEqual(len(self.requests), 1)
        self.assertEqual(self.guard.snapshot()["counts"]["unknown"], 1)

    def test_managed_retry_reserves_each_attempt_and_keeps_the_unknown_first_attempt(self):
        def handle(request):
            if len(self.requests) == 1:
                raise httpx.ReadTimeout("Offline timeout", request=request)
            snapshot = self.guard.snapshot()
            self.assertEqual(snapshot["counts"]["pending"], 1)
            self.assertEqual(snapshot["counts"]["unknown"], 1)
            self.assertEqual(snapshot["held_nanodollars"], 39_480_000)
            return httpx.Response(200, json=completion(generation="gen-second-attempt"))

        response = self.managed(self.adapter(handle)).complete(self.request())
        self.assertEqual(response.text, "Original answer.")
        self.assertEqual(len(self.requests), 2)
        snapshot = self.guard.snapshot()
        self.assertEqual(snapshot["counts"]["total"], 2)
        self.assertEqual(snapshot["counts"]["unknown"], 1)
        self.assertEqual(snapshot["counts"]["settled"], 1)
        self.assertEqual(snapshot["held_nanodollars"], 19_740_000)
        self.assertEqual(snapshot["used_nanodollars"], 123_000)

    def test_missing_nan_negative_and_byok_costs_fail_without_automatic_retry(self):
        for index, payload in enumerate(
            (
                completion(cost=None),
                completion(cost="NaN"),
                completion(cost="-0.1"),
                completion(byok=True),
            )
        ):
            with self.subTest(index=index):
                guard = BudgetGuard(self.directory / f"invalid-{index}.sqlite", 27)
                before = len(self.requests)
                adapter = self.adapter(
                    lambda _, body=payload: httpx.Response(200, json=body), guard=guard
                )
                with self.assertRaises(BudgetAccountingError):
                    self.managed(adapter).complete(self.request())
                self.assertEqual(len(self.requests) - before, 1)
                snapshot = guard.snapshot()
                self.assertEqual(snapshot["counts"]["unknown"], 1)
                self.assertEqual(snapshot["held_nanodollars"], 19_740_000)
                self.assertEqual(snapshot["used_nanodollars"], 0)
                self.assertTrue(snapshot["blocked"])
                with self.assertRaises(BudgetAccountingError):
                    adapter.complete(self.request())
                self.assertEqual(len(self.requests) - before, 1)

    def test_exhausted_allowance_prevents_http_despite_managed_retry_policy(self):
        guard = BudgetGuard(self.directory / "exhausted.sqlite", "0.01")

        def forbidden(_):
            raise AssertionError("Unfunded HTTP request was sent")

        adapter = self.adapter(forbidden, guard=guard)
        with self.assertRaises(BudgetExhausted):
            self.managed(adapter).complete(self.request())
        self.assertEqual(self.requests, [])
        self.assertEqual(guard.snapshot()["counts"]["total"], 0)

    def test_charge_exceeding_reservation_blocks_further_http(self):
        adapter = self.adapter(lambda _: httpx.Response(200, json=completion(cost="0.02")))
        managed = self.managed(adapter)
        with self.assertRaises(BudgetAccountingError):
            managed.complete(self.request())
        self.assertEqual(len(self.requests), 1)
        self.assertTrue(self.guard.snapshot()["blocked"])
        self.assertEqual(self.guard.snapshot()["counts"]["breach"], 1)
        with self.assertRaises(BudgetAccountingError):
            managed.complete(self.request())
        self.assertEqual(len(self.requests), 1)

    def test_unexpected_response_model_halts_before_another_http_attempt(self):
        payload = completion()
        payload["model"] = "openai/gpt-5.6-terra"
        adapter = self.adapter(lambda _: httpx.Response(200, json=payload))
        managed = self.managed(adapter)
        with self.assertRaises(BudgetAccountingError):
            managed.complete(self.request())
        self.assertEqual(len(self.requests), 1)
        self.assertTrue(self.guard.snapshot()["blocked"])
        with self.assertRaises(BudgetAccountingError):
            adapter.complete(self.request())
        self.assertEqual(len(self.requests), 1)

    def test_dated_same_model_response_is_recorded_without_substituting_family(self):
        payload = completion()
        payload["model"] = "openai/gpt-4o-mini-2024-07-18"
        response = self.adapter(lambda _: httpx.Response(200, json=payload)).complete(
            self.request()
        )
        self.assertEqual(response.model, payload["model"])
        self.assertFalse(self.guard.snapshot()["blocked"])
        self.assertEqual(self.guard.snapshot()["counts"]["settled"], 1)

    def test_same_prefix_nondate_model_variant_is_rejected(self):
        payload = completion()
        payload["model"] = "openai/gpt-4o-mini-search-preview"
        adapter = self.adapter(lambda _: httpx.Response(200, json=payload))
        with self.assertRaises(BudgetAccountingError):
            self.managed(adapter).complete(self.request())
        self.assertTrue(self.guard.snapshot()["blocked"])
        self.assertEqual(len(self.requests), 1)
        with self.assertRaises(BudgetAccountingError):
            adapter.complete(self.request())
        self.assertEqual(len(self.requests), 1)

    def test_local_cache_hit_needs_no_new_reservation_or_http(self):
        adapter = self.adapter(lambda _: httpx.Response(200, json=completion()))
        cache = ResponseCache(self.directory / "cache.sqlite")
        self.addCleanup(cache.close)
        managed = ManagedClient(adapter, cache=cache)
        first = managed.complete(self.request())
        second = managed.complete(self.request())
        self.assertFalse(first.cached)
        self.assertTrue(second.cached)
        self.assertEqual(len(self.requests), 1)
        self.assertEqual(self.guard.snapshot()["counts"]["total"], 1)
        self.assertEqual(self.guard.snapshot()["used_nanodollars"], 123_000)

    def test_unapproved_model_reasoning_and_embeddings_cannot_reach_http(self):
        adapter = self.adapter(lambda _: self.fail("Unapproved paid operation"))
        with self.assertRaises(BudgetAccountingError):
            adapter.complete(self.request(model="openai/gpt-5.6-terra"))
        with self.assertRaises(BudgetAccountingError):
            adapter.complete(self.request(reasoning_effort="high"))
        with self.assertRaises(ValueError):
            adapter.embed(EmbedRequest(texts=("Test",), model="openai/text-embedding-3-small"))
        self.assertEqual(self.requests, [])
        self.assertEqual(self.guard.snapshot()["counts"]["total"], 0)

    def test_guard_rejects_unofficial_or_insecure_endpoints(self):
        for endpoint in (
            "https://example.invalid/api/v1",
            "http://openrouter.ai/api/v1",
            "https://openrouter.ai/other-path",
        ):
            with self.subTest(endpoint=endpoint), self.assertRaises(ValueError):
                self.adapter(lambda _: self.fail("Endpoint contacted"), base_url=endpoint)
        self.assertEqual(self.requests, [])


if __name__ == "__main__":
    unittest.main()
