"""Offline checks: complete coverage, original bootstrap, and cost separation."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

from ams.data.mpbench import load_mpbench
from ams.eval.review_stats import asr_ci

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location(
    "mpbench_analysis", ROOT / "scripts/analyse_mpbench_reproduction.py"
)
analysis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(analysis)


class MPBenchAnalysisTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cases, _ = load_mpbench(ROOT / "data/mpbench")
        # Synthetic verdicts stay inside these tests; they are never saved as results.
        cls.rows = [
            {
                "cid": analysis.case_key(c),
                "is_adversarial": str(int(c.is_adversarial)),
                "attack_type": c.attack_type,
                "benign_scorable": str(int(c.is_adversarial or bool(c.expected_memory.strip()))),
                "benign_warranted": ""
                if c.is_adversarial
                else str(int(bool(c.legitimate_memory_write))),
                "attack_succeeded": str(int(c.is_adversarial and i % 3 == 0)),
                "answer_correct": str(int(not c.is_adversarial and i % 4 != 0)),
                "answer": "Synthetic unit-test answer; not a reproduction.",
                "answer_without_memory": "Synthetic no-memory control." if c.is_adversarial else "",
            }
            for i, c in enumerate(cls.cases)
            if c.retrieval_query.strip()
        ]

    def test_full_gold_coverage_and_changed_label_rejected(self):
        _, counts = analysis.validate_rows(self.rows, self.cases)
        self.assertEqual(counts, analysis.EXPECTED)
        with self.assertRaisesRegex(ValueError, "incomplete coverage"):
            analysis.validate_rows(self.rows[:-1], self.cases)
        changed = [{**r} for r in self.rows]
        changed[0]["attack_type"] = "changed"
        with self.assertRaisesRegex(ValueError, "changed attack category"):
            analysis.validate_rows(changed, self.cases)

    def test_duplicate_and_unqualified_identifiers_rejected(self):
        with self.assertRaisesRegex(ValueError, "duplicate outcome"):
            analysis.validate_rows(self.rows + [self.rows[0]], self.cases)
        old = [{**r} for r in self.rows]
        old[0]["cid"] = old[0]["cid"].split(":", 1)[1]
        with self.assertRaisesRegex(ValueError, "legacy unqualified"):
            analysis.validate_rows(old, self.cases)
        old[0]["source_split"] = "adversarial"
        old[0]["original_cid"] = old[0]["cid"]
        _, counts = analysis.validate_rows(old, self.cases)
        self.assertEqual(counts["attack"], 2999)

    def test_empty_no_memory_controls_rejected(self):
        changed = [{**r} for r in self.rows]
        changed[0]["answer_without_memory"] = ""
        with self.assertRaisesRegex(ValueError, "no-memory control answer"):
            analysis.validate_rows(changed, self.cases)

    def test_full_openrouter_ids_and_explicit_substitutions(self):
        target = {"model_id": "openai/gpt-4o-mini"}
        models = {role: "openrouter:openai/gpt-4o-mini" for role in ("memory", "agent", "judge")}
        self.assertEqual(
            analysis.validate_models(models, target, declared=False, allowed=False), {}
        )
        changed = {**models, "memory": "openrouter:wrong-vendor/gpt-4o-mini"}
        for declared, allowed in ((False, False), (True, False), (False, True)):
            with self.assertRaisesRegex(ValueError, "model substitution requires"):
                analysis.validate_models(changed, target, declared=declared, allowed=allowed)
        substitutions = analysis.validate_models(changed, target, declared=True, allowed=True)
        self.assertEqual(substitutions["memory"]["actual"], "wrong-vendor/gpt-4o-mini")

    def test_ingestion_logs_include_write_only_cases(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d)
            root = ROOT / "data/mpbench"
            hashes = {
                name: hashlib.sha256((root / name).read_bytes()).hexdigest()
                for name in ("adversarial_data.jsonl.jsonl", "benign_data.jsonl.jsonl")
            }
            integrity = {"files": hashes, "ingestions": 6240, "pool_size": 6240}
            (path / "dataset_integrity.json").write_text(json.dumps(integrity))
            catalog, writes = [], []
            for c in self.cases:
                provenance = {
                    "cid": analysis.case_key(c),
                    "original_cid": c.raw["id"],
                    "source_split": "adversarial" if c.is_adversarial else "benign",
                }
                fields = (
                    "retrieval_query",
                    "expected_memory",
                    "legitimate_memory_write",
                    "attack_type",
                    "attack_signal",
                    "domain",
                    "is_adversarial",
                )
                catalog.append({**provenance, **{k: getattr(c, k) for k in fields}})
                writes.append({**provenance, "session_id": "pool0"})
            (path / "case_catalog.jsonl").write_text("\n".join(json.dumps(r) for r in catalog))
            log = path / "written_memories-no_defence.jsonl"
            log.write_text("\n".join(json.dumps(r) for r in writes))
            checked = analysis.validate_ingestions(path, self.cases, "no_defence", root)
            self.assertEqual(checked["observed_write_cases"], 6240)
            missing = next(
                analysis.case_key(c) for c in self.cases if not c.retrieval_query.strip()
            )
            log.write_text("\n".join(json.dumps(r) for r in writes if r["cid"] != missing))
            with self.assertRaisesRegex(ValueError, "incomplete written_memories"):
                analysis.validate_ingestions(path, self.cases, "no_defence", root)
            integrity["files"]["benign_data.jsonl.jsonl"] = "incorrect"
            (path / "dataset_integrity.json").write_text(json.dumps(integrity))
            with self.assertRaisesRegex(ValueError, "dataset hashes differ"):
                analysis.validate_ingestions(path, self.cases, "no_defence", root)

    def test_metrics_reuse_original_query_bootstrap(self):
        metrics = analysis.compute_metrics(self.rows, self.cases, resamples=20)
        attacks = [r for r in self.rows if analysis.truth(r["is_adversarial"])]
        mapping = {analysis.case_key(c): c.retrieval_query for c in self.cases}
        _, ci_case, ci_query, _, nquery = asr_ci(attacks, mapping, b=20, seed=0)
        self.assertEqual(metrics["asr_case_bootstrap_ci95_percent"], list(ci_case))
        self.assertEqual(metrics["asr_query_clustered_ci95_percent"], list(ci_query))
        self.assertEqual(metrics["distinct_attack_queries"], nquery)
        benign = [
            r
            for r in self.rows
            if not analysis.truth(r["is_adversarial"]) and analysis.truth(r["benign_scorable"])
        ]
        expected = 100 * sum(analysis.truth(r["answer_correct"]) for r in benign) / 2856
        self.assertEqual(metrics["benign_utility_percent"], expected)

    def test_ledger_excludes_local_and_cached_calls(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d)
            rows = [
                {
                    "provider": "openrouter",
                    "model": "openai/gpt-4o-mini",
                    "cached": False,
                    "input_tokens": 100,
                    "output_tokens": 20,
                    "cost_usd": 0.25,
                },
                {
                    "provider": "openrouter",
                    "model": "openai/gpt-4o-mini",
                    "cached": True,
                    "cost_usd": 10,
                },
                {"provider": "local", "model": "MiniLM", "cached": False, "cost_usd": 10},
            ]
            (path / "usage.jsonl").write_text("\n".join(json.dumps(r) for r in rows))
            cost = analysis.usage_cost(path)
            self.assertEqual(cost["uncached_paid_provider_calls"], 1)
            self.assertEqual(cost["estimated_cost_usd"], 0.25)
            self.assertEqual(cost["excluded_cache_hits"], 1)
            self.assertEqual(cost["excluded_uncached_local_calls"], 1)
            (path / "usage.jsonl").write_text(json.dumps({"provider": "echo"}))
            with self.assertRaisesRegex(ValueError, "synthetic echo"):
                analysis.usage_cost(path)

    def test_no_runs_produces_only_pending_comparisons(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(analysis.main(["--output-dir", d]), 0)
            report = json.loads((Path(d) / "comparison.json").read_text())
            self.assertEqual(len(report["comparisons"]), 32)
            self.assertTrue(
                all(r["reproduction"] == {"status": "pending"} for r in report["comparisons"])
            )

    def test_echo_manifest_cannot_be_reported_as_full(self):
        target = next(
            r
            for r in json.loads(analysis.TARGETS.read_text())["published_targets"]
            if r["backbone"] == "4omini" and r["method"] == "no_defence"
        )
        with tempfile.TemporaryDirectory() as d:
            path = Path(d)
            config = {
                "pool_size": 6240,
                "retrieve_k": 4,
                "seed": 0,
                "memory": {"max_facts": 6},
                "models": {"memory": "echo:test", "agent": "echo:test", "judge": "echo:test"},
            }
            (path / "manifest.json").write_text(
                json.dumps({"finished_utc": "test", "n_pool_cases": 6240, "config": config})
            )
            (path / "mpbench_summary.json").write_text(
                json.dumps({"n_cases": 6240, "n_pool_cases": 6240})
            )
            with self.assertRaisesRegex(ValueError, "non-live model"):
                analysis.analyse_run(path, target, self.cases)
            (path / "mpbench_summary.json").write_text(
                json.dumps({"n_cases": 6240, "n_pool_cases": None})
            )
            with self.assertRaisesRegex(ValueError, "did not ingest 6240"):
                analysis.analyse_run(path, target, self.cases)


if __name__ == "__main__":
    unittest.main()
