"""Deterministic offline fixtures only: these are not annotated MPBench data."""

from __future__ import annotations

import copy
import itertools
import json
import random
import tempfile
import unittest
from fractions import Fraction
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from ams.research.phase1_annotations import (
    bundle_verdict,
    eligible_records,
    reconcile,
    review_template,
    utility_template,
    validate_review,
    validate_utility,
)
from ams.research.phase1_common import PreparationError, digest, opaque, stage_seed
from ams.research.phase1_data import (
    duplicate_groups,
    import_evidence_catalog,
    source_parts,
    strict_objects,
)
from ams.research.phase1_scenarios import (
    SCENARIOS,
    STRATA,
    assert_public,
    assign,
    make_episode,
    policy_sets,
    runtime_view,
    select_bags,
    subset_table,
    validate_bag,
    validate_episode,
    weighted_subset,
)
from ams.research.phase1_stress import (
    compromise_plan,
    copy_descriptors,
    delayed_audit_plan,
    false_accusation_plan,
    noisy_audit_plan,
)


def fixture_packet(pid="p_fixture"):
    text = "The meeting room is Maple."
    artifacts = source_parts(pid, "Read the note.", text)
    return {
        "contribution_id": pid,
        "context_id": "email",
        "use_id": opaque("use", pid),
        "task": "Read the note.",
        "intended_use": "Which room is stated?",
        "artifacts": artifacts,
        "records": [{"record_id": opaque("r", pid), "text": text, "content_hash": digest(text)}],
    }


def reviewed(packet, who="reviewer_a", verdict="safe_for_use", origin="external"):
    row = review_template(packet)
    row.update({"reviewer_id": who, "status": "complete", "independent_human_review": True})
    source = next(a for a in packet["artifacts"] if a["role"] == origin)
    row["records"][0].update(
        {
            "origin": origin,
            "source_spans": [
                {
                    "artifact_id": source["artifact_id"],
                    "start": 0,
                    "end": len(source["text"]),
                    "quote": source["text"],
                }
            ],
            "verdict": verdict,
            "fully_reviewed": True,
            "rationale": "OFFLINE TEST FIXTURE",
            "evidence_quote": packet["records"][0]["text"] if verdict == "unsafe" else "",
        }
    )
    return row


def utility(packet):
    row = utility_template(packet)
    source = packet["artifacts"][1]
    row.update(
        {
            "question": "According to the note, which meeting room is stated?",
            "answers": ["Maple"],
            "support_record_id": packet["records"][0]["record_id"],
            "support_artifact_id": source["artifact_id"],
            "start": 0,
            "end": len(source["text"]),
            "quote": source["text"],
            "proposed_by": "writer",
            "validated_by": "checker",
            "status": "complete",
            "safe_descriptive_use_confirmed": True,
            "unique_support_in_bag_confirmed": True,
        }
    )
    return row


def fixture_bag(prefix="fixture"):
    """Synthetic small strings, never written to a real prepared dataset."""
    bag, public, packets = [], {}, {}
    for context in ("email", "file_and_doc"):
        for label, z, n in STRATA:
            for i in range(n):
                pid = opaque("p", prefix, context, label, z, i)
                packet = fixture_packet(pid)
                packet["context_id"] = context
                decisions = validate_review(packet, reviewed(packet, verdict=z))["decisions"]
                qa = utility(packet) if z == "safe_for_use" else None
                bag.append(
                    {
                        "contribution_id": pid,
                        "context_id": context,
                        "stratum": label,
                        "Z_bundle": z,
                        "Y_case": label == "attack",
                        "utility": qa,
                        "records": decisions,
                        "frozen_records": packet["records"],
                        "reviewers": ["fixture_a", "fixture_b"],
                        "group_id": opaque("g", pid),
                        "packet_hash": digest(packet),
                        "retrieval_query": packet["intended_use"],
                        "expected_memory": "private fixture reference",
                    }
                )
                public[pid] = {
                    "contribution_id": pid,
                    "context_id": context,
                    "user_query": packet["task"],
                    "context": packet["artifacts"][1]["text"],
                    "artifacts": packet["artifacts"],
                    "payload_hash": digest(pid),
                }
                packets[pid] = packet
    return bag, public, packets


class DataTests(unittest.TestCase):
    def test_actual_chunk_export_must_bind_complete_sources_and_content(self):
        case = SimpleNamespace(cid="source:1", user_query="Task", context="Source text")
        row = {
            "cid": case.cid,
            "payload_hash": digest([case.user_query, case.context]),
            "complete": True,
            "exporter_fingerprint": "fixture_only",
            "evidence_chunks": [
                {"chunk_id": "ec1", "text": "Source text", "content_hash": digest("Source text")}
            ],
        }
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "chunks.jsonl"
            p.write_text(json.dumps(row) + "\n")
            records = {case.cid: []}
            stats = import_evidence_catalog(p, [case], records)
            self.assertTrue(stats["chunk_records_available"])
            self.assertEqual(records[case.cid][0]["record_kind"], "evidence_chunk")
            row["evidence_chunks"][0]["content_hash"] = "invented"
            p.write_text(json.dumps(row) + "\n")
            with self.assertRaises(PreparationError):
                import_evidence_catalog(p, [case], {case.cid: []})

    def test_strict_decoder_consumes_concatenated_objects_and_rejects_tail(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "data.jsonl"
            p.write_text('{} {}\n{"n":1}')
            self.assertEqual(len(strict_objects(p)), 3)
            p.write_text("{} garbage")
            with self.assertRaises(PreparationError):
                strict_objects(p)

    def test_real_offsets_do_not_merge_repeated_headers(self):
        context = "  From: A\nAlpha\n---\nFrom: A\nBeta  "
        parts = source_parts("one", "Remember my preference.", context)
        self.assertEqual([p["text"] for p in parts[1:]], ["From: A\nAlpha", "From: A\nBeta"])
        self.assertEqual(len({p["artifact_id"] for p in parts}), 3)
        for p in parts[1:]:
            self.assertEqual(context[p["start"] : p["end"]], p["text"])
        self.assertEqual(parts[0]["role"], "principal")
        self.assertNotEqual(
            parts[1]["artifact_id"], source_parts("two", "", context)[1]["artifact_id"]
        )

    def test_duplicate_components_are_transitive_and_short_queries_not_all_merged(self):
        def c(cid, query):
            return SimpleNamespace(cid=cid, retrieval_query=query, user_query=cid, context=cid)

        cases = [
            c("a", "one two three four five six seven eight nine ten"),
            c("b", "one two three four five six seven eight nine ten extra"),
            c("c", "yes"),
            c("d", "no"),
            c("e", "YES"),
        ]
        groups, _ = duplicate_groups(cases)
        self.assertEqual(groups["a"], groups["b"])
        self.assertEqual(groups["c"], groups["e"])
        self.assertNotEqual(groups["c"], groups["d"])

    def test_import_does_not_import_model_transport(self):
        import subprocess
        import sys

        code = (
            "import sys; import ams.research.phase1; "
            "assert not any(x.startswith(('ams.llm','openai','torch')) for x in sys.modules)"
        )
        result = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)


class AnnotationTests(unittest.TestCase):
    def test_empty_ambiguous_and_principal_bundles_never_become_external_safe(self):
        self.assertEqual(bundle_verdict([]), "uncertain")
        self.assertEqual(
            bundle_verdict([{"origin": "principal", "verdict": "safe_for_use"}]), "uncertain"
        )
        self.assertEqual(
            bundle_verdict([{"origin": "ambiguous", "verdict": "unsafe"}]), "uncertain"
        )

    def test_attack_case_can_have_safe_memory_without_relabeling_case(self):
        packet = fixture_packet()
        original = [
            {
                "contribution_id": packet["contribution_id"],
                "Y_case": True,
                "stratum": "attack",
                "records": packet["records"],
            }
        ]
        eligible, _ = eligible_records(
            original,
            [packet],
            [reviewed(packet)],
            [reviewed(packet, "reviewer_b")],
            [],
            [utility(packet)],
        )
        self.assertTrue(eligible[0]["Y_case"])
        self.assertEqual(eligible[0]["Z_bundle"], "safe_for_use")

    def test_independent_review_and_third_person_adjudication(self):
        p = fixture_packet()
        with self.assertRaises(PreparationError):
            reconcile([p], [reviewed(p)], [reviewed(p)])
        b = reviewed(p, "reviewer_b", "unsafe")
        approved, stats = reconcile([p], [reviewed(p)], [b])
        self.assertEqual(approved, [])
        self.assertEqual(stats["disagreements"], 1)
        with self.assertRaises(PreparationError):
            reconcile([p], [reviewed(p)], [b], [reviewed(p)])
        approved, stats = reconcile([p], [reviewed(p)], [b], [reviewed(p, "reviewer_c")])
        self.assertEqual(approved[0]["Z_bundle"], "safe_for_use")
        self.assertEqual(stats["adjudicated"], 1)

    def test_stale_content_and_invented_source_quotes_rejected(self):
        p = fixture_packet()
        r = reviewed(p)
        r["packet_hash"] = "stale"
        with self.assertRaises(PreparationError):
            validate_review(p, r)
        r = reviewed(p)
        r["records"][0]["source_spans"][0]["quote"] = "invented"
        with self.assertRaises(PreparationError):
            validate_review(p, r)

    def test_utility_independent_support_and_no_answer_in_question(self):
        p = fixture_packet()
        approved, _ = reconcile([p], [reviewed(p)], [reviewed(p, "reviewer_b")])
        u = utility(p)
        validate_utility(p, approved[0], u)
        u["validated_by"] = u["proposed_by"]
        with self.assertRaises(PreparationError):
            validate_utility(p, approved[0], u)
        u = utility(p)
        u["question"] = "Is the room Maple?"
        with self.assertRaises(PreparationError):
            validate_utility(p, approved[0], u)


class AssignmentTests(unittest.TestCase):
    def test_exact_weighted_subset_normalization_and_transition_probabilities(self):
        weights = list(map(Fraction, ("1", "2.25", "9", "1")))
        ints, dp = subset_table(weights, 2)
        combinations = list(itertools.combinations(range(4), 2))
        mass = {a: Fraction(ints[a[0]] * ints[a[1]]) for a in combinations}
        self.assertEqual(dp[0][2], sum(mass.values()))
        for a in combinations:
            prob, left = Fraction(1), 2
            for i, w in enumerate(ints):
                if not left:
                    break
                inside = Fraction(w * dp[i + 1][left - 1], dp[i][left])
                prob *= inside if i in a else 1 - inside
                left -= i in a
            self.assertEqual(prob, mass[a] / sum(mass.values()))
        for seed in range(100):
            sample = weighted_subset(weights, 2, random.Random(seed))
            self.assertEqual(len(set(sample)), 2)

    def test_null_subset_law_is_uniform(self):
        ints, dp = subset_table([Fraction(1)] * 16, 8)
        self.assertEqual(ints, [1] * 16)
        self.assertEqual(dp[0][8], 12870)
        self.assertEqual(dp[1][7], 6435)

    def test_six_scenarios_preserve_counts_and_common_orders(self):
        bag, public, packets = fixture_bag()
        episodes = [make_episode(bag, public, packets, "08", s) for s in SCENARIOS]
        roots, ingestions = set(), set()
        for e in episodes:
            validate_episode(e)
            roots.add(e["private"]["reserved_audits"][0])
            ingestions.add(
                tuple(
                    x["contribution_id"] for x in e["private"]["events"] if x["event"] == "ingest"
                )
            )
            self.assertEqual(len(set(e["shared_arm_inputs"].values())), 1)
        self.assertEqual(len(roots), 1)
        self.assertEqual(len(ingestions), 1)
        self.assertEqual(assign(bag, "08", "weak_localized"), assign(bag, "08", "weak_localized"))

    def test_fixed_audit_control_has_same_targets_across_regimes(self):
        bag, public, packets = fixture_bag()
        episodes = [
            make_episode(bag, public, packets, "08", s, fixed_audits=True) for s in SCENARIOS
        ]
        self.assertEqual(len({tuple(e["private"]["reserved_audits"]) for e in episodes}), 1)
        self.assertEqual(len({digest(e["private"]["query_gold"]) for e in episodes}), 1)

    def test_lower_budgets_preserve_probe_cohort_without_future_audits(self):
        bag, public, packets = fixture_bag()
        episodes = [
            make_episode(bag, public, packets, "08", "strong_localized", b) for b in (1, 3, 5)
        ]
        self.assertEqual(len({digest(e["private"]["query_gold"]) for e in episodes}), 1)
        self.assertEqual(
            [sum(x["event"] == "audit" for x in e["private"]["events"]) for e in episodes],
            [1, 3, 5],
        )

    def test_no_forced_mixed_rates_and_no_case_label_assignment_dependency(self):
        bag, _, _ = fixture_bag()
        a, _ = assign(bag, "08", "strong_distributed")
        alternative = copy.deepcopy(bag)
        for row in alternative:
            row["Y_case"] = not row["Y_case"]
        # Placement is based on reviewed Z and context, never direct case-label routing.
        self.assertEqual(a, assign(alternative, "08", "strong_distributed")[0])

    def test_sampling_enforces_strata_and_group_disjointness(self):
        candidates = fixture_bag("first")[0] + fixture_bag("second")[0]
        bags = select_bags(candidates, 2)
        for b in bags:
            validate_bag(b)
        self.assertFalse({r["group_id"] for r in bags[0]} & {r["group_id"] for r in bags[1]})
        with self.assertRaises(PreparationError):
            select_bags(candidates, 3)
        candidates[0]["group_id"] = candidates[1]["group_id"]
        with self.assertRaises(PreparationError):
            validate_bag(candidates[:32])

    def test_permissions_are_label_blind_and_exact_quarter(self):
        bag, _, _ = fixture_bag()
        assignments, _ = assign(bag, "08", "uninformative")
        plan = policy_sets(assignments, "08")
        self.assertEqual(len(plan["P0_only_roots"]), 8)
        self.assertEqual(len(plan["write_denied_roots"]), 8)
        self.assertNotIn(plan["revoke_R1_root"], plan["P0_only_roots"])
        self.assertEqual(plan, policy_sets(assignments, "08"))

    def test_length_delimited_seed_is_unambiguous(self):
        self.assertNotEqual(stage_seed("1", "23", "x"), stage_seed("12", "3", "x"))


class BoundaryTests(unittest.TestCase):
    def test_keyed_ids_hide_enumerable_bag_names_without_changing_payloads(self):
        from ams.research.phase1_blinding import blind_episode, keyed_id

        bag, public, packets = fixture_bag()
        e = make_episode(bag, public, packets, "08", "strong_localized")
        key = bytes(range(32))
        blinded = blind_episode(e, key)
        self.assertEqual(blinded, blind_episode(e, key))
        self.assertNotEqual(set(e["public_inputs"]), set(blinded["public_inputs"]))
        for pid, row in e["public_inputs"].items():
            other = blinded["public_inputs"][keyed_id(pid, key)]
            self.assertEqual(row["context"], other["context"])
            self.assertEqual(row["user_query"], other["user_query"])
            self.assertEqual(row["artifacts"][1]["text"], other["artifacts"][1]["text"])
        assert_public(runtime_view(blinded, 38))
        self.assertNotEqual(
            blinded["public_inputs"], blind_episode(e, bytes(reversed(range(32))))["public_inputs"]
        )

    def test_runtime_has_only_prefix_and_returns_detached_objects(self):
        bag, public, packets = fixture_bag()
        e = make_episode(bag, public, packets, "08", "strong_localized")
        self.assertEqual(runtime_view(e, 0)["visible_contributions"], {})
        self.assertEqual(runtime_view(e, 32)["revealed_audits"], [])
        view = runtime_view(e, 33)
        self.assertEqual(len(view["revealed_audits"]), 1)
        self.assertEqual(len(runtime_view(e, 37)["revealed_audits"]), 5)
        view["revealed_audits"][0]["verdict"] = "tampered"
        self.assertEqual(runtime_view(e, 33)["revealed_audits"][0]["verdict"], "unsafe")
        self.assertIsNotNone(runtime_view(e, 38)["current_query"])
        assert_public(runtime_view(e, 38))
        self.assertEqual(runtime_view(e, 38, "unauthorized")["visible_contributions"], {})
        with self.assertRaises(PreparationError):
            runtime_view(e, len(e["private"]["events"]) + 1)

    def test_gold_field_and_event_budget_corruption_are_rejected(self):
        bag, public, packets = fixture_bag()
        e = make_episode(bag, public, packets, "08", "strong_localized")
        with self.assertRaises(PreparationError):
            assert_public({"context": "legitimate source text", "nested": {"Y_case": True}})
        e["private"]["budget"] = 6
        with self.assertRaises(PreparationError):
            validate_episode(e)

    def test_missing_annotations_block_build_without_public_episode_files(self):
        from ams.research.phase1 import build_pilot, implementation_fingerprints
        from ams.research.phase1_common import PROTOCOL_HASH, SCHEMA

        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            prep, out = base / "prep", base / "blocked"
            (prep / "private").mkdir(parents=True)
            (prep / "public").mkdir()
            for name in ("blinded_packets", "case_index", "duplicate_groups"):
                (prep / f"private/{name}.jsonl").write_text("")
            (prep / "public/candidate_inputs.jsonl").write_text("")
            (prep / "preparation_manifest.json").write_text(
                json.dumps(
                    {
                        "schema": SCHEMA,
                        "protocol_sha256": PROTOCOL_HASH,
                        "files": {},
                        "implementation_sha256": implementation_fingerprints(),
                        "frozen_chunk_catalog_available": False,
                    }
                )
            )
            status = build_pilot(prep, base / "no_reviews", out)
            self.assertFalse(status["pilot_ready"])
            self.assertEqual(status["real_episodes_generated"], 0)
            self.assertFalse((out / "public").exists())
            # Even a sufficient claim-only selection cannot release the m=4 protocol.
            with patch("ams.research.phase1.select_bags", return_value=[fixture_bag()[0]]):
                blocked = build_pilot(prep, base / "no_reviews", base / "chunk_blocked")
            self.assertFalse(blocked["pilot_ready"])
            self.assertIn("Evidence chunks are missing", blocked["blocking_reason"])

    def test_revocation_removes_claims_and_previous_audits_from_requester_view(self):
        bag, public, packets = fixture_bag()
        e = make_episode(bag, public, packets, "08", "strong_localized")
        root = e["private"]["reserved_audits"][0]
        before = len(e["private"]["events"])
        self.assertIn(root, runtime_view(e, before)["visible_contributions"])
        e["private"]["events"].append(
            {
                "event": "policy",
                "contribution_id": root,
                "policy_version": 2,
                "allowed_readers": ["audit_service"],
            }
        )
        after = runtime_view(e, before + 1)
        self.assertNotIn(root, after["visible_contributions"])
        self.assertNotIn(root, {a["contribution_id"] for a in after["revealed_audits"]})
        with self.assertRaises(PreparationError):
            e["private"]["events"][-1]["policy_version"] = 1
            runtime_view(e, before + 1)

    def test_public_allowlist_rejects_unrecognized_gold_alias(self):
        from ams.research.phase1_scenarios import validate_public_contribution

        _, public, _ = fixture_bag()
        row = copy.deepcopy(next(iter(public.values())))
        row["target_risk_indicator"] = 1
        with self.assertRaises(PreparationError):
            validate_public_contribution(row)


class StressTests(unittest.TestCase):
    def test_compromise_has_clean_prefix_nine_audits_and_eight_pre_feedback_queries(self):
        bag, _, packets = fixture_bag()
        plan = compromise_plan(bag, packets, "08")
        self.assertEqual(plan, compromise_plan(bag, packets, "08"))
        events, rows = plan["events"], plan["private"]["gold"]
        self.assertEqual(sum(e["event"] == "audit" for e in events), 9)
        prefix = plan["private"]["prefix_audits"]
        self.assertEqual(len(prefix), 4)
        self.assertTrue(all(rows[p]["Z_bundle"] == "safe_for_use" for p in prefix))
        self.assertTrue(all(rows[p]["stratum"] != "attack" for p in prefix))
        self.assertEqual(len(plan["private"]["pre_feedback_cohort"]), 8)
        for c in ("email", "file_and_doc"):
            new = [p for p in plan["private"]["pre_feedback_cohort"] if rows[p]["context_id"] == c]
            self.assertEqual(sum(rows[p]["Z_bundle"] == "unsafe" for p in new), 3)
        seen, prefix_count, pre_count = set(), 0, 0
        for e in events:
            if e["event"] == "ingest":
                seen.add(e["contribution_id"])
            if e["event"] == "audit":
                self.assertIn(e["payload"]["contribution_id"], seen)
                if len(seen) == 16:
                    prefix_count += 1
            if e["event"] == "query" and len(seen) == 32:
                pre_count += 1
        self.assertEqual(prefix_count, 4)
        self.assertGreaterEqual(pre_count, 8)

    def test_false_accusation_reserve_correction_and_paired_control(self):
        bag, _, packets = fixture_bag()
        extra, _, extra_packets = fixture_bag("reserve")
        reserve = []
        for c in ("email", "file_and_doc"):
            u = [r for r in extra if r["context_id"] == c and r["Z_bundle"] == "unsafe"][:4]
            s = [r for r in extra if r["context_id"] == c and r["stratum"] == "suggestive_benign"][
                :4
            ]
            reserve += u + s
        packets.update(extra_packets)
        plan = false_accusation_plan(bag, reserve, packets, "08")
        self.assertEqual(len(plan["assignments"]), 48)
        events = plan["events"]
        audits = [e["payload"] for e in events if e["event"] == "audit"]
        self.assertEqual(len(audits), 5)
        self.assertEqual(audits[0]["verdict"], "unsafe")
        self.assertEqual(audits[-1]["verdict"], "safe_for_use")
        self.assertEqual(audits[-1]["supersedes_ticket_id"], audits[0]["ticket_id"])
        self.assertEqual(sum(e["event"] == "query" for e in events), 48)
        clean = plan["private"]["clean_contributor"]
        clean_ids = [p for p, m in plan["assignments"].items() if m["contributor_id"] == clean]
        self.assertEqual(len(clean_ids), 16)
        self.assertTrue(all(not plan["private"]["gold"][p]["Y_case"] for p in clean_ids))
        control = [e["payload"] for e in plan["correct_audit_control"] if e["event"] == "audit"]
        self.assertEqual(control[0]["verdict"], "safe_for_use")
        self.assertEqual(
            [e for e in events if e["event"] == "query"],
            [e for e in plan["correct_audit_control"] if e["event"] == "query"],
        )
        with self.assertRaises(PreparationError):
            false_accusation_plan(bag, [], packets, "08")

    def test_known_copies_keep_one_observation_root_and_inherit_permissions(self):
        bag, public, packets = fixture_bag()
        e = make_episode(bag, public, packets, "08", "uninformative")
        row = next(iter(e["public_inputs"].values()))
        copies = copy_descriptors(row, "08")
        self.assertEqual(len({c["copy_id"] for c in copies}), 3)
        self.assertEqual({c["observation_root_id"] for c in copies}, {row["contribution_id"]})
        self.assertTrue(all(c["allowed_readers"] == row["allowed_readers"] for c in copies))

    def test_noise_replay_deterministic_and_delay_cannot_improve_earlier_decision(self):
        bag, public, packets = fixture_bag()
        e = make_episode(bag, public, packets, "08", "uninformative")
        events = e["private"]["events"]
        self.assertEqual(noisy_audit_plan(events, "08"), noisy_audit_plan(events, "08"))
        delayed = delayed_audit_plan(events, 4)
        first_audit = next(i for i, event in enumerate(delayed) if event["event"] == "audit")
        self.assertEqual(sum(x["event"] == "query" for x in delayed[:first_audit]), 4)
        e["private"]["events"] = delayed
        self.assertEqual(runtime_view(e, first_audit)["revealed_audits"], [])
        self.assertEqual(delayed_audit_plan(events, 0), events)

    def test_frozen_config_agrees_with_executable_design(self):
        from ams.research.phase1_common import ARMS, MASTER_SEED, PROTOCOL_HASH

        config = json.loads(Path("configs/research/mpbench_phase1.json").read_text())
        self.assertEqual(config["master_seed"], MASTER_SEED)
        self.assertEqual(config["protocol_sha256"], PROTOCOL_HASH)
        self.assertEqual(tuple(config["primary_arms"]), ARMS)
        self.assertFalse(any(config["enabled"].values()))


if __name__ == "__main__":
    unittest.main()
