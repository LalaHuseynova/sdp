"""Conditional post-review data construction using invented temporary reviews only."""

import copy
import json
from collections import Counter

import pytest

from ams.research import comparison, focused_review as f, scoped_cohort as s
from ams.research.dynamic.models import LedgerError, canonical, digest
from ams.research.recovery.offline import sha_file
from test_ai_exploratory_freeze import test_balanced_invented_freeze_never_becomes_human_gold_or_live_execution as build_balanced
from test_focused_review import complete, coordinator, write
from test_question_calibration import offline  # noqa: F401


def fixture(tmp_path, *, accept=True):
    build_balanced(tmp_path)
    prepared, reviewed = tmp_path/"prepared", tmp_path/"reviews"
    packets = list(map(json.loads, (prepared/"private/review_packets.jsonl").open()))
    by_pid = {p["contribution_id"]: p for p in packets}
    for packet in packets:
        for r in packet["records"]:
            r["content_hash"] = digest(r["text"])
    (prepared/"private/review_packets.jsonl").write_text("".join(canonical(p)+"\n" for p in packets))
    qs = list(map(json.loads, (prepared/"private/question_drafts.jsonl").open()))
    target = "p_file_and_doc_10"  # The invented safe explicit-retention contribution.
    q = copy.deepcopy(next(q for q in qs if q["contribution_id"] == target))
    old_qid = q["candidate_id"]; q["candidate_id"] = "new_frozen_scoped_fixture_QA"
    rows = list(map(json.loads, (reviewed/"automated_proposals.jsonl").open()))
    for row in rows:
        packet = by_pid[row["contribution_id"]]
        row["packet_hash"] = digest(packet)
        for r in row["records"]:
            r["content_hash"] = next(x["content_hash"] for x in packet["records"] if x["record_id"] == r["record_id"])
        for candidate in row["questions"]:
            if candidate["candidate_id"] == old_qid:
                candidate["no_answer_in_question"] = None
    (reviewed/"automated_proposals.jsonl").write_text("".join(canonical(r)+"\n" for r in rows))
    files = {n: sha_file(reviewed/n) for n in ["automated_proposals.jsonl", "summary.json"]}
    (reviewed/"results_manifest.json").write_text(canonical({"files": files, "hash": digest(files)}))
    package = tmp_path/"package"; (package/"controller_only").mkdir(parents=True)
    (package/"controller_only/candidate.json").write_text(canonical(q))
    (package/"controller_only/packet.json").write_text(canonical(by_pid[target]))
    files = {str(p.relative_to(package)): sha_file(p) for p in package.rglob("*.json")}
    (package/"manifest.json").write_text(canonical({"files": files, "hash": digest(files)}))
    root = tmp_path/"workflow"; f.prepare(package, root)
    if accept:
        complete(root)
        imported = tmp_path/"accepted"
        f.accept(root, write(root, "coordinator", coordinator(root)), imported)
    else:
        imported = None
    ready = tmp_path/"scoped-ready"
    result = f.readiness(root, prepared, [reviewed], ready, imported)
    return prepared, reviewed, ready, result


def test_qualified_fixture_freeze_preserves_scoped_QA_source_AI_and_equal_feedback(tmp_path):
    prepared, reviewed, ready, report = fixture(tmp_path)
    assert report["exploratory_data_ready"] is True
    old = (reviewed/"automated_proposals.jsonl").read_bytes()
    out = tmp_path/"scoped-cohort"
    result = s.freeze(prepared, ready, out)
    assert result["contributions"] == 32 and result["overlays"] == 3
    assert result["selected_human_QA_questions"] == 1
    assert result["human_verified_memory_labels"] == 0 and result["scientific_human_validated"] is False
    assert result["execution_enabled"] is False
    manifest = f.read(out/"manifest.json")
    assert manifest["schema"] == s.SCHEMA
    selection = f.read(out/"private/selection.json")
    provenance = f.read(out/"private/annotation_provenance.json")
    assert selection["human_validated_questions"] == 1 and selection["human_verified_labels"] == 0
    assert provenance["selected_AI_QA_questions"] == 15
    orders, roots = [], []
    for file in (out/"public").glob("*.json"):
        public = f.read(file); private = f.read(out/"private"/file.name)
        assert "PRIVATE_TARGET" not in file.read_text() and "invented-person" not in file.read_text()
        assert "review_record_hashes" not in public and "gold_cases" not in public
        ingests = [e for e in public["events"] if e["event"] == "ingest"]
        assert Counter(e["context_id"] for e in ingests) == {"email": 16, "file_and_doc": 16}
        assert private["feedback_budget_each"] == 5 and len(private["audits"]) == 5
        assert all(a["annotation_source"] == "llm" and a["independently_verified"] is False for a in private["audits"])
        assert private["arms_receive_identical_data_and_feedback"] is True
        orders.append([e["contribution_id"] for e in ingests]); roots.append(private["reserved_audit_ids"][0])
    assert orders[0] == orders[1] == orders[2] and len(set(roots)) == 1
    assert (reviewed/"automated_proposals.jsonl").read_bytes() == old
    with pytest.raises(LedgerError, match="overwrite"):
        s.freeze(prepared, ready, out)


def test_pending_reviews_cannot_produce_a_real_cohort(tmp_path):
    prepared, _, ready, report = fixture(tmp_path, accept=False)
    assert report["exploratory_data_ready"] is False and report["human_validated_questions"] == 0
    with pytest.raises(LedgerError, match="accepted scoped QA"):
        s.freeze(prepared, ready, tmp_path/"forbidden")
    assert not (tmp_path/"forbidden").exists()


@pytest.mark.parametrize("mutation", ["source_vote", "question_decision", "selected_ids"])
def test_forged_view_or_selection_is_not_a_qualified_review(tmp_path, mutation):
    prepared, _, ready, _ = fixture(tmp_path)
    if mutation in {"source_vote", "question_decision"}:
        view = ready/"selection_view"
        rows = list(map(json.loads, (view/"automated_proposals.jsonl").open()))
        if mutation == "source_vote":
            rows[0]["records"][0]["verdict"] = "safe_for_use"
        else:
            rows[-1]["questions"][0]["useful_for_task"] = False
        (view/"automated_proposals.jsonl").write_text("".join(canonical(r)+"\n" for r in rows))
        files = {n: sha_file(view/n) for n in ["automated_proposals.jsonl", "summary.json"]}
        (view/"results_manifest.json").write_text(canonical({"files": files, "hash": digest(files)}))
    else:
        path = ready/"review_readiness.json"; body=f.read(path);body["selected_ids"]=list(reversed(body["selected_ids"]));path.write_text(canonical(body))
        m=f.read(ready/"review_readiness_manifest.json");m["files"]["review_readiness.json"]=sha_file(path)
        (ready/"review_readiness_manifest.json").write_text(canonical(m))
    with pytest.raises(LedgerError, match="changed"):
        s.freeze(prepared, ready, tmp_path/"forbidden")
    assert not (tmp_path/"forbidden").exists()


def test_scoped_analysis_keeps_QA_provenance_without_promoting_the_whole_corpus(tmp_path):
    prepared, _, ready, _ = fixture(tmp_path)
    cohort = tmp_path/"scoped-cohort"; s.freeze(prepared, ready, cohort)
    plan = tmp_path/"analysis-plan"
    output = s.prepare_analysis(cohort, prepared/"private/evaluator_case_index.jsonl", "base-group", plan)
    spec = comparison.load_plan(plan)
    assert output["selected_human_QA_questions"] == 1 and output["human_verified_memory_labels"] == 0
    assert spec["basis"] == "AI_exploratory" and spec["execution_enabled"] is False
    assert len(spec["cells"]) == 3 and all(c["audit_tickets"] == 5 for c in spec["cells"])
    assert f.read(plan/"annotation_provenance.json")["selected_human_QA_questions"] == 1
    analysis = comparison.analyse(spec, [], resamples=10)
    assert analysis["recorded_query_outcomes"] == 0 and analysis["scientifically_human_validated"] is False
    assert analysis["status"] == "incomplete_saved_outcomes"
    with pytest.raises(LedgerError, match="Unrecognized frozen AI cohort"):
        comparison.prepare(cohort, prepared/"private/evaluator_case_index.jsonl", "g", tmp_path/"old-contract")
    assert not (tmp_path/"old-contract").exists()
    selected = cohort/"private/selection.json"
    selected.write_text(selected.read_text()+" ")
    with pytest.raises(LedgerError, match="dependency changed"):
        comparison.load_plan(plan)


def test_scoped_review_cannot_turn_a_source_bundle_into_human_gold(tmp_path):
    prepared, _, ready, _ = fixture(tmp_path)
    cohort = tmp_path/"cohort"; s.freeze(prepared, ready, cohort)
    path=cohort/"private/selection.json"; body=f.read(path);body["human_verified_labels"]=1;path.write_text(canonical(body))
    m=f.read(cohort/"manifest.json");m["files"]["private/selection.json"]=sha_file(path);m["hash"]=digest(m["files"])
    (cohort/"manifest.json").write_text(canonical(m))
    with pytest.raises(LedgerError, match="promoted"):
        s.verify(cohort)


def test_changed_memory_text_cannot_reuse_an_AI_safety_assessment(tmp_path):
    prepared, _, ready, _ = fixture(tmp_path)
    path=prepared/"private/review_packets.jsonl"; packets=list(map(json.loads,path.open()))
    packets[0]["records"][0]["text"] += " changed"
    path.write_text("".join(canonical(p)+"\n" for p in packets))
    with pytest.raises(LedgerError, match="packet changed|memory version"):
        s.freeze(prepared, ready, tmp_path/"forbidden")
    assert not (tmp_path/"forbidden").exists()


def test_human_QA_metadata_cannot_be_erased_by_updating_only_summary_counts(tmp_path):
    prepared, _, ready, _ = fixture(tmp_path)
    cohort=tmp_path/"cohort"; s.freeze(prepared, ready, cohort)
    selected=cohort/"private/selection.json"; a=f.read(selected);a["human_validated_questions"]=0;selected.write_text(canonical(a))
    provenance=cohort/"private/annotation_provenance.json"; b=f.read(provenance)
    b.update(selected_human_QA_questions=0, selected_human_QA_candidate_ids=[], selected_AI_QA_questions=16)
    provenance.write_text(canonical(b))
    m=f.read(cohort/"manifest.json")
    for p in [selected,provenance]:m["files"][str(p.relative_to(cohort))]=sha_file(p)
    m["hash"]=digest(m["files"]);(cohort/"manifest.json").write_text(canonical(m))
    with pytest.raises(LedgerError, match="Question catalog/review provenance"):
        s.verify(cohort)
