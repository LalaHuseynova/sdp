"""Mock-only unit extension engine; production freeze is independently checked."""

import json

import httpx
import pytest

from ams.research import provisional_extension as ext
from ams.research.dynamic.models import LedgerError
from ams.research.provisional_run.preparation import verify as verify_fixture
from test_dynamic_execution import reply
from test_dynamic_native import example, offline  # noqa: F401
from test_provisional_run import fixture_plan


def test_extension_engine_uses_existing_helpers_and_restarts_without_duplicate_requests(
    tmp_path,
    example,  # noqa: F811
    monkeypatch,
):
    plan, _ = fixture_plan(tmp_path, example)
    for file in (plan / "private").glob("ep_*.json"):
        value = json.loads(file.read_text())
        value["write_diagnostics"] = []
        file.write_text(json.dumps(value))
    # Re-pin the explicitly artificial fixture after adding optional diagnostics.
    from ams.research.dynamic.models import digest
    from ams.research.recovery.offline import sha_file

    manifest = json.loads((plan / "manifest.json").read_text())
    manifest["files"] = {n: sha_file(plan / n) for n in manifest["files"]}
    manifest["hash"] = digest(manifest["files"])
    (plan / "manifest.json").write_text(json.dumps(manifest))
    # Unit dependency injection supplies the smaller test-fixture matrix only;
    # production CLI always uses ext.verify's strict seven-group contract.
    monkeypatch.setattr(ext, "verify", verify_fixture)
    seen = []

    def handler(request):
        body = json.loads(request.content)
        seen.append(body)
        return reply(
            text="NO\nInvented judgment" if body["max_tokens"] == 120 else "Invented answer"
        )

    out = tmp_path / "result"
    with ext.memoized_evidence_revisions():
        first = ext.run(plan, out, mock=httpx.MockTransport(handler))
    count = len(seen)
    with ext.memoized_evidence_revisions():
        second = ext.run(plan, out, mock=httpx.MockTransport(handler))
    assert first["status"] == second["status"] == "complete_saved_outcomes"
    assert first["outcomes"] == 18 and len(seen) == count
    assert first["costs"]["project_used_usd"] == second["costs"]["project_used_usd"]


def test_extension_rejects_old_three_cell_scope(tmp_path, example):  # noqa: F811
    plan, _ = fixture_plan(tmp_path, example)
    with pytest.raises(LedgerError, match="extension manifest"):
        ext.verify(plan)


def test_extension_never_overwrites_existing_output(tmp_path):
    with pytest.raises(LedgerError, match="overwrite"):
        ext.prepare(tmp_path, tmp_path)
