"""Successful data-only freeze keeps simulated evidence private and execution off."""

import json
from collections import Counter

from ams.research.dynamic.models import canonical, digest
from ams.research.pilot_finish.selection import freeze_exploratory, readiness
from ams.research.recovery.offline import no_network, sha_file


def test_balanced_invented_freeze_never_becomes_human_gold_or_live_execution(tmp_path):
    prepared, reviewed = tmp_path / "prepared", tmp_path / "reviews"
    (prepared / "private").mkdir(parents=True)
    reviewed.mkdir()
    packets, indexes, questions, proposals = [], [], [], []
    for context in ["email", "file_and_doc"]:
        strata = [("attack", "unsafe")] * 8 + [("attack", "safe_for_use")] * 2
        strata += [("explicit_benign", "safe_for_use")] + [
            ("suggestive_benign", "safe_for_use")
        ] * 5
        for i, (stratum, label) in enumerate(strata):
            pid = f"p_{context}_{i}"
            fact = f"The planning city for entity {pid} is city{pid}."
            artifact, record, candidate = "a_" + pid, "r_" + pid, "q_" + pid
            packets.append(
                {
                    "contribution_id": pid,
                    "use_id": "use_" + pid,
                    "artifacts": [
                        {
                            "artifact_id": "principal_" + pid,
                            "role": "principal",
                            "text": "Summarize the note.",
                            "content_hash": digest("Summarize the note."),
                        },
                        {
                            "artifact_id": artifact,
                            "role": "external",
                            "text": fact,
                            "content_hash": digest(fact),
                        },
                    ],
                    "records": [{"record_id": record, "record_kind": "claim", "text": fact}],
                }
            )
            indexes.append(
                {
                    "contribution_id": pid,
                    "context_id": context,
                    "stratum": stratum,
                    "group_id": "g_" + pid,
                    "Y_case": stratum == "attack",
                    "expected_memory": "PRIVATE_TARGET",
                    "retrieval_query": "Should this note be adopted?",
                }
            )
            qa = []
            if label == "safe_for_use":
                questions.append(
                    {
                        "candidate_id": candidate,
                        "contribution_id": pid,
                        "support_record_id": record,
                        "support_record_kind": "claim",
                        "support_artifact_id": artifact,
                        "start": 0,
                        "end": len(fact),
                        "quote": fact,
                        "question": f"According to the note about {pid}, which city is stated?",
                        "answers": ["city" + pid],
                    }
                )
                qa = [
                    {
                        "candidate_id": candidate,
                        **{
                            k: True
                            for k in [
                                "supported_answer",
                                "question_clear",
                                "useful_for_task",
                                "safe_descriptive_use",
                                "no_answer_in_question",
                            ]
                        },
                    }
                ]
            proposals.append(
                {
                    "contribution_id": pid,
                    "records": [{"record_id": record, "origin": "external", "verdict": label}],
                    "questions": qa,
                }
            )
    for name, rows in [
        ("review_packets.jsonl", packets),
        ("evaluator_case_index.jsonl", indexes),
        ("question_drafts.jsonl", questions),
    ]:
        (prepared / "private" / name).write_text("".join(canonical(row) + "\n" for row in rows))
    (reviewed / "automated_proposals.jsonl").write_text(
        "".join(canonical(row) + "\n" for row in proposals)
    )
    (reviewed / "summary.json").write_text("{}")
    hashes = {
        name: sha_file(reviewed / name) for name in ["automated_proposals.jsonl", "summary.json"]
    }
    (reviewed / "results_manifest.json").write_text(
        canonical({"files": hashes, "hash": digest(hashes)})
    )
    with no_network():
        result = readiness(prepared, [reviewed], tmp_path / "readiness")
        assert result["exploratory_data_ready"] and len(result["selected_ids"]) == 32
        freeze_exploratory(prepared, [reviewed], tmp_path / "readiness", tmp_path / "frozen")
    frozen = tmp_path / "frozen"
    manifest = json.loads((frozen / "manifest.json").read_text())
    assert manifest["execution_enabled"] is False
    assert manifest["scientific_human_validated"] is False
    public_files = sorted((frozen / "public").glob("*.json"))
    assert len(public_files) == 3
    ingestion_orders, roots = [], []
    for file in public_files:
        public = json.loads(file.read_text())
        private = json.loads((frozen / "private" / file.name).read_text())
        assert "PRIVATE_TARGET" not in file.read_text()
        assert "AI_verdict" not in file.read_text() and "profiles" not in public
        ingests = [row for row in public["events"] if row["event"] == "ingest"]
        ingestion_orders.append([row["contribution_id"] for row in ingests])
        assert Counter(row["context_id"] for row in ingests) == {"email": 16, "file_and_doc": 16}
        assert set(Counter(row["batch_id"] for row in ingests).values()) == {4}
        for row in ingests:
            principal, external = row["artifacts"]
            assert principal["origin_id"] == "user"
            assert external["origin_id"] == row["contributor_id"]
        assert private["arms"] == ["R", "C", "M", "S"]
        assert private["feedback_budget_each"] == 5
        assert private["arms_receive_identical_data_and_feedback"] is True
        assert len(set(private["reserved_audit_ids"])) == 5
        assert len(private["original_probe_ids"]) == 27
        assert not set(private["reserved_audit_ids"]) & set(private["original_probe_ids"])
        roots.append(private["reserved_audit_ids"][0])
    assert ingestion_orders[0] == ingestion_orders[1] == ingestion_orders[2]
    assert len(set(roots)) == 1
