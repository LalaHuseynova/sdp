"""Offline accounting tests. No providers, credentials, or network are used."""

from __future__ import annotations

import json
import multiprocessing
import sqlite3
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
from pathlib import Path

from ams.llm.budget import BudgetAccountingError, BudgetExhausted, BudgetGuard

MODEL = "openai/gpt-4o-mini"


def reserve_from_process(path, queue):
    try:
        guard = BudgetGuard(path, "0.0384012")
        queue.put(bool(guard.reserve(MODEL, 1)))
    except BudgetExhausted:
        queue.put(False)


class BudgetGuardTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / "budget.sqlite"

    def test_worst_case_reservation_then_authoritative_settlement(self):
        guard = BudgetGuard(self.path, 25)
        reservation = guard.reserve(MODEL, 900)
        held = guard.snapshot()
        self.assertEqual(held["held_nanodollars"], 19_740_000)
        self.assertEqual(held["used_nanodollars"], 0)
        self.assertEqual(held["counts"]["pending"], 1)
        metadata = {
            "generation_id": "gen-example",
            "model": MODEL,
            "input_tokens": 500,
            "output_tokens": 40,
        }
        guard.settle(reservation, Decimal("0.000099"), metadata)
        settled = guard.snapshot()
        self.assertEqual(settled["used_nanodollars"], 99_000)
        self.assertEqual(settled["held_nanodollars"], 0)
        self.assertEqual(settled["remaining_nanodollars"], 25_000_000_000 - 99_000)
        self.assertEqual(settled["counts"]["settled"], 1)
        json.dumps(settled, allow_nan=False)

    def test_unknown_attempt_and_restart_never_release_reservation(self):
        guard = BudgetGuard(self.path, "0.025")
        reservation = guard.reserve(MODEL, 100)
        guard.mark_unknown(reservation, "APIConnectionError")
        before = guard.snapshot()
        restarted = BudgetGuard(self.path, "0.025")
        self.assertEqual(restarted.snapshot(), before)
        self.assertEqual(before["counts"]["unknown"], 1)
        with self.assertRaises(BudgetExhausted):
            restarted.reserve(MODEL, 100)
        # An independently recovered authoritative charge can resolve ambiguity.
        restarted.settle(reservation, "0.0001", {"generation_id": "gen-recovered"})
        self.assertEqual(restarted.snapshot()["held_nanodollars"], 0)

    def test_crash_pending_reservation_survives_reinitialization(self):
        guard = BudgetGuard(self.path, "0.025")
        guard.reserve(MODEL, 900)
        restarted = BudgetGuard(self.path, "0.025")
        self.assertEqual(restarted.snapshot()["counts"]["pending"], 1)
        with self.assertRaises(BudgetExhausted):
            restarted.reserve(MODEL, 900)
        with self.assertRaises(BudgetAccountingError):
            BudgetGuard(self.path, 25)

    def test_thread_reservations_are_atomic(self):
        guard = BudgetGuard(self.path, "0.0384012")

        def attempt(_):
            try:
                return guard.reserve(MODEL, 1)
            except BudgetExhausted:
                return None

        with ThreadPoolExecutor(max_workers=16) as pool:
            tokens = list(pool.map(attempt, range(16)))
        self.assertEqual(sum(t is not None for t in tokens), 2)
        snapshot = guard.snapshot()
        self.assertEqual(snapshot["counts"]["total"], 2)
        self.assertEqual(snapshot["remaining_nanodollars"], 0)
        self.assertLessEqual(snapshot["committed_nanodollars"], snapshot["limit_nanodollars"])

    def test_processes_share_one_persistent_allowance(self):
        guard = BudgetGuard(self.path, "0.0384012")
        context = multiprocessing.get_context("spawn")
        queue = context.Queue()
        processes = [
            context.Process(target=reserve_from_process, args=(str(self.path), queue))
            for _ in range(4)
        ]
        try:
            for process in processes:
                process.start()
            results = [queue.get(timeout=20) for _ in processes]
            for process in processes:
                process.join(timeout=20)
                self.assertEqual(process.exitcode, 0)
            self.assertEqual(sum(results), 2)
            self.assertEqual(guard.snapshot()["remaining_nanodollars"], 0)
        finally:
            for process in processes:
                if process.is_alive():
                    process.terminate()
                    process.join()
            queue.close()

    def test_repeated_settlement_does_not_double_debit_or_release(self):
        guard = BudgetGuard(self.path, 25)
        reservation = guard.reserve(MODEL, 900)
        guard.settle(reservation, "0.01", {"generation_id": "gen-one"})
        before = guard.snapshot()
        guard.settle(reservation, "0.01")
        guard.mark_unknown(reservation, "late_callback")
        self.assertEqual(guard.snapshot(), before)

    def test_cost_above_reservation_is_recorded_then_blocks_every_further_attempt(self):
        guard = BudgetGuard(self.path, 25)
        reservation = guard.reserve(MODEL, 900)
        with self.assertRaisesRegex(BudgetAccountingError, "exceeded"):
            guard.settle(reservation, "0.02", {"generation_id": "gen-breach"})
        guard.mark_unknown(reservation, "BudgetAccountingError")
        snapshot = guard.snapshot()
        self.assertTrue(snapshot["blocked"])
        self.assertEqual(snapshot["counts"]["breach"], 1)
        self.assertEqual(snapshot["used_nanodollars"], 20_000_000)
        self.assertEqual(snapshot["held_nanodollars"], 0)
        with self.assertRaises(BudgetAccountingError):
            BudgetGuard(self.path, 25).reserve(MODEL, 1)

    def test_cost_above_total_allowance_is_not_hidden_or_clamped(self):
        guard = BudgetGuard(self.path, 25)
        reservation = guard.reserve(MODEL, 900)
        with self.assertRaises(BudgetAccountingError):
            guard.settle(reservation, 26)
        snapshot = guard.snapshot()
        self.assertEqual(snapshot["used_usd"], 26)
        self.assertEqual(snapshot["overrun_usd"], 1)
        self.assertEqual(snapshot["remaining_usd"], 0)

    def test_conflicting_settlement_blocks_and_retains_larger_charge(self):
        guard = BudgetGuard(self.path, 25)
        reservation = guard.reserve(MODEL, 900)
        guard.settle(reservation, "0.005")
        with self.assertRaisesRegex(BudgetAccountingError, "Conflicting"):
            guard.settle(reservation, "0.004")
        snapshot = guard.snapshot()
        self.assertEqual(snapshot["used_usd"], 0.005)
        self.assertTrue(snapshot["blocked"])

    def test_nan_infinite_and_invalid_request_bounds_fail_before_reservation(self):
        for value in ("NaN", "Infinity", "-Infinity", "-1", "0", True):
            with self.subTest(value=value), self.assertRaises(BudgetAccountingError):
                BudgetGuard(self.path, value)
        guard = BudgetGuard(self.path, 25)
        for limit in (0, -1, 16_385, 900.0, True):
            with self.subTest(limit=limit), self.assertRaises(BudgetAccountingError):
                guard.reserve(MODEL, limit)
        with self.assertRaises(BudgetAccountingError):
            guard.reserve("openai/gpt-5.6-terra", 900)
        with self.assertRaises(BudgetAccountingError):
            BudgetGuard(self.path, 25, context_token_bound=127_999)
        self.assertEqual(guard.snapshot()["counts"]["total"], 0)

    def test_invalid_authoritative_cost_keeps_reserve_and_blocks(self):
        guard = BudgetGuard(self.path, 25)
        reservation = guard.reserve(MODEL, 900)
        with self.assertRaises(BudgetAccountingError):
            guard.settle(reservation, "NaN")
        snapshot = guard.snapshot()
        self.assertTrue(snapshot["blocked"])
        self.assertEqual(snapshot["counts"]["unknown"], 1)
        self.assertEqual(snapshot["held_nanodollars"], 19_740_000)
        with self.assertRaises(BudgetAccountingError):
            guard.reserve(MODEL, 1)

    def test_metadata_rejects_prompts_and_api_secrets(self):
        guard = BudgetGuard(self.path, 25)
        reservation = guard.reserve(MODEL, 900)
        sensitive = "sk-or-v1-secret-test-marker"
        with self.assertRaises(BudgetAccountingError):
            guard.settle(reservation, "0.001", {"generation_id": sensitive})
        with sqlite3.connect(self.path) as conn:
            serialized = " ".join(str(row) for row in conn.execute("SELECT * FROM reservations"))
        self.assertNotIn(sensitive, serialized)
        with self.assertRaises(BudgetAccountingError):
            guard.settle(reservation, "0.001", {"messages": ["private prompt"]})

    def test_budget_rounds_allowance_down_and_charges_up(self):
        guard = BudgetGuard(self.path, "25.0000000009")
        reservation = guard.reserve(MODEL, 1)
        guard.settle(reservation, "0.0000000001")
        snapshot = guard.snapshot()
        self.assertEqual(snapshot["limit_nanodollars"], 25_000_000_000)
        self.assertEqual(snapshot["used_nanodollars"], 1)

    def test_inconsistent_persisted_totals_fail_closed_after_restart(self):
        guard = BudgetGuard(self.path, 25)
        guard.reserve(MODEL, 1)
        with sqlite3.connect(self.path) as conn:
            conn.execute("UPDATE budget_config SET held_nanodollars='0' WHERE singleton=1")
        with self.assertRaisesRegex(BudgetAccountingError, "disagree"):
            BudgetGuard(self.path, 25)
        with self.assertRaises(BudgetAccountingError):
            guard.snapshot()

    def test_explicit_halt_is_shared_persistent_and_does_not_release_pending_funds(self):
        guard = BudgetGuard(self.path, 27)
        reservation = guard.reserve(MODEL, 900)
        guard.halt("unverified_billing")
        before = guard.snapshot()
        self.assertTrue(before["blocked"])
        self.assertEqual(before["held_nanodollars"], 19_740_000)
        restarted = BudgetGuard(self.path, 27)
        with self.assertRaises(BudgetAccountingError):
            restarted.reserve(MODEL, 900)
        restarted.settle(reservation, "0.001")
        self.assertEqual(restarted.snapshot()["held_nanodollars"], 0)
        self.assertTrue(restarted.snapshot()["blocked"])
        with self.assertRaises(BudgetAccountingError):
            guard.reserve(MODEL, 900)

    def test_unknown_metadata_retains_identifiers_native_counts_and_entire_reservation(self):
        guard = BudgetGuard(self.path, 27)
        reservation = guard.reserve(MODEL, 900)
        guard.mark_unknown(
            reservation,
            "MissingBillingCost",
            metadata={
                "generation_id": "gen-missing",
                "request_id": "a" * 64,
                "model": MODEL,
                "input_tokens": 500,
                "output_tokens": 40,
                "estimated_cost_usd": 0.000099,
                "usage_details": {"cost_missing": True, "billing_verified": False},
            },
        )
        before = guard.snapshot()
        guard.mark_unknown(reservation, "InterruptedAfterBillingStop")
        guard.mark_unknown(reservation, "MissingBillingCost", metadata={"total_tokens": 540})
        with sqlite3.connect(self.path) as conn:
            row = conn.execute(
                "SELECT state,metadata,actual_nanodollars FROM reservations"
            ).fetchone()
        metadata = json.loads(row[1])
        self.assertEqual(row[0], "unknown")
        self.assertIsNone(row[2])
        self.assertEqual(metadata["generation_id"], "gen-missing")
        self.assertEqual(metadata["request_id"], "a" * 64)
        self.assertEqual(metadata["input_tokens"], 500)
        self.assertEqual(metadata["total_tokens"], 540)
        self.assertEqual(guard.snapshot()["held_nanodollars"], 19_740_000)
        self.assertEqual(guard.snapshot()["used_nanodollars"], 0)
        self.assertEqual(guard.snapshot()["committed_nanodollars"], before["committed_nanodollars"])

    def test_reviewed_resume_preserves_all_money_settings_and_attempt_records(self):
        guard = BudgetGuard(self.path, 27)
        settled = guard.reserve(MODEL, 900)
        guard.settle(settled, "0.001", {"generation_id": "gen-paid"})
        unresolved = guard.reserve(MODEL, 900)
        guard.mark_unknown(unresolved, "MissingBillingCost", {"generation_id": "gen-unknown"})
        guard.halt("unverified_billing")
        before = guard.snapshot()
        with sqlite3.connect(self.path) as conn:
            original_rows = conn.execute(
                "SELECT * FROM reservations ORDER BY reservation_id"
            ).fetchall()
            settings = conn.execute("SELECT settings FROM budget_config").fetchone()[0]
        guard.resume_after_review("software_estimate_review_missing_cost")
        after = BudgetGuard(self.path, 27).snapshot()
        self.assertFalse(after["blocked"])
        self.assertEqual(after["review_events"], 1)
        for key in (
            "used_nanodollars",
            "held_nanodollars",
            "committed_nanodollars",
            "remaining_nanodollars",
            "limit_nanodollars",
            "counts",
        ):
            self.assertEqual(after[key], before[key])
        with sqlite3.connect(self.path) as conn:
            self.assertEqual(
                conn.execute("SELECT settings FROM budget_config").fetchone()[0], settings
            )
            self.assertEqual(
                conn.execute("SELECT * FROM reservations ORDER BY reservation_id").fetchall(),
                original_rows,
            )
            event = conn.execute(
                "SELECT reason,previous_blocked_reason,resulting_blocked_reason,"
                "used_nanodollars,held_nanodollars FROM budget_review_events "
                "WHERE event_type='resume_after_review'"
            ).fetchone()
        self.assertEqual(
            event[:3], ("software_estimate_review_missing_cost", "unverified_billing", "")
        )
        self.assertEqual(int(event[3]), before["used_nanodollars"])
        self.assertEqual(int(event[4]), before["held_nanodollars"])
        guard.reserve(MODEL, 900)

    def test_review_cannot_clear_protected_halts_or_downgrade_them(self):
        for index, reason in enumerate(
            ("unexpected_response_model", "invalid_billing", "byok_billing")
        ):
            with self.subTest(reason=reason):
                guard = BudgetGuard(Path(self.tmp.name) / f"protected-{index}.sqlite", 27)
                guard.reserve(MODEL, 900)
                guard.halt(reason)
                guard.halt("unverified_billing")
                self.assertEqual(guard.snapshot()["blocked_reason"], reason)
                for expected in ("unverified_billing", reason):
                    with self.assertRaises(BudgetAccountingError):
                        guard.resume_after_review(
                            "review_attempt", expected_blocked_reason=expected
                        )
                self.assertEqual(guard.snapshot()["review_events"], 0)
                self.assertTrue(guard.snapshot()["blocked"])

    def test_review_never_repairs_a_breach_even_if_legacy_reason_was_overwritten(self):
        guard = BudgetGuard(self.path, 27)
        reservation = guard.reserve(MODEL, 900)
        with self.assertRaises(BudgetAccountingError):
            guard.settle(reservation, "0.02")
        # Simulate an older caller overwriting the reason; the durable breach remains.
        with sqlite3.connect(self.path) as conn:
            conn.execute("UPDATE budget_config SET blocked_reason='unverified_billing'")
        before = guard.snapshot()
        with self.assertRaisesRegex(BudgetAccountingError, "financial"):
            guard.resume_after_review("review_attempt")
        self.assertEqual(guard.snapshot(), before)

    def test_review_audits_totals_and_rejects_overcommitted_allowance(self):
        guard = BudgetGuard(self.path, 27)
        guard.reserve(MODEL, 900)
        guard.halt("unverified_billing")
        with sqlite3.connect(self.path) as conn:
            conn.execute("UPDATE budget_config SET held_nanodollars='0'")
        with self.assertRaisesRegex(BudgetAccountingError, "disagree"):
            guard.resume_after_review("review_attempt")
        with sqlite3.connect(self.path) as conn:
            conn.execute("UPDATE budget_config SET held_nanodollars='28000000000'")
            conn.execute("UPDATE reservations SET reserved_nanodollars=28000000000")
        with self.assertRaisesRegex(BudgetAccountingError, "exceed"):
            guard.resume_after_review("review_attempt")
        self.assertEqual(guard.snapshot()["review_events"], 0)
        self.assertEqual(guard.snapshot()["limit_usd"], 27)
        self.assertTrue(guard.snapshot()["blocked"])

    def test_concurrent_reviews_clear_once_and_keep_all_held_funds(self):
        guard = BudgetGuard(self.path, 27)
        guard.reserve(MODEL, 900)
        guard.halt("unverified_billing")

        def review(_):
            try:
                guard.resume_after_review("concurrent_review")
                return True
            except BudgetAccountingError:
                return False

        with ThreadPoolExecutor(max_workers=16) as pool:
            results = list(pool.map(review, range(16)))
        self.assertEqual(sum(results), 1)
        snapshot = guard.snapshot()
        self.assertEqual(snapshot["review_events"], 1)
        self.assertEqual(snapshot["held_nanodollars"], 19_740_000)
        self.assertEqual(snapshot["used_nanodollars"], 0)
        self.assertFalse(snapshot["blocked"])
        with self.assertRaises(BudgetAccountingError):
            guard.resume_after_review("repeat_review")

    def test_review_racing_with_protected_halt_cannot_unlock_the_protected_stop(self):
        guard = BudgetGuard(self.path, 27)
        guard.reserve(MODEL, 900)
        guard.halt("unverified_billing")

        def review():
            try:
                guard.resume_after_review("review_race")
            except BudgetAccountingError:
                pass

        with ThreadPoolExecutor(max_workers=2) as pool:
            review_future = pool.submit(review)
            halt_future = pool.submit(guard.halt, "unexpected_response_model")
            review_future.result()
            halt_future.result()
        self.assertTrue(guard.snapshot()["blocked"])
        self.assertEqual(guard.snapshot()["blocked_reason"], "unexpected_response_model")
        self.assertEqual(guard.snapshot()["held_nanodollars"], 19_740_000)
        with self.assertRaises(BudgetAccountingError):
            guard.reserve(MODEL, 900)


if __name__ == "__main__":
    unittest.main()
