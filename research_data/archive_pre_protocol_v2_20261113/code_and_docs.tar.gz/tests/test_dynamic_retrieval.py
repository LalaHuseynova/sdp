"""Retrieval software checks with invented data/exact replay, never an MPBench evaluation."""

from __future__ import annotations

import json
import socket
from dataclasses import asdict, replace

import pytest

from ams.core.lattice import Rung
from ams.eval.use_type import FixedUse
from ams.llm.types import ChatRequest, ChatResponse, EmbedRequest, EmbedResponse, Message
from ams.research.dynamic import Finding, LedgerError, Policy, Register, StoredRecord
from ams.research.dynamic.models import digest
from ams.research.retrieval import (
    AccessSnapshot,
    ArtifactGrant,
    BindingCatalog,
    GovernedRetrieval,
    RecordBinding,
)
from ams.research.retrieval.fixture import EPISODE, QUERY, SESSION, USE, build_fixture
from ams.research.retrieval.replay import ExactReplayClient


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def deny(*args, **kwargs):
        raise AssertionError("Offline retrieval checks forbid networking")

    for target in ("connect", "connect_ex"):
        monkeypatch.setattr(socket.socket, target, deny)
    monkeypatch.setattr(socket, "create_connection", deny)
    monkeypatch.setattr(socket, "getaddrinfo", deny)


def adapter(f, arm="S", **kwargs):
    return GovernedRetrieval(f.memory, f.bindings, Policy(arm), **kwargs)


def read(f, arm="S", *, context=None, k=4, **kwargs):
    return adapter(f, arm, **kwargs).retrieve_with_trace(
        session_id=SESSION, query=QUERY, context=context or f.context(), k=k
    )


def deny_artifacts(f, ids, *, version="v1", requester="user"):
    return AccessSnapshot(
        version,
        tuple(
            replace(g, readers=tuple(x for x in g.readers if x != requester))
            if g.artifact_id in ids
            else g
            for g in f.access.grants
        ),
    )


@pytest.mark.parametrize("external", [False, True])
@pytest.mark.parametrize("conflicting", [False, True])
@pytest.mark.parametrize("k", [0, 1, 4, 20])
def test_disabled_parity_matches_original_entries_verdicts_and_prompt(
    tmp_path, external, conflicting, k
):
    original = build_fixture(
        tmp_path / "original", external_evidence=external, conflicting=conflicting
    )
    research = build_fixture(
        tmp_path / "research", external_evidence=external, conflicting=conflicting
    )
    expected = original.memory.retrieve(session_id=SESSION, query=QUERY, k=k)
    outcome = read(research, effects_enabled=False, k=k)
    assert outcome.retrieval == expected
    assert outcome.trace.supplied_context == tuple(e.text for e in expected.entries)
    template = original.memory.prompts.get("answer_typed", "v2")
    # The original answer_fn uses bullet-prefixed sentinels and an explicit empty marker.
    assert template.render(
        query=QUERY,
        required=expected.required or "description",
        memory="\n".join(f"- {e.text}" for e in expected.entries) or "(nothing)",
    ) == template.render(
        query=QUERY,
        required=outcome.retrieval.required or "description",
        memory="\n".join(f"- {text}" for text in outcome.trace.supplied_context) or "(nothing)",
    )
    original_chat = [r for r in original.memory.client.requests if type(r) is ChatRequest]
    research_chat = [r for r in research.memory.client.requests if type(r) is ChatRequest]
    assert research_chat == original_chat
    assert outcome.trace.contested_after == tuple(
        (c.claim_id, c.contested) for c in original.memory._graph(SESSION).claims()
    )


def test_enabled_no_evidence_matches_original_reproduced_settings(tmp_path):
    f = build_fixture(tmp_path / "book")
    expected = f.memory.retrieve(session_id=SESSION, query=QUERY)
    for arm in "RCMS":
        assert read(f, arm).retrieval == expected
        assert read(f, arm).trace.evidence_revision == f.ledger.snapshot().revision


def test_permissions_filter_before_conflict_model_and_refill_both_paths(tmp_path):
    f = build_fixture(tmp_path / "book", external_evidence=True, conflicting=True)
    context = f.context(access=deny_artifacts(f, {"artifact-0"}))
    outcome = read(f, context=context)
    assert [e.entry_id for e in outcome.retrieval.entries] == [
        "c1",
        "c2",
        "c3",
        "c4",
        "e1",
        "e2",
        "e3",
        "e4",
    ]
    assert not any(type(req) is ChatRequest for req in f.memory.client.requests)
    assert "Artificial note 0" not in "\n".join(outcome.trace.supplied_context)
    assert outcome.trace.claim_replacements == outcome.trace.chunk_replacements == 1
    assert not f.memory._graph(SESSION).claim("c0").contested
    assert all(
        t.decision.reason == "acl_denied" and not t.selected
        for t in outcome.trace.candidates
        if t.native_id in {"c0", "e0"}
    )


@pytest.mark.parametrize("arm", list("RCMS"))
def test_direct_unsafe_blocks_claim_and_chunk_before_conflict_and_refills(tmp_path, arm):
    f = build_fixture(tmp_path / "book", external_evidence=True, conflicting=True)
    f.ledger.append(f.audit("root-0"))
    outcome = read(f, arm)
    assert len(outcome.retrieval.entries) == 8
    assert {"c0", "e0"}.isdisjoint(outcome.trace.selected_ids)
    assert not any(type(req) is ChatRequest for req in f.memory.client.requests)
    assert outcome.trace.claim_replacements == outcome.trace.chunk_replacements == 1
    assert f.ledger.snapshot().usage.tickets == 1


def test_rank_penalty_and_scope_selection_change_actual_retrieval(tmp_path):
    f = build_fixture(tmp_path / "book", external_evidence=True)
    f.ledger.append(f.audit("root-0"))
    r, c, s = (read(f, arm, k=2) for arm in "RCS")
    assert r.trace.selected_ids[:2] == ("c1", "c2")
    # Context C penalizes both; S only penalizes the batch supported by the incident.
    assert s.trace.selected_ids[:2] == ("c2", "c1")
    assert c.trace.candidates[2].decision.penalty > 0
    assert s.trace.candidates[2].decision.penalty == 0
    assert s.trace.candidates[2].decision.active_scopes == ()
    assert all(o.trace.evidence_revision == r.trace.evidence_revision for o in (c, s))


def test_gate_allows_refill_past_original_top_k(tmp_path):
    f = build_fixture(tmp_path / "book", external_evidence=True)
    f.ledger.append(f.audit("root-0"))
    f.ledger.append(f.audit("root-1", event="a2", at=2))
    # Two unsafe roots in one batch: C/M gate the contributor/context; S gates only that batch.
    c, s = read(f, "C"), read(f, "S")
    assert "c2" not in c.trace.selected_ids and "c2" in s.trace.selected_ids
    assert len(c.retrieval.entries) == len(s.retrieval.entries) == 8
    assert c.trace.claim_replacements >= 2
    assert s.trace.candidates[2].decision.eligible


def test_verified_safe_exception_stays_subject_to_current_permissions(tmp_path):
    f = build_fixture(tmp_path / "book", external_evidence=True)
    for i in range(2):
        f.ledger.append(f.audit(f"root-{i}", event=f"a{i}", at=i + 1))
    # Fully safe independent sibling would reduce group d; use a partial local review instead.
    record = f.records["root-2"][0]
    check = replace(
        f.audit("root-2", "unresolved", event="safe", at=3),
        complete_bundle=False,
        findings=(
            Finding(record.record_id, record.content_hash, "safe_for_use", "fixture://local-only"),
        ),
    )
    f.ledger.append(check)
    outcome = read(f, "C")
    assert "c2" in outcome.trace.selected_ids and "e2" not in outcome.trace.selected_ids
    denied = read(f, "C", context=f.context(access=deny_artifacts(f, {"artifact-2"})))
    assert {"c2", "e2"}.isdisjoint(denied.trace.selected_ids)
    changed = read(f, "C", context=f.context(access=replace(f.access, version="v2")))
    assert "c2" not in changed.trace.selected_ids


def test_revocation_rechecked_despite_identical_query_and_embedding_cache(tmp_path):
    f = build_fixture(tmp_path / "book", external_evidence=True)
    first = read(f, context=f.context(requester="R1"))
    access = deny_artifacts(f, {"artifact-0"}, requester="R1", version="v2")
    second = read(f, context=f.context(access=access, requester="R1"))
    assert "c0" in first.trace.selected_ids and "c0" not in second.trace.selected_ids
    assert "e0" in first.trace.selected_ids and "e0" not in second.trace.selected_ids
    assert first.trace.access_hash != second.trace.access_hash
    assert first.trace.principal == second.trace.principal == "user"
    assert first.trace.requester == second.trace.requester == "R1"
    assert first.trace.query_hash == second.trace.query_hash


def test_permissions_bind_even_when_research_effects_are_disabled(tmp_path):
    f = build_fixture(tmp_path / "book", external_evidence=True)
    outcome = read(
        f, effects_enabled=False, context=f.context(access=deny_artifacts(f, {"artifact-0"}))
    )
    assert {"c0", "e0"}.isdisjoint(outcome.trace.selected_ids)
    assert len(outcome.retrieval.entries) == 8


def test_original_authority_and_external_chunk_flag_cannot_be_raised_by_safe_labels(tmp_path):
    f = build_fixture(tmp_path / "book")
    f.memory.use_type = FixedUse(Rung.PREFERENCE)
    f.ledger.append(f.audit("root-0", "safe_for_use"))
    outcome = read(f)
    assert "c0" not in outcome.trace.selected_ids and "e0" not in outcome.trace.selected_ids
    assert not outcome.retrieval.entries or all(
        e.metadata.get("evidence") for e in outcome.retrieval.entries
    )
    # Principal chunks can answer at the requested original standing.
    assert {e.entry_id for e in outcome.retrieval.entries} == {"e6", "e7", "e8", "e9"}


def test_parent_policy_intersection_for_chunks_and_copy_artifacts(tmp_path):
    f = build_fixture(tmp_path / "book", external_evidence=True)
    grants = tuple(
        replace(g, parents=("restricted-parent",)) if g.artifact_id == "artifact-0" else g
        for g in f.access.grants
    )
    access = AccessSnapshot(
        "v2", (*grants, ArtifactGrant("restricted-parent", ("user",), ("read",)))
    )
    r1 = read(f, context=f.context(access=access, requester="R1"))
    assert {"c0", "e0"}.isdisjoint(r1.trace.selected_ids)
    p0 = read(f, context=f.context(access=access))
    assert {"c0", "e0"} <= set(p0.trace.selected_ids)
    # A chunk spanning two sources inherits both parent policies.
    chunk = f.memory._chunks[SESSION][0]
    f.memory._chunks[SESSION][0] = replace(chunk, source_ids=("s0", "s1"))
    records = tuple(
        replace(r, source_ids=("s0", "s1"), artifact_ids=("artifact-0", "artifact-1"))
        if r.native_id == "e0"
        else r
        for r in f.bindings.records
    )
    f.bindings = replace(f.bindings, records=records)
    r1 = read(
        f,
        context=f.context(access=deny_artifacts(f, {"artifact-1"}, requester="R1"), requester="R1"),
    )
    assert "e0" not in r1.trace.selected_ids


def test_uncertain_attribution_never_uses_heuristic_source_as_culpable_author(tmp_path):
    f = build_fixture(tmp_path / "book", external_evidence=True)
    f.ledger.append(f.audit("root-5"))
    snap = f.ledger.snapshot()
    assert snap.group("source", "innocent-uploader").unsafe == 0
    assert snap.observations() == ()
    outcome = read(f, "M")
    assert {"c5", "e5"}.isdisjoint(outcome.trace.selected_ids)
    assert all(t.decision.penalty == 0 for t in outcome.trace.candidates)


@pytest.mark.parametrize(
    "change",
    [
        "missing_record",
        "changed_claim",
        "changed_source",
        "future_source",
        "missing_grant",
        "different_episode",
        "unregistered_version",
        "principal_as_contributor",
        "derived_claim",
    ],
)
def test_invalid_or_stale_binding_stops_before_any_model_or_embedding_call(tmp_path, change):
    f = build_fixture(tmp_path / "book", external_evidence=True, conflicting=True)
    context = f.context()
    if change == "missing_record":
        f.bindings = replace(f.bindings, records=f.bindings.records[1:])
    elif change == "changed_claim":
        f.memory._graph(SESSION).claim("c0").text = "Changed text"
    elif change == "changed_source":
        graph = f.memory._graph(SESSION)
        graph.add_source(replace(graph.source("s0"), text="Changed source"))
    elif change == "future_source":
        f.bindings = replace(
            f.bindings,
            sources=(*f.bindings.sources, replace(f.bindings.sources[0], source_id="not-ingested")),
        )
    elif change == "missing_grant":
        context = f.context(access=replace(f.access, grants=f.access.grants[1:]))
    elif change == "different_episode":
        f.bindings = replace(f.bindings, episode_id="another-episode")
    elif change == "unregistered_version":
        # Both live content and binding agree, but the ledger has no such version.
        f.memory._graph(SESSION).claim("c0").text = "Changed text"
        f.bindings = replace(
            f.bindings,
            records=tuple(
                replace(r, content_hash=digest("Changed text")) if r.native_id == "c0" else r
                for r in f.bindings.records
            ),
        )
    elif change == "principal_as_contributor":
        f.bindings = replace(
            f.bindings,
            records=tuple(
                replace(r, origin_class="external") if r.native_id == "c6" else r
                for r in f.bindings.records
            ),
        )
    elif change == "derived_claim":
        f.memory._graph(SESSION).claim("c0").derived_from = ("c1",)
    with pytest.raises(LedgerError):
        read(f, context=context)
    assert f.memory.client.requests == f.memory.embed_client.requests == []


@pytest.mark.parametrize(
    "change",
    [
        {"mode": "confine"},
        {"mode": "off"},
        {"hops": 1},
        {"index": "hnsw"},
        {"index": "partitioned"},
    ],
)
def test_unsupported_paths_rejected_including_after_construction(tmp_path, change):
    f = build_fixture(tmp_path / "book")
    a = adapter(f)
    for key, value in change.items():
        setattr(f.memory, key, value)
    with pytest.raises(LedgerError, match="flat.*withhold.*hops"):
        a.retrieve(session_id=SESSION, query=QUERY, context=f.context())
    assert f.memory.embed_client.requests == []


def test_common_candidate_cap_limits_refill_identically_and_does_not_refund_audits(tmp_path):
    f = build_fixture(tmp_path / "book", external_evidence=True)
    f.ledger.append(f.audit("root-0"))
    for arm in "RCMS":
        outcome = read(f, arm, claim_candidate_cap=4, chunk_candidate_cap=4)
        assert len(outcome.retrieval.entries) == 6
        assert {t.native_id for t in outcome.trace.candidates if t.in_candidate_pool} == {
            "c0",
            "c1",
            "c2",
            "c3",
            "e0",
            "e1",
            "e2",
            "e3",
        }
        assert all(t.decision.consumed_tickets == 1 for t in outcome.trace.candidates)


def test_correction_recovery_and_delayed_snapshot_are_not_served_from_stale_results(tmp_path):
    f = build_fixture(tmp_path / "book", external_evidence=True)
    old = f.context()
    f.ledger.append(f.audit("root-0", at=10))
    blocked = read(f)
    assert "c0" not in blocked.trace.selected_ids
    assert "c0" in read(f, context=old).trace.selected_ids
    f.ledger.append(f.audit("root-0", "safe_for_use", event="correction", at=11, supersedes="a1"))
    restored = read(f)
    assert {"c0", "e0"} <= set(restored.trace.selected_ids)
    assert restored.trace.evidence_revision != blocked.trace.evidence_revision
    assert f.ledger.snapshot().usage.tickets == 2


def test_exact_replay_miss_cannot_download_or_call_api(tmp_path):
    f = build_fixture(tmp_path / "book")
    with pytest.raises(LedgerError, match="embedding replay miss"):
        adapter(f).retrieve(session_id=SESSION, query="not captured", context=f.context())
    client = ExactReplayClient(key_provider="fixture")
    with pytest.raises(LedgerError, match="chat replay miss"):
        client.complete(ChatRequest((Message("user", "uncaptured"),), "fixture"))


def test_blinded_binding_import_rejects_gold_and_native_collision(tmp_path):
    f = build_fixture(tmp_path / "book")
    public = {
        "episode_id": f.bindings.episode_id,
        "sources": [asdict(s) for s in f.bindings.sources],
        "records": [asdict(r) for r in f.bindings.records],
    }
    public = json.loads(json.dumps(public))
    assert BindingCatalog.from_dict(public) == f.bindings
    with pytest.raises(LedgerError, match="Unexpected catalog"):
        BindingCatalog.from_dict({**public, "expected_memory": "must remain private"})
    public["records"][0]["Y_case"] = "adversarial"
    with pytest.raises(LedgerError, match="fields"):
        BindingCatalog.from_dict(public)
    with pytest.raises(LedgerError, match="Duplicate native"):
        replace(f.bindings, records=(*f.bindings.records, f.bindings.records[0]))


def test_incomplete_or_cyclic_acl_inheritance_is_rejected():
    with pytest.raises(LedgerError, match="Missing parent"):
        AccessSnapshot("v1", (ArtifactGrant("copy", ("user",), ("read",), ("missing",)),))
    with pytest.raises(LedgerError, match="Cyclic"):
        AccessSnapshot(
            "v1",
            (
                ArtifactGrant("a", ("user",), ("read",), ("b",)),
                ArtifactGrant("b", ("user",), ("read",), ("a",)),
            ),
        )


def test_original_source_caps_and_common_research_refill(tmp_path):
    f = build_fixture(tmp_path / "book", source_cap=1, evidence_slots=0)
    graph = f.memory._graph(SESSION)
    # A second independent claim from the same artifact; no additional source vote.
    graph.add_claim(replace(graph.claim("c0"), claim_id="extra"))
    f.memory._vectors[SESSION].add(["extra"], [(1.0, 0.0)])
    logical = StoredRecord(
        "logical-extra", digest(graph.claim("extra").text), "claim", "artifact-0"
    )
    f.ledger.append(Register("register-extra", 0, f.ledger.snapshot().roots["root-0"], (logical,)))
    f.bindings = replace(
        f.bindings,
        records=(
            *f.bindings.records,
            RecordBinding(
                SESSION,
                "extra",
                logical.record_id,
                logical.content_hash,
                "claim",
                ("s0",),
                ("artifact-0",),
                "external",
            ),
        ),
    )
    original = f.memory.retrieve(session_id=SESSION, query=QUERY, k=4)
    assert len(original.entries) == 3  # original takes top-k then applies source_cap
    assert read(f, effects_enabled=False).retrieval == original
    for arm in "RCMS":
        result = read(f, arm)
        assert len(result.retrieval.entries) == 4
        assert sum(e.parent_ids == ("s0",) for e in result.retrieval.entries) == 1


def test_actual_original_write_chunk_build_and_typed_retrieval_are_connected(tmp_path):
    from ams.core.prompts import PromptLibrary
    from ams.memory.typed import TypedStandingMemory
    from ams.research.dynamic import EvidenceLedger, Provenance
    from ams.research.retrieval import RetrievalContext, SourceBinding

    text = "Artificial project Cedar has fixture status green."
    prompts = PromptLibrary()
    extract = prompts.get("extract_typed_claims", "v1").render(query="", context=text, max_claims=6)
    req = ChatRequest((Message("user", extract),), "fixture-chat", temperature=0.0, max_tokens=900)
    client = ExactReplayClient(
        key_provider="fixture",
        chats={
            req.cache_key("fixture"): ChatResponse(
                json.dumps({"claims": [{"text": text, "type": "description", "subject": "Cedar"}]}),
                "fixture-chat",
                "fixture",
                cached=True,
            )
        },
        embeddings={
            EmbedRequest((q,), "fixture-embed").cache_key("fixture"): EmbedResponse(
                ((1.0, 0.0),), "fixture-embed", "fixture", cached=True
            )
            for q in (text, QUERY)
        },
    )
    memory = TypedStandingMemory(
        client,
        "fixture-chat",
        client,
        "fixture-embed",
        FixedUse(Rung.DESCRIPTION),
        mode="withhold",
        endorsement="sentence",
        evidence_slots=4,
        external_evidence=True,
        detect_conflicts=False,
    )
    written = memory.write(session_id=SESSION, user_query="", context=text)
    graph = memory._graph(SESSION)
    assert len(written.written) == len(memory._chunks[SESSION]) == 1
    sources = tuple(
        SourceBinding(
            SESSION,
            s.source_id,
            "external" if s.role == "external_body" else "principal",
            digest(s.text),
            str(s.role),
            s.principal_id,
        )
        for s in graph._sources.values()
    )
    native = (
        (
            written.written[0].entry_id,
            "claim",
            (graph.claim(written.written[0].entry_id).source_id,),
        ),
        (
            memory._chunks[SESSION][0].chunk_id,
            "evidence_chunk",
            memory._chunks[SESSION][0].source_ids,
        ),
    )
    stored = tuple(
        StoredRecord(f"stable-{kind}", digest(text), kind, "external") for _, kind, _ in native
    )
    records = tuple(
        RecordBinding(
            SESSION, key, record.record_id, digest(text), kind, parents, ("external",), "external"
        )
        for (key, kind, parents), record in zip(native, stored, strict=True)
    )
    book = EvidenceLedger.create(
        tmp_path / "book", episode_id=EPISODE, audit_limit=5, mode="artificial_fixture"
    )
    book.append(
        Register(
            "ingest",
            0,
            Provenance(
                "single-known-fixture-source", "email", "b1", "u1", "authenticated_external"
            ),
            stored,
        )
    )
    catalog = BindingCatalog(EPISODE, sources, records)
    access = AccessSnapshot(
        "v1",
        (
            ArtifactGrant("external", ("user",), ("read",)),
            ArtifactGrant("principal", ("user",), ("read",)),
        ),
    )
    context = RetrievalContext(book.snapshot(), access, USE, "user")
    expected = memory.retrieve(session_id=SESSION, query=QUERY)
    actual = GovernedRetrieval(memory, catalog, Policy("S")).retrieve(
        session_id=SESSION, query=QUERY, context=context
    )
    assert actual == expected and len(actual.entries) == 2
    assert actual.entries[1].metadata["evidence"] is True
    assert (
        len([r for r in client.requests if type(r) is ChatRequest]) == 1
    )  # replayed extraction only


def test_operations_and_all_denied_pools_are_not_safe_evidence(tmp_path):
    f = build_fixture(tmp_path / "book", external_evidence=True)
    context = replace(f.context(), operation="ungranted-operation")
    out = read(f, context=context)
    assert not out.retrieval.entries and out.retrieval.eligible_empty
    assert not any(t.in_candidate_pool for t in out.trace.candidates)
    assert f.ledger.snapshot().usage.tickets == 0 and f.ledger.snapshot().observations() == ()


def test_empty_store_returns_original_empty_result_without_models(tmp_path):
    f = build_fixture(tmp_path / "book")
    f.memory.reset(SESSION)
    f.bindings = BindingCatalog(EPISODE, (), ())
    outcome = read(f)
    assert outcome.retrieval == f.memory.retrieve(session_id=SESSION, query=QUERY)
    assert outcome.trace.candidates == outcome.trace.supplied_context == ()
    assert f.memory.client.requests == []


@pytest.mark.parametrize("arm", list("RCMS"))
def test_acl_version_change_does_not_silently_restore_known_unsafe_use(tmp_path, arm):
    f = build_fixture(tmp_path / "book", external_evidence=True)
    f.ledger.append(f.audit("root-0"))
    new_context = f.context(access=replace(f.access, version="v2"))
    changed = read(f, arm, context=new_context)
    assert {"c0", "e0"}.isdisjoint(changed.trace.selected_ids)
    held = [t for t in changed.trace.candidates if t.native_id == "c0"][0]
    assert held.decision.reason == "policy_changed_recheck_required"
    assert held.decision.local_status == "unreviewed"  # not a fabricated v2 unsafe label
    # A directly reviewed safe use under the NEW policy may restore this exact use.
    f.ledger.append(
        replace(
            f.audit("root-0", "safe_for_use", event="new-policy-review", at=2), policy_version="v2"
        )
    )
    restored = read(f, arm, context=f.context(access=new_context.access))
    assert {"c0", "e0"} <= set(restored.trace.selected_ids)
    assert f.ledger.snapshot().group("source", "u1").unsafe == 1
    assert f.ledger.snapshot().usage.tickets == 2


def test_artificial_example_cli_is_repeatable_and_never_overwrites(tmp_path):
    import subprocess
    import sys
    from pathlib import Path

    script = Path(__file__).resolve().parents[1] / "scripts/check_dynamic_retrieval.py"
    destinations = [tmp_path / "first", tmp_path / "second"]
    for out in destinations:
        proc = subprocess.run(
            [sys.executable, str(script), "--out", str(out)],
            capture_output=True,
            text=True,
            check=True,
        )
        summary = json.loads(proc.stdout)
        assert summary["initial_original_parity"]
        assert summary["retrieval_checks"] == 20
        assert set(summary["audit_tickets_per_arm"].values()) == {3}
        assert summary["paid_cost_usd"] == summary["model_api_requests"] == 0
    for path in destinations[0].rglob("*"):
        if path.is_file():
            assert (
                path.read_bytes()
                == (destinations[1] / path.relative_to(destinations[0])).read_bytes()
            )
    proc = subprocess.run(
        [sys.executable, str(script), "--out", str(destinations[0])], capture_output=True, text=True
    )
    assert proc.returncode == 2 and "overwrite" in proc.stdout
