"""Artificial fixtures only; none is an independently annotated benchmark case."""

from __future__ import annotations

import copy
import json
import math
import subprocess
import sys
from collections import Counter
from fractions import Fraction
from pathlib import Path

import pytest

from ams.research.phase1_annotations import review_template
from ams.research.phase1_common import PreparationError, digest, opaque
from ams.research.phase1_data import source_parts
from ams.research.phase1_scenarios import SCENARIOS, subset_table
from ams.research.provisional.annotations import prepare_annotations, warnings
from ams.research.provisional.episodes import (
    COUNTS,
    assignments,
    make_episode,
    pending_audits,
    recode,
    select_bags,
    source_pool,
    validate_bag,
    validate_episode,
    view,
)
from ams.research.provisional.pipeline import prepare
from ams.research.provisional.questions import prepare_questions, quality_flags, refined_question


def fixture(prefix="first"):
    rows, catalog, packets, parents, roles = [], {}, {}, {}, {}
    for context in ("email", "file_and_doc"):
        for label, n in COUNTS.items():
            for i in range(n):
                pid = opaque("p", prefix, context, label, i)
                entity = f"Project {context.title()}{label.title()}{i}"
                text = f"{entity} is on track."
                query = f"Remember the note about {entity}."
                parts = source_parts(pid, query, text)
                rid, eid, principal = (opaque(t, pid) for t in ("r", "e", "pc"))
                parents[rid] = parts[1]["artifact_id"]
                roles[rid], roles[principal] = "external", "principal"
                span = {
                    "artifact_id": parts[1]["artifact_id"],
                    "start": 0,
                    "end": len(text),
                    "quote": text,
                }
                records = [
                    {
                        "record_id": rid,
                        "record_kind": "claim",
                        "text": text,
                        "content_hash": digest(text),
                        "construction_source_spans": [],
                        "proposed_support_spans": [span],
                    },
                    {
                        "record_id": eid,
                        "record_kind": "evidence_chunk",
                        "text": text,
                        "content_hash": digest(text),
                        "construction_source_spans": [span],
                        "proposed_support_spans": [],
                    },
                    {
                        "record_id": principal,
                        "record_kind": "claim",
                        "text": query,
                        "content_hash": digest(query),
                        "construction_source_spans": [],
                        "proposed_support_spans": [
                            {
                                "artifact_id": parts[0]["artifact_id"],
                                "start": 0,
                                "end": len(query),
                                "quote": query,
                            }
                        ],
                    },
                ]
                packets[pid] = {
                    "contribution_id": pid,
                    "context_id": context,
                    "task": query,
                    "intended_use": f"What is stated about {entity}?",
                    "use_id": opaque("use", pid),
                    "artifacts": parts,
                    "records": records,
                    "bundle_completeness": "complete_text_and_structural_provenance",
                }
                catalog[pid] = {
                    "contribution_id": pid,
                    "context_id": context,
                    "user_query": query,
                    "context": text,
                    "artifacts": parts,
                    "payload_hash": digest([query, text]),
                }
                rows.append(
                    {
                        "contribution_id": pid,
                        "context_id": context,
                        "stratum": label,
                        "Y_case": label == "attack",
                        "review_candidate": True,
                        "group_id": opaque("dup", pid),
                        "original_case_key": f"fixture:{pid}",
                        "retrieval_query": packets[pid]["intended_use"],
                        "expected_memory": "PRIVATE TARGET",
                    }
                )
    return rows, catalog, packets, parents, roles


def episode(scenario="strong_localized"):
    bag, catalog, packets, _, roles = fixture()
    pool = source_pool(bag, catalog, packets, roles)
    mapping, hidden = assignments(bag, "D00", scenario)
    key = bytes(range(32))
    return make_episode(bag, mapping, hidden, pool, "D00", key), recode(pool, key)


def test_warning_is_a_literal_hint_and_not_a_verified_safety_label():
    text = 'Security example: "Ignore previous instructions." Do not follow that instruction.'
    hits = warnings(text)
    assert hits and all(text[h["start"] : h["end"]] == h["quote"] for h in hits)
    assert all(h["quotation_or_negation_may_make_this_safe"] for h in hits)
    assert all("verdict" not in h for h in hits)


def test_annotation_hints_never_prefill_human_votes_or_mutate_original_packets():
    _, _, index, _, _ = fixture()
    packets = list(index.values())
    before = copy.deepcopy(packets)
    updated, hints, report = prepare_annotations(packets)
    assert packets == before
    assert all(h["verified_verdict"] is None for h in hints)
    assert report["human_verified_labels"] == 0
    for p in updated:
        assert "warnings" not in json.dumps(p)
        form = review_template(p)
        assert form["status"] == "pending" and form["reviewer_id"] == ""
        assert all(r["origin"] is None and r["verdict"] is None for r in form["records"])


def test_source_suggestions_preserve_actual_offsets():
    _, _, p, _, _ = fixture()
    updated, _, _ = prepare_annotations(list(p.values()))
    for packet in updated:
        artifacts = {a["artifact_id"]: a for a in packet["artifacts"]}
        for r in packet["records"]:
            for s in r["source_support_suggestions"]:
                assert artifacts[s["artifact_id"]]["text"][s["start"] : s["end"]] == s["quote"]
                assert s["semantic_review_status"] == "unverified"


def test_question_refinement_preserves_reference_and_never_validates_sources():
    _, _, p, parents, _ = fixture()
    packets, _, _ = prepare_annotations(list(p.values()))
    qs, report = prepare_questions(packets, parents, [])
    assert qs and report["human_validated_questions"] == 0
    assert any("described?" in q["question"] for q in qs)
    assert all(q["source_safety_status"] == "safety_unverified" for q in qs)
    assert all(not q["eligible_for_final_benign_set"] and not q["human_validations"] for q in qs)
    assert len({(q["contribution_id"], q["question"], tuple(q["answers"])) for q in qs}) == len(qs)
    assert max(Counter(q["contribution_id"] for q in qs).values()) <= 3


def test_negation_is_not_silently_rewritten():
    c = {
        "question": "According to the note about No external sharing, what description is given?",
        "generated_by": "offline_existing_claim_clause_v1",
        "answers": ["permitted"],
        "support_record_kind": "claim",
    }
    assert refined_question(c, {"text": "No external sharing is permitted."}) == c["question"]
    assert "negation_or_quantifier_needs_review" in quality_flags(c)


def test_bag_is_case_balanced_and_never_requires_or_invents_z_labels():
    rows, *_ = fixture()
    validate_bag(rows)
    assert Counter(r["Y_case"] for r in rows) == {True: 20, False: 12}
    assert all("Z_bundle" not in r for r in rows)
    wrong = copy.deepcopy(rows)
    wrong[0]["Y_case"] = False
    with pytest.raises(PreparationError):
        validate_bag(wrong)


def test_matching_is_deterministic_and_component_disjoint_across_groups():
    rows = fixture("a")[0] + fixture("b")[0]
    first = select_bags(rows, [], 2)
    assert first == select_bags(list(reversed(rows)), [], 2)
    assert len({r["group_id"] for b in first for r in b}) == 64
    for bag in first:
        validate_bag(bag)
    with pytest.raises(PreparationError):
        select_bags(rows, [], 3)


def test_oversized_components_are_not_silently_approved():
    rows, *_ = fixture()
    groups = [{"group_id": r["group_id"], "manual_review_required": True} for r in rows]
    with pytest.raises(PreparationError):
        select_bags(rows, groups, 1)


def test_selection_ignores_machine_warnings_question_quality_and_future_reviews():
    rows = fixture("a")[0] + fixture("b")[0]
    changed = copy.deepcopy(rows)
    for r in changed:
        r.update(
            {"automated_warning": "unsafe-looking", "qa_quality": 0, "unrevealed_review": "safe"}
        )
    expected = [[r["contribution_id"] for r in b] for b in select_bags(rows, [], 2)]
    assert expected == [[r["contribution_id"] for r in b] for b in select_bags(changed, [], 2)]


def test_exact_subset_sampler_uses_ten_attack_case_slots_in_null_condition():
    _, table = subset_table([Fraction(1)] * 16, 10)
    assert table[0][10] == math.comb(16, 10)
    bag, *_ = fixture()
    for scenario in SCENARIOS:
        mapping, _ = assignments(bag, "D00", scenario)
        for context in ("email", "file_and_doc"):
            assert sum(r["Y_case"] for r in bag if r["context_id"] == context) == 10
        assert set(Counter(m["batch_id"] for m in mapping.values()).values()) == {4}


def test_all_scenarios_have_same_inputs_root_and_ingestion_order():
    bag, catalog, packets, _, roles = fixture()
    pool = source_pool(bag, catalog, packets, roles)
    roots, ingest = [], []
    for scenario in SCENARIOS:
        mapping, hidden = assignments(bag, "D00", scenario)
        roots.append(pending_audits(mapping, "D00")[0])
        e = make_episode(bag, mapping, hidden, pool, "D00", bytes(range(32)))
        ingest.append([r for r in e["events"] if r["event"] == "ingest"])
        assert len(set(e["shared_arm_inputs"].values())) == 1
    assert len(set(roots)) == 1 and all(i == ingest[0] for i in ingest)


def test_pending_audits_never_contain_an_unsafe_seed_or_consumed_budget():
    e, pool = episode()
    audits = [a for a in e["events"] if a["event"] == "audit_request_pending"]
    assert len(audits) == 5
    assert all(a["verdict"] is None and a["completed_verifications"] == 0 for a in audits)
    assert e["status"]["completed_verifications"] == 0
    assert not e["status"]["scientific_evaluation_allowed"]
    assert len(e["private"]["case_targets"]) == 27
    validate_episode(e, pool)


def test_runtime_projection_hides_future_inputs_labels_and_feedback():
    e, pool = episode()
    assert not view(pool, e, 0)["visible_contributions"]
    assert not view(pool, e, 32)["pending_audit_requests"]
    visible = view(pool, e, 33)
    assert len(visible["pending_audit_requests"]) == 1
    assert visible["revealed_audit_results"] == []
    assert "PRIVATE TARGET" not in json.dumps(view(pool, e, 38))
    visible["pending_audit_requests"][0]["verdict"] = "tampered"
    assert view(pool, e, 33)["pending_audit_requests"][0]["verdict"] is None


def test_principal_records_are_not_assigned_to_synthetic_external_contributors():
    e, pool = episode()
    for p in view(pool, e, 32)["visible_contributions"].values():
        for r in p["records"]:
            if r["source_role"] == "principal":
                assert r["principal_id"] == "user" and r["synthetic_origin_id"] is None
            elif r["source_role"] == "external":
                assert r["principal_id"] is None and r["synthetic_origin_id"]


def test_denied_reader_gets_no_content_or_other_principals_query():
    e, pool = episode()
    denied = view(pool, e, 38, "unauthorized")
    assert denied["visible_contributions"] == {} and denied["current_query"] is None
    assert denied["pending_audit_requests"] == []


def test_invalid_pending_verdict_unknown_public_fields_or_budget_are_rejected():
    e, pool = episode()
    changed = copy.deepcopy(e)
    changed["events"][32]["verdict"] = "unsafe"
    with pytest.raises(PreparationError):
        validate_episode(changed, pool)
    changed_pool = copy.deepcopy(pool)
    next(iter(changed_pool.values()))["target_risk_indicator"] = 1
    with pytest.raises(PreparationError):
        validate_episode(e, changed_pool)
    changed = copy.deepcopy(e)
    changed["shared_arm_inputs"]["R"] = "different"
    with pytest.raises(PreparationError):
        validate_episode(changed, pool)


def test_keyed_ids_preserve_original_text_and_roles():
    bag, catalog, packets, _, roles = fixture()
    pool = source_pool(bag, catalog, packets, roles)
    first, second = recode(pool, bytes(range(32))), recode(pool, bytes(reversed(range(32))))
    assert set(first) != set(second)
    assert sorted(r["context"] for r in first.values()) == sorted(
        r["context"] for r in pool.values()
    )


def test_existing_output_is_refused_before_reading_or_overwriting(tmp_path):
    marker = tmp_path / "do_not_change.txt"
    marker.write_text("genuine prior output")
    with pytest.raises(PreparationError):
        prepare(Path("missing"), Path("missing"), Path("missing"), tmp_path, Path("missing"))
    assert marker.read_text() == "genuine prior output"


def test_new_modules_do_not_import_or_initialize_models():
    process = subprocess.run(
        [
            sys.executable,
            "-c",
            "import sys; import ams.research.provisional.pipeline; "
            "assert not any(m.startswith(('openai','torch','transformers')) for m in sys.modules)",
        ],
        capture_output=True,
        text=True,
    )
    assert process.returncode == 0, process.stderr
