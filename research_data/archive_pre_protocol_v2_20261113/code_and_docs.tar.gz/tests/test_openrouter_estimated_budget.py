"""Offline coverage for optional estimated billing with conservative retained holds."""

from __future__ import annotations

import json
import sqlite3
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
from pathlib import Path
from unittest.mock import patch

import httpx
from openai import OpenAI

from ams.llm.base import ProviderError
from ams.llm.budget import BudgetAccountingError, BudgetExhausted, BudgetGuard
from ams.llm.cache import ResponseCache
from ams.llm.pool import ManagedClient, RetryPolicy
from ams.llm.providers.openai_client import OpenAIClient
from ams.llm.types import ChatRequest, Message

MODEL = "openai/gpt-4o-mini"
HOLD = 19_740_000


def completion():
    return {
        "id": "gen-offline-estimated-test",
        "object": "chat.completion",
        "created": 1,
        "model": MODEL,
        "choices": [
            {
                "index": 0,
                "finish_reason": "stop",
                "message": {"role": "assistant", "content": "Unmodified original answer."},
            }
        ],
        "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
    }


class OpenRouterEstimatedBudgetTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)
        self.path = self.directory / "budget.sqlite"
        self.guard = BudgetGuard(self.path, 27)
        self.requests = []
        for context in (
            patch("socket.socket.connect", side_effect=AssertionError("Network forbidden")),
            patch.dict("os.environ", {"AMS_BUDGET_ALLOW_ESTIMATED_USAGE": "0"}),
        ):
            context.start()
            self.addCleanup(context.stop)

    @staticmethod
    def request(**overrides):
        values = {
            "messages": (
                Message("system", "Original SAFE-Mem instructions."),
                Message("user", "Original memory and evaluation question."),
            ),
            "model": MODEL,
            "temperature": 0.0,
            "max_tokens": 900,
            "stop": ("END",),
        }
        values.update(overrides)
        return ChatRequest(**values)

    def adapter(self, handler, *, allow_estimated=True, guard=None):
        def capture(request):
            self.requests.append(json.loads(request.content))
            return handler(request)

        sdk = OpenAI(
            api_key="offline-test-key",
            base_url="https://openrouter.ai/api/v1",
            max_retries=5,
            http_client=httpx.Client(transport=httpx.MockTransport(capture)),
        )
        self.addCleanup(sdk.close)
        result = OpenAIClient(
            provider="openrouter",
            sdk_client=sdk,
            budget_guard=guard or self.guard,
            allow_estimated_billing=allow_estimated,
        )
        self.addCleanup(result._client.close)
        return result

    @staticmethod
    def managed(adapter):
        return ManagedClient(adapter, retry=RetryPolicy(max_attempts=3), sleep=lambda _: None)

    def reservation(self, path=None):
        with sqlite3.connect(path or self.path) as conn:
            conn.row_factory = sqlite3.Row
            row = dict(conn.execute("SELECT * FROM reservations ORDER BY created_utc").fetchone())
        row["metadata"] = json.loads(row["metadata"])
        return row

    def test_missing_cost_preserves_text_native_counts_prompt_and_full_hold(self):
        request = self.request()
        response = self.adapter(lambda _: httpx.Response(200, json=completion())).complete(request)
        self.assertEqual(response.text, "Unmodified original answer.")
        self.assertEqual(response.usage.input_tokens, 10)
        self.assertEqual(response.usage.output_tokens, 5)
        self.assertAlmostEqual(response.usage.cost_usd, 0.0000045)
        self.assertEqual(len(self.requests), 1)
        payload = self.requests[0]
        self.assertEqual(payload["model"], request.model)
        self.assertEqual(payload["max_tokens"], request.max_tokens)
        self.assertEqual(payload["temperature"], request.temperature)
        self.assertEqual(payload["stop"], list(request.stop))
        self.assertEqual(
            payload["messages"],
            [{"role": message.role, "content": message.content} for message in request.messages],
        )
        snapshot = self.guard.snapshot()
        self.assertFalse(snapshot["blocked"])
        self.assertEqual(snapshot["held_nanodollars"], HOLD)
        self.assertEqual(snapshot["used_nanodollars"], 0)
        self.assertEqual(snapshot["counts"]["unknown"], 1)
        receipt = self.reservation()
        self.assertEqual(receipt["state"], "unknown")
        self.assertEqual(receipt["error_type"], "MissingBillingCost")
        self.assertEqual(receipt["metadata"]["request_id"], request.cache_key("openrouter"))
        self.assertEqual(receipt["metadata"]["generation_id"], completion()["id"])
        self.assertEqual(receipt["metadata"]["model"], MODEL)
        self.assertEqual(receipt["metadata"]["input_tokens"], 10)
        self.assertEqual(receipt["metadata"]["output_tokens"], 5)
        self.assertFalse(receipt["metadata"]["billing_verified"])
        self.assertTrue(receipt["metadata"]["cost_missing"])
        self.assertAlmostEqual(receipt["metadata"]["estimated_cost_usd"], 0.0000045)

    def test_absent_native_usage_does_not_invent_tokens_and_reports_full_cost_bound(self):
        payload = completion()
        del payload["usage"]
        response = self.adapter(lambda _: httpx.Response(200, json=payload)).complete(
            self.request()
        )
        self.assertEqual(response.usage.input_tokens, 0)
        self.assertEqual(response.usage.output_tokens, 0)
        self.assertAlmostEqual(response.usage.cost_usd, HOLD / 1_000_000_000)
        metadata = self.reservation()["metadata"]
        self.assertNotIn("input_tokens", metadata)
        self.assertNotIn("output_tokens", metadata)
        self.assertFalse(metadata["usage_details"]["input_tokens_known"])
        self.assertFalse(metadata["usage_details"]["output_tokens_known"])
        self.assertEqual(self.guard.snapshot()["held_nanodollars"], HOLD)

    def test_partial_native_usage_is_a_token_lower_bound_with_full_cost_hold(self):
        payload = completion()
        del payload["usage"]["completion_tokens"]
        response = self.adapter(lambda _: httpx.Response(200, json=payload)).complete(
            self.request()
        )
        self.assertEqual(response.usage.input_tokens, 10)
        self.assertEqual(response.usage.output_tokens, 0)
        self.assertAlmostEqual(response.usage.cost_usd, HOLD / 1_000_000_000)
        metadata = self.reservation()["metadata"]
        self.assertTrue(metadata["usage_details"]["input_tokens_known"])
        self.assertFalse(metadata["usage_details"]["output_tokens_known"])
        self.assertEqual(metadata["input_tokens"], 10)
        self.assertNotIn("output_tokens", metadata)
        self.assertEqual(self.guard.snapshot()["held_nanodollars"], HOLD)

    def test_strict_default_still_persistently_halts_missing_billing(self):
        adapter = self.adapter(
            lambda _: httpx.Response(200, json=completion()), allow_estimated=False
        )
        with self.assertRaises(BudgetAccountingError):
            self.managed(adapter).complete(self.request())
        self.assertEqual(len(self.requests), 1)
        self.assertEqual(self.guard.snapshot()["blocked_reason"], "unverified_billing")
        self.assertEqual(self.guard.snapshot()["held_nanodollars"], HOLD)
        reopened = BudgetGuard(self.path, 27)
        with self.assertRaises(BudgetAccountingError):
            reopened.reserve(MODEL, 900)

    def test_environment_flag_is_explicit_opt_in(self):
        with patch.dict("os.environ", {"AMS_BUDGET_ALLOW_ESTIMATED_USAGE": "1"}):
            adapter = self.adapter(
                lambda _: httpx.Response(200, json=completion()), allow_estimated=False
            )
        response = adapter.complete(self.request())
        self.assertEqual(response.text, "Unmodified original answer.")
        self.assertFalse(self.guard.snapshot()["blocked"])

    def test_known_charge_remains_authoritative_even_when_estimates_allowed(self):
        payload = completion()
        payload["usage"]["cost"] = "0.000123"
        response = self.adapter(lambda _: httpx.Response(200, json=payload)).complete(
            self.request()
        )
        self.assertAlmostEqual(response.usage.cost_usd, 0.000123)
        self.assertEqual(self.guard.snapshot()["used_nanodollars"], 123_000)
        self.assertEqual(self.guard.snapshot()["held_nanodollars"], 0)
        self.assertEqual(self.reservation()["state"], "settled")

    def test_malformed_cost_byok_wrong_model_and_price_breach_still_halt(self):
        variants = []
        for cost in ("NaN", "Infinity", "-0.01"):
            payload = completion()
            payload["usage"]["cost"] = cost
            variants.append((payload, "invalid_billing"))
        payload = completion()
        payload["usage"]["is_byok"] = True
        variants.append((payload, "byok_billing"))
        payload = completion()
        payload["model"] = "openai/gpt-4o-mini-search-preview"
        variants.append((payload, "unexpected_response_model"))
        payload = completion()
        payload["usage"]["cost"] = "0.03"
        variants.append((payload, "actual_cost_exceeded_reservation"))
        for index, (body, reason) in enumerate(variants):
            with self.subTest(reason=reason, index=index):
                path = self.directory / f"protected-{index}.sqlite"
                guard = BudgetGuard(path, 27)
                before = len(self.requests)
                adapter = self.adapter(lambda _, b=body: httpx.Response(200, json=b), guard=guard)
                with self.assertRaises(BudgetAccountingError):
                    self.managed(adapter).complete(self.request())
                self.assertEqual(len(self.requests) - before, 1)
                self.assertEqual(guard.snapshot()["blocked_reason"], reason)
                with self.assertRaises(BudgetAccountingError):
                    adapter.complete(self.request())
                self.assertEqual(len(self.requests) - before, 1)

    def test_missing_cost_cannot_bypass_native_usage_price_breach(self):
        payload = completion()
        payload["usage"]["prompt_tokens"] = 1_000_000
        adapter = self.adapter(lambda _: httpx.Response(200, json=payload))
        with self.assertRaises(BudgetAccountingError):
            self.managed(adapter).complete(self.request())
        self.assertEqual(self.guard.snapshot()["blocked_reason"], "usage_price_breach")
        self.assertEqual(self.guard.snapshot()["held_nanodollars"], HOLD)
        self.assertEqual(len(self.requests), 1)

    def test_partial_native_usage_cannot_bypass_model_input_bound(self):
        payload = completion()
        payload["usage"]["prompt_tokens"] = 128_001
        del payload["usage"]["completion_tokens"]
        adapter = self.adapter(lambda _: httpx.Response(200, json=payload))
        with self.assertRaises(BudgetAccountingError):
            self.managed(adapter).complete(self.request())
        self.assertEqual(self.guard.snapshot()["blocked_reason"], "usage_price_breach")
        self.assertEqual(self.guard.snapshot()["held_nanodollars"], HOLD)
        self.assertEqual(len(self.requests), 1)

    def test_empty_choices_and_http_200_error_retry_same_prompt_with_new_hold(self):
        for index, first in enumerate(
            (
                {**completion(), "choices": []},
                {"error": {"message": "private-error-body", "code": 503}},
            )
        ):
            with self.subTest(index=index):
                path = self.directory / f"retry-{index}.sqlite"
                guard = BudgetGuard(path, 27)
                start = len(self.requests)

                def handle(_, start=start, first=first):
                    if len(self.requests) == start + 1:
                        return httpx.Response(200, json=first)
                    body = completion()
                    body["usage"]["cost"] = "0.000123"
                    return httpx.Response(200, json=body)

                adapter = self.adapter(handle, guard=guard)
                response = self.managed(adapter).complete(self.request())
                self.assertEqual(response.text, "Unmodified original answer.")
                self.assertEqual(len(self.requests) - start, 2)
                self.assertEqual(self.requests[start], self.requests[start + 1])
                self.assertEqual(adapter._client.max_retries, 0)
                snapshot = guard.snapshot()
                self.assertFalse(snapshot["blocked"])
                self.assertEqual(snapshot["counts"]["unknown"], 1)
                self.assertEqual(snapshot["counts"]["settled"], 1)
                self.assertEqual(snapshot["held_nanodollars"], HOLD)
                receipt = self.reservation(path)
                self.assertEqual(receipt["error_type"], "IncompleteResponse")
                self.assertEqual(
                    receipt["metadata"]["request_id"], self.request().cache_key("openrouter")
                )
                self.assertNotIn("private-error-body", json.dumps(receipt["metadata"]))

    def test_valid_refusal_or_empty_content_is_preserved_without_retry(self):
        for index, content in enumerate((None, "")):
            with self.subTest(content=content):
                guard = BudgetGuard(self.directory / f"refusal-{index}.sqlite", 27)
                payload = completion()
                payload["choices"][0]["message"].update(content=content, refusal="Model refusal.")
                start = len(self.requests)
                response = self.managed(
                    self.adapter(
                        lambda _, body=payload: httpx.Response(200, json=body), guard=guard
                    )
                ).complete(self.request())
                self.assertEqual(response.text, "")
                self.assertEqual(len(self.requests) - start, 1)
                self.assertFalse(guard.snapshot()["blocked"])
                self.assertEqual(guard.snapshot()["counts"]["unknown"], 1)

    def test_estimated_completion_cache_replay_retains_one_hold_and_no_new_http(self):
        cache = ResponseCache(self.directory / "responses.sqlite")
        self.addCleanup(cache.close)
        managed = ManagedClient(
            self.adapter(lambda _: httpx.Response(200, json=completion())), cache=cache
        )
        first = managed.complete(self.request())
        second = managed.complete(self.request())
        self.assertEqual(first.text, second.text)
        self.assertFalse(first.cached)
        self.assertTrue(second.cached)
        self.assertEqual(len(self.requests), 1)
        self.assertEqual(self.guard.snapshot()["held_nanodollars"], HOLD)
        self.assertEqual(self.guard.snapshot()["counts"]["total"], 1)

    def test_exhausted_allowance_stops_incomplete_response_retry_before_next_http(self):
        guard = BudgetGuard(self.directory / "one-retry.sqlite", "0.02")
        adapter = self.adapter(
            lambda _: httpx.Response(200, json={"error": {"code": 503}}), guard=guard
        )
        with self.assertRaises(BudgetExhausted):
            self.managed(adapter).complete(self.request())
        self.assertEqual(len(self.requests), 1)
        self.assertEqual(guard.snapshot()["held_nanodollars"], HOLD)
        self.assertFalse(guard.snapshot()["blocked"])

    def test_incomplete_response_is_retryable_and_metadata_does_not_log_response_body(self):
        adapter = self.adapter(
            lambda _: httpx.Response(200, json={"error": {"message": "private-error-body"}})
        )
        with self.assertRaises(ProviderError) as raised:
            adapter.complete(self.request())
        self.assertTrue(raised.exception.retryable)
        self.assertNotIn("private-error-body", str(raised.exception))
        self.assertNotIn("private-error-body", json.dumps(self.reservation()["metadata"]))

    def test_concurrent_missing_costs_cannot_commit_more_than_27_dollars(self):
        # Production 128k input bound and maximum 16,384 output ceiling, real SDK/mock HTTP.
        reservation = Decimal("0.0290304")
        allowed = int(Decimal(27) / reservation)
        adapter = self.adapter(lambda _: httpx.Response(200, json=completion()))

        def attempt(index):
            try:
                adapter.complete(self.request(max_tokens=16_384, sample_index=index))
                return True
            except BudgetExhausted:
                return False

        with ThreadPoolExecutor(max_workers=16) as executor:
            results = list(executor.map(attempt, range(allowed + 32)))
        self.assertEqual(sum(results), allowed)
        self.assertEqual(len(self.requests), allowed)
        snapshot = self.guard.snapshot()
        self.assertEqual(snapshot["counts"]["unknown"], allowed)
        self.assertEqual(snapshot["counts"]["settled"], 0)
        self.assertEqual(snapshot["used_nanodollars"], 0)
        self.assertEqual(snapshot["held_nanodollars"], int(reservation * allowed * 1_000_000_000))
        self.assertLessEqual(snapshot["committed_nanodollars"], 27_000_000_000)
        self.assertFalse(snapshot["blocked"])
        reopened = BudgetGuard(self.path, 27)
        with self.assertRaises(BudgetExhausted):
            reopened.reserve(MODEL, 16_384)
        self.assertEqual(len(self.requests), allowed)


if __name__ == "__main__":
    unittest.main()
