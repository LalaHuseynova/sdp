"""Offline SDK/HTTP integration, shared limits and crash checks on invented records."""

from __future__ import annotations

import json
import socket
import sqlite3
from dataclasses import replace

import httpx
import pytest

from ams.llm.types import ChatRequest, Message
from ams.research.dynamic.models import LedgerError, digest
from ams.research.execution import ExecutionSession, GuardedSequentialRun
from ams.research.execution.assets import text_hash, validate_runtime_assets
from ams.research.execution.preflight import check_config
from ams.research.execution.session import MODEL, prompt_measurement
from ams.research.sequential import SequentialRun
from ams.research.sequential.fixture import build_state, query


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def deny(*args, **kwargs):
        raise AssertionError("Execution integration tests forbid real networking")

    for key in ("connect", "connect_ex"):
        monkeypatch.setattr(socket.socket, key, deny)
    monkeypatch.setattr(socket, "create_connection", deny)
    monkeypatch.setattr(socket, "getaddrinfo", deny)


class Crash(BaseException):
    pass


def fail_at(target):
    def fault(stage):
        if stage == target:
            raise Crash(stage)

    return fault


def req(**kwargs):
    values = dict(
        messages=(Message("user", "Invented integration question"),),
        model=MODEL,
        temperature=0,
        max_tokens=200,
    )
    return ChatRequest(**{**values, **kwargs})


def reply(*, cost="0.000123", finish="stop", text="Invented integration answer", model=MODEL):
    usage = {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}
    if cost is not None:
        usage["cost"] = cost
    return httpx.Response(
        200,
        json={
            "id": "gen-offline-execution-fixture",
            "object": "chat.completion",
            "created": 1,
            "model": model,
            "choices": [
                {
                    "index": 0,
                    "finish_reason": finish,
                    "message": {"role": "assistant", "content": text},
                }
            ],
            "usage": usage,
        },
    )


def mock_session(path, handler=None):
    session = ExecutionSession.create(path, plan_hash="invented-plan")
    seen = []

    def handle(request):
        assert session.guard.snapshot()["counts"]["pending"] == 1
        seen.append(json.loads(request.content))
        return handler(request) if handler else reply()

    session.arm_mock(httpx.MockTransport(handle))
    return session, seen


def runtime(path, *, classifier=False):
    state, _ = build_state(path, classifier=classifier)
    state.memory.model = state.answer_model = MODEL
    state.memory.client.key_provider = "openrouter"
    state.memory.client.chats.clear()
    if classifier:
        state.memory.use_type.model = MODEL
    state.validate()
    return state


def test_shared_30_dollar_allowance_and_enforced_wire_options(tmp_path):
    session, seen = mock_session(tmp_path / "s")
    with session:
        r = session.complete("first", "answer", req())
        assert r["actual_paid_usd"] == "0"  # Simulated billing is never actual spending.
        assert r["dispatch"]["receipt"]["actual_nanodollars"] == 123000
        budget = session.guard.snapshot()
        assert budget["limit_usd"] == 30
        assert budget["used_nanodollars"] == 123000
        assert budget["held_nanodollars"] == 0
        assert len(seen) == 1
        assert seen[0]["provider"] == {
            "max_price": {"prompt": 0.15, "completion": 0.60, "request": 0},
            "allow_fallbacks": False,
            "require_parameters": True,
        }
        assert all(p["enabled"] is False for p in seen[0]["plugins"])
        assert session._sdk.max_retries == 0
    with ExecutionSession(tmp_path / "s") as resumed:
        assert resumed.guard.snapshot()["used_nanodollars"] == 123000
        assert resumed.complete("first", "answer", req()) == r  # No armed transport needed.
        with pytest.raises(LedgerError, match="changed request"):
            resumed.complete("first", "answer", req(messages=(Message("user", "different"),)))
    assert len(seen) == 1


def test_limit_cannot_be_increased_or_reinitialized(tmp_path):
    path = tmp_path / "s"
    ExecutionSession.create(path, plan_hash="fixture").close()
    with pytest.raises(LedgerError, match="exists"):
        ExecutionSession.create(path, plan_hash="fixture")
    body = json.loads((path / "session.json").read_text())
    body["limit_usd"] = "125.00"
    (path / "session.json").write_text(json.dumps(body))
    with pytest.raises(LedgerError, match="increased"):
        ExecutionSession(path)


def test_same_session_has_single_writer(tmp_path):
    with ExecutionSession.create(tmp_path / "s", plan_hash="fixture"):
        with pytest.raises(LedgerError, match="Another dispatcher"):
            ExecutionSession(tmp_path / "s")


@pytest.mark.parametrize("kind", ["timeout", "http_503", "missing_billing", "wrong_model"])
def test_unknown_outcomes_halt_without_hidden_retry(tmp_path, kind, monkeypatch):
    monkeypatch.setenv("AMS_BUDGET_ALLOW_ESTIMATED_USAGE", "1")

    def handler(request):
        if kind == "timeout":
            raise httpx.ReadTimeout("Fixture timeout", request=request)
        if kind == "http_503":
            return httpx.Response(503, json={"error": {"message": "Fixture outage"}})
        if kind == "missing_billing":
            return reply(cost=None)
        return reply(model="unapproved/model")

    path = tmp_path / "s"
    session, seen = mock_session(path, handler)
    with session:
        result = session.complete("first", "answer", req())
        assert result["error"] is not None
        assert result["actual_paid_usd"] is None
        assert len(seen) == 1
        snap = session.guard.snapshot()
        assert snap["held_nanodollars"] == 19320000
        assert snap["blocked"]
        with pytest.raises(LedgerError, match="Unresolved"):
            session.complete("other", "answer", req())
    with ExecutionSession(path) as resumed:
        assert resumed.guard.snapshot()["held_nanodollars"] == 19320000
        assert resumed.complete("first", "answer", req()) == result
        with pytest.raises(LedgerError):
            resumed.complete("other", "answer", req())
    assert len(seen) == 1


@pytest.mark.parametrize("stage", ["after_dispatch_intent", "after_provider_before_response_save"])
def test_crash_window_is_never_automatically_redispatched(tmp_path, stage):
    path = tmp_path / "s"
    session, seen = mock_session(path)
    with session:
        with pytest.raises(Crash):
            session.complete("first", "answer", req(), fault=fail_at(stage))
    with ExecutionSession(path) as resumed:
        with pytest.raises(LedgerError, match="Unknown dispatch outcome"):
            resumed.complete("first", "answer", req())
        with pytest.raises(LedgerError, match="Unresolved dispatch"):
            resumed.complete("other", "answer", req())
    assert len(seen) == (0 if stage == "after_dispatch_intent" else 1)


def test_cap_exhaustion_blocks_before_mock_http(tmp_path):
    session, seen = mock_session(tmp_path / "s")
    with session:
        # A consistent artificial paid-attempt prefix near USD 30, not real usage.
        with sqlite3.connect(session.guard.path) as db:
            db.executemany(
                """INSERT INTO reservations VALUES (?,?,?, ?,?,?, 'settled','{}','',?,?)""",
                [
                    (
                        f"fixture-{i}",
                        MODEL,
                        200,
                        "fixture",
                        19320000,
                        19320000,
                        "fixture",
                        "fixture",
                    )
                    for i in range(1552)
                ],
            )
            db.execute(
                "UPDATE budget_config SET used_nanodollars=?,held_nanodollars='0'",
                (str(1552 * 19320000),),
            )
        result = session.complete("no-room", "answer", req())
        assert result["error"]["type"] == "BudgetExhausted"
        assert len(seen) == 0
        assert session.guard.snapshot()["committed_usd"] <= 30


@pytest.mark.parametrize(
    "override,stage",
    [
        ({"model": "other/model"}, "answer"),
        ({"max_tokens": 900}, "answer"),
        ({"max_tokens": 24}, "classifier"),
        ({"temperature": 1}, "answer"),
        ({"reasoning_effort": "high"}, "answer"),
    ],
)
def test_unplanned_calls_rejected_before_http(tmp_path, override, stage):
    session, seen = mock_session(tmp_path / "s")
    with session:
        with pytest.raises(LedgerError):
            session.complete("bad", stage, req(**override))
        assert not seen


def test_live_activation_refuses_before_sdk_or_credentials(tmp_path, monkeypatch):
    from ams.research.planning import pipeline

    def blocked(plan):
        raise LedgerError("Scientific freeze unavailable")

    monkeypatch.setattr(pipeline, "require_scientific_freeze", blocked)
    with ExecutionSession.create(tmp_path / "s", plan_hash="fixture") as session:
        with pytest.raises(LedgerError, match="Scientific"):
            session.arm_live(scientific_plan=tmp_path, api_key="not-a-real-credential")
        assert session._sdk is None


def test_api_answer_is_captured_and_restart_does_not_repeat_it(tmp_path):
    session, seen = mock_session(tmp_path / "s", lambda _: reply(finish="length"))
    with session:
        state = runtime(tmp_path / "fixture")
        assert validate_runtime_assets(state)["valid_at_current_event_cursor"]
        run = GuardedSequentialRun.create(tmp_path / "run", state).attach(session)
        run.fault = fail_at("before_commit")
        with pytest.raises(Crash):
            run.step(query("q", 0))
        assert len(seen) == 1
        run.close()
        with GuardedSequentialRun(tmp_path / "run") as resumed:
            resumed.attach(session)
            result = resumed.recover()
            assert result["status"] == "completed" and result["value"]["truncated"]
            assert result["resources"]["inference"]["mock_dispatch_calls"] == 1
            assert result["resources"]["inference"]["live_api_calls"] == 0
            assert result["resources"]["inference"]["actual_paid_usd"] == "0"
            assert resumed.step(query("q", 0)) == result
            resumed.checkpoint(tmp_path / "checkpoint")
        with GuardedSequentialRun.restore(
            tmp_path / "checkpoint", tmp_path / "restored"
        ) as restored:
            restored.attach(session)
            assert restored.step(query("q", 0)) == result
        # Original runner can replay captured state but never dispatch live calls itself.
        with SequentialRun(tmp_path / "run") as offline:
            assert offline.step(query("q", 0)) == result
        assert len(seen) == 1


def test_classifier_or_embedding_miss_never_uses_api(tmp_path):
    session, seen = mock_session(tmp_path / "s")
    with session:
        for classifier in (True, False):
            state = runtime(tmp_path / f"fixture-{classifier}", classifier=classifier)
            if not classifier:
                state.memory.embed_client.embeddings.clear()
            with GuardedSequentialRun.create(tmp_path / f"run-{classifier}", state) as run:
                run.attach(session)
                assert run.step(query("q", 0))["status"] == "failed"
        assert not seen


def test_two_arms_share_allowance_and_run_cannot_switch_session(tmp_path):
    session, seen = mock_session(tmp_path / "s")
    with session:
        for arm in ("R", "S"):
            state = runtime(tmp_path / f"fixture-{arm}")
            state.policy = (
                replace(state.policy, arm=arm) if hasattr(state.policy, "arm") else state.policy
            )
            with GuardedSequentialRun.create(tmp_path / f"run-{arm}", state) as run:
                run.attach(session)
                assert run.step(query("q", 0))["status"] == "completed"
        assert len(seen) == 2
        assert session.guard.snapshot()["used_nanodollars"] == 246000
    with ExecutionSession.create(tmp_path / "other", plan_hash="fixture") as other:
        with GuardedSequentialRun(tmp_path / "run-R") as run:
            with pytest.raises(LedgerError, match="switch"):
                run.attach(other)


def test_prompt_measurement_and_hash_do_not_claim_gpt_tokenization():
    measurement = prompt_measurement(req(messages=(Message("user", "é"),)))
    assert measurement["utf8_content_bytes"] == 2
    assert measurement["native_tokens_measured"] is False
    assert measurement["guaranteed_token_bound"] is False
    assert text_hash("claim") == digest("claim")


def test_config_rejects_limit_or_execution_promotion():
    from pathlib import Path

    cfg = json.loads(Path("configs/research/dynamic_execution_v1_20261031.json").read_text())
    check_config(cfg)
    for key, value in (("total_api_limit_usd", "31.00"), ("scientific_execution_enabled", True)):
        with pytest.raises(LedgerError):
            check_config({**cfg, key: value})


def test_controller_controls_and_judges_share_the_same_budget(tmp_path):
    session, seen = mock_session(tmp_path / "s")
    with session:
        for stage in ("judge_answer", "judge_entry", "no_memory_answer"):
            result = session.complete(
                stage, stage, req(max_tokens=200 if stage == "no_memory_answer" else 120)
            )
            assert result["error"] is None
        classifier = req(max_tokens=24)
        first = session.complete_shared_classifier(classifier)
        assert session.complete_shared_classifier(classifier) == first
        assert len(seen) == 4
        assert session.guard.snapshot()["used_nanodollars"] == 4 * 123000
        with pytest.raises(LedgerError, match="shared exact key"):
            session.complete("per-arm-classifier", "classifier_catalog", classifier)


def test_response_or_request_tampering_detected_on_reopen(tmp_path):
    path = tmp_path / "s"
    session, _ = mock_session(path)
    with session:
        session.complete("a", "answer", req())
    with sqlite3.connect(path / "dispatch.sqlite") as db:
        db.execute("UPDATE dispatches SET stage='conflict'")
    with pytest.raises(LedgerError, match="changed"):
        ExecutionSession(path)


def test_mock_session_cannot_be_promoted_to_live_accounting(tmp_path):
    session, _ = mock_session(tmp_path / "s")
    with session:
        with pytest.raises(LedgerError, match="Mock and live"):
            session._set_mode("live")


def test_oversized_prompt_stops_before_http(tmp_path):
    session, seen = mock_session(tmp_path / "s")
    with session:
        with pytest.raises(LedgerError, match="Oversized"):
            session.complete("large", "answer", req(messages=(Message("user", "x" * 128000),)))
        assert not seen


def test_run_binding_is_pinned_in_checkpoint_database(tmp_path):
    session, seen = mock_session(tmp_path / "s")
    with session:
        with GuardedSequentialRun.create(tmp_path / "run", runtime(tmp_path / "f")) as run:
            run.attach(session)
            run.step(query("q", 0))
        binding = tmp_path / "run/execution_binding.json"
        original = json.loads(binding.read_text())
        binding.unlink()
        with GuardedSequentialRun(tmp_path / "run") as run:
            run.attach(session)
            assert json.loads(binding.read_text()) == original
        binding.write_text(json.dumps({**original, "run_id": "wrong-run"}))
        with GuardedSequentialRun(tmp_path / "run") as run:
            with pytest.raises(LedgerError, match="binding changed"):
                run.attach(session)
        assert len(seen) == 1
