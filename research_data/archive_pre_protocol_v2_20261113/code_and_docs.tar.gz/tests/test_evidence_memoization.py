"""Memoization identity/correction and unchanged saved controller replay."""

import json

import httpx
import pytest

from ams.research.dynamic.ledger import EvidenceSnapshot, LedgerConfig
from ams.research.evidence_memoization import memoized_evidence_revisions
from ams.research.provisional_run.runner import run
from test_dynamic_execution import reply
from test_dynamic_native import example, offline  # noqa: F401
from test_provisional_run import fixture_plan


def test_revision_identity_new_snapshots_and_descriptor_restoration():
    original = EvidenceSnapshot.revision
    a = EvidenceSnapshot(LedgerConfig("fixture", "verified_audits", 5), (), 0)
    b = EvidenceSnapshot(LedgerConfig("other-fixture", "verified_audits", 5), (), 0)
    expected_a, expected_b = a.revision, b.revision
    assert expected_a != expected_b
    with memoized_evidence_revisions() as stats:
        for _ in range(10):
            assert a.revision == expected_a
        assert b.revision == expected_b
        assert stats == {"calculations": 2, "cache_hits": 9}
    assert EvidenceSnapshot.revision is original and a.revision == expected_a
    with pytest.raises(RuntimeError), memoized_evidence_revisions():
        raise RuntimeError("fixture crash")
    assert EvidenceSnapshot.revision is original


def test_existing_controller_outputs_replay_exactly_with_memoization(tmp_path, example):  # noqa: F811
    plan, _ = fixture_plan(tmp_path, example)
    seen = []

    def handler(request):
        body = json.loads(request.content)
        seen.append(body)
        return reply(
            text="NO\nInvented judgment" if body["max_tokens"] == 120 else "Invented answer"
        )

    out = tmp_path / "results"
    first = run(plan, out, mock=httpx.MockTransport(handler))
    count = len(seen)
    before = (out / "queries.sqlite").stat().st_size
    with memoized_evidence_revisions() as stats:
        second = run(plan, out, mock=httpx.MockTransport(handler))
    assert second["status"] == first["status"] and len(seen) == count
    assert second["costs"]["project_used_usd"] == first["costs"]["project_used_usd"]
    assert (out / "queries.sqlite").stat().st_size == before
    assert stats["cache_hits"] > 0
