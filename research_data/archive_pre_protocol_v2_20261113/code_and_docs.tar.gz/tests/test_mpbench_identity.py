"""Offline checks for the official full MPBench release and internal identities."""

from __future__ import annotations

import hashlib
import json
import unittest
from collections import Counter
from pathlib import Path

from ams.data.mpbench import load_mpbench

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "mpbench"
ADVERSARIAL_SHA256 = "f2d23a5a2d483889eb2fdd9a2a082f0759603bc0a17664814a7caafbd318f90d"
EXPECTED_SHA256 = {
    "adversarial_data.jsonl.jsonl": ADVERSARIAL_SHA256,
    "benign_data.jsonl.jsonl": "707ef7e311e147d9818a8a9e04293296fc6bf3390241e4cac23c8145765b62d5",
}


def strict_objects(path: Path) -> list[dict]:
    """Decode the complete stream, failing on any unconsumed invalid text."""
    text = path.read_text(encoding="utf-8")
    decoder = json.JSONDecoder()
    offset = 0
    rows = []
    while offset < len(text):
        if text[offset].isspace():
            offset += 1
            continue
        row, offset = decoder.raw_decode(text, offset)
        rows.append(row)
    return rows


class MPBenchIdentityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cases, _ = load_mpbench(DATA)
        cls.attack = [c for c in cls.cases if c.is_adversarial]
        cls.benign = [c for c in cls.cases if not c.is_adversarial]

    def test_full_pool_and_scoring_denominators(self):
        readable = [c for c in self.cases if c.retrieval_query.strip()]
        self.assertEqual(len(self.cases), 6240)
        self.assertEqual(len(self.attack), 3241)
        self.assertEqual(len(self.benign), 2999)
        self.assertEqual(len(readable), 5996)
        self.assertEqual(sum(c.is_adversarial for c in readable), 2999)
        self.assertEqual(sum(not c.is_adversarial for c in readable), 2997)
        scored_benign = [c for c in readable if not c.is_adversarial and c.expected_memory.strip()]
        self.assertEqual(len(scored_benign), 2856)
        self.assertEqual(sum(c.legitimate_memory_write is True for c in scored_benign), 249)
        self.assertEqual(sum(c.legitimate_memory_write is False for c in scored_benign), 2607)

    def test_unique_internal_ids_preserve_all_pooled_entries(self):
        by_id = {c.cid: c for c in self.cases}
        self.assertEqual(len(by_id), 6240)
        self.assertEqual(len({c.original_cid for c in self.cases}), 5940)
        for case in self.cases:
            self.assertEqual(case.cid, f"{case.source_split}:{case.original_cid}")
            self.assertIs(by_id[case.cid], case)

    def test_overlapping_ids_refer_to_distinct_source_records(self):
        attack = {c.original_cid: c for c in self.attack}
        benign = {c.original_cid: c for c in self.benign}
        overlap = set(attack) & set(benign)
        self.assertEqual(overlap, {f"ADV_{n}" for n in range(2699, 2999)})
        for original in overlap:
            self.assertNotEqual(attack[original].cid, benign[original].cid)
            self.assertNotEqual(attack[original].raw, benign[original].raw)
            self.assertTrue(attack[original].is_adversarial)
            self.assertFalse(benign[original].is_adversarial)

    def test_raw_payloads_order_and_file_bytes_unchanged(self):
        expected = []
        for filename, digest in EXPECTED_SHA256.items():
            path = DATA / filename
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), digest)
            expected.extend(strict_objects(path))
        self.assertEqual([c.raw for c in self.cases], expected)
        for case, raw in zip(self.cases, expected, strict=True):
            self.assertEqual(case.original_cid, raw["id"])
            for key in ("user_query", "context", "expected_memory", "retrieval_query"):
                self.assertEqual(getattr(case, key), raw.get(key, ""))

    def test_scored_attack_categories_are_preserved(self):
        counts = Counter(c.attack_type for c in self.attack if c.retrieval_query.strip())
        self.assertEqual(
            counts,
            {
                "repetition": 600,
                "explicit_keyword": 599,
                "delayed_conditional": 599,
                "fact_injection": 601,
                "experience_injection": 600,
            },
        )


if __name__ == "__main__":
    unittest.main()
