"""Reference isolation, evidence checks, closed stage gates and capped mock billing."""

import copy
import json
import re
import socket

import httpx
import pytest

from ams.research.ai_pilot import calibration as c
from ams.research.dynamic.models import LedgerError, canonical
from ams.research.pilot_finish.reviewer import StructuredSession
from test_llm_review import completion
from test_llm_review import plan as parent_plan  # noqa: F401


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def deny(*args, **kwargs):
        raise AssertionError("Only mock HTTP permitted")

    monkeypatch.setattr(socket.socket, "connect", deny)
    monkeypatch.setattr(socket.socket, "connect_ex", deny)
    monkeypatch.setattr(socket, "create_connection", deny)
    monkeypatch.setattr(socket, "getaddrinfo", deny)


def test_reference_changes_do_not_change_model_requests_and_no_family_leaks():
    row = c.corpus("development")[0]
    changed = {**copy.deepcopy(row), "aliases": ["Unlisted city"]}
    first, _ = c.make_jobs([row])
    second, _ = c.make_jobs([changed])
    assert first == second
    jobs, _ = c.make_jobs(c.corpus("development") + c.corpus("validation"))
    assert len(jobs) == 108
    for job in jobs:
        body = json.loads(job["request"]["messages"][1]["content"])
        assert set(body) == (
            {"passage", "question"} if job["checker_task"] == "support" else {"question"}
        )
        assert not {"aliases", "expected", "split", "family", "reference"} & set(body)
        assert "wrong_reference" not in canonical(body)
        assert "$12.4" not in canonical(body) and "ADV_" not in canonical(body)


def test_whitespace_aliases_preserve_numeric_punctuation_units_and_negation():
    assert c.normalized("4.8\u202fm") == c.normalized("4.8 m")
    assert c.literal_exposure("Is the limit 4.8\u202fm?", ["4.8 m"])
    assert not c.literal_exposure("Is the limit 4/8 m?", ["4.8 m"])
    assert not c.literal_exposure("Is the limit 4.8 km?", ["4.8 m"])
    assert c.normalized("8 MB") != c.normalized("8 Mb")
    raw = {
        "status": "answerable",
        "answer": "not open",
        "evidence": "The gate is not open.",
        "reason": "Explicit negation.",
    }
    assert c.support_decision(raw, ["open"]) == "not_confirmed"
    assert (
        c.support_decision({**raw, "answer": "open", "evidence": "The gate is closed."}, ["open"])
        == "uncertain"
    )


@pytest.mark.parametrize(
    "change",
    [
        {"extra": True},
        {"evidence": "invented"},
        {"status": "not_stated", "answer": "Lima"},
        {"reason": ""},
    ],
)
def test_invalid_extractions_fail_closed(change):
    body = {"passage": "The city is Lima.", "question": "Which city is stated?"}
    raw = {
        "status": "answerable",
        "answer": "Lima",
        "evidence": body["passage"],
        "reason": "Literal city.",
    }
    with pytest.raises(LedgerError):
        c.validate_extraction("support", body, {**raw, **change})


def oracle(kind, body, fail_conflict=False):
    if kind == "leakage":
        found = re.search(r"day immediately after (\w+)", body["question"])
        if found:
            days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
            return {
                "status": "answer_given",
                "answer": days[(days.index(found.group(1)) + 1) % 7],
                "evidence": found.group(0),
                "reason": "Calendar clue.",
            }
        return {
            "status": "answer_not_given",
            "answer": "",
            "evidence": "",
            "reason": "Requests an unknown value.",
        }
    text = body["passage"]
    if "equally authoritative" in text:
        if fail_conflict:
            return {
                "status": "answerable",
                "answer": re.search(r"as (.+?)\. Another", text).group(1),
                "evidence": text,
                "reason": "Deliberately wrong fixture decision.",
            }
        return {
            "status": "uncertain",
            "answer": "",
            "evidence": text,
            "reason": "Unresolved competing entries.",
        }
    if "does not specify" in text:
        return {
            "status": "not_stated",
            "answer": "",
            "evidence": "",
            "reason": "Requested field absent.",
        }
    answer = text.rsplit(" is ", 1)[1].removesuffix(".")
    if " handoff is on " in text:
        answer = answer.removeprefix("on ")
    return {
        "status": "answerable",
        "answer": answer,
        "evidence": text,
        "reason": "Literal stated value.",
    }


def test_corpus_denominators_and_abstention_cannot_pass():
    dev = c.corpus("development")
    held = c.corpus("validation")
    assert {x["case_id"] for x in dev}.isdisjoint(x["case_id"] for x in held)
    assert {(x["source"], x["memory"], x["question"]) for x in dev}.isdisjoint(
        (x["source"], x["memory"], x["question"]) for x in held
    )
    jobs, links = c.make_jobs(dev)
    votes = {
        j["call_id"]: {
            "valid": True,
            "extraction": oracle(
                j["checker_task"], json.loads(j["request"]["messages"][1]["content"])
            ),
        }
        for j in jobs
    }
    result = c.evaluate(dev, links, votes)
    assert result["passed"] and result["metrics"]["support_correct"] == 48
    assert result["metrics"]["leakage_correct"] == 24
    for v in votes.values():
        v["extraction"] = {
            "status": "uncertain",
            "answer": "",
            "evidence": "",
            "reason": "Abstain.",
        }
    assert not c.evaluate(dev, links, votes)["passed"]


@pytest.mark.parametrize("scenario", ["pass", "development_failure", "budget_stop"])
def test_staged_validation_and_restart_never_runs_target_or_pays_twice(
    request, monkeypatch, scenario
):
    original, cfg, _, _ = request.getfixturevalue("parent_plan")
    repo = original.parent
    for relative in [
        "scripts/calibrate_question_checker.py",
        "reports/QUESTION_CHECKER_CALIBRATION_20261101_PROTOCOL.md",
    ]:
        file = repo / relative
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_text("# offline fixture dependency\n")
    monkeypatch.setattr(c, "ENTRY_NANODOLLARS", 0)
    if scenario == "budget_stop":
        monkeypatch.setattr(c, "CALIBRATION_CAP_NANODOLLARS", 27000000)
    out = repo / "calibration"
    c.prepare(repo, out)
    _, jobs, _, _ = c.verify_study(out)
    seen = []

    def handler(request):
        data = json.loads(request.content)
        body = json.loads(data["messages"][1]["content"])
        seen.append(body)
        kind = "support" if "passage" in body else "leakage"
        assert "aliases" not in body and "expected" not in body
        return completion(oracle(kind, body, scenario == "development_failure"))

    transport = httpx.MockTransport(handler)

    def arm(self, plan, key):
        self.arm_annotation_mock(plan, transport)
        self.provider_preflight = {"test_only": True}

    monkeypatch.setenv("OPENROUTER_API_KEY", "offline-only")
    monkeypatch.setattr(StructuredSession, "arm_annotation", arm)
    result = c.run(out)
    if scenario == "pass":
        assert result["certificate_issued"] and result["splits_run"] == [
            "development",
            "validation",
        ]
        assert len(seen) == 108
    else:
        assert not result["certificate_issued"] and result["splits_run"] == ["development"]
        assert not (out / "checker_certificate.json").exists()
        held = {
            canonical(json.loads(j["request"]["messages"][1]["content"]))
            for j in jobs
            if j["split"] == "validation"
        }
        assert not any(canonical(b) in held for b in seen)
        if scenario == "budget_stop":
            assert result["status"] == "calibration_budget_stopped"
    assert (
        result["questions_promoted"]
        == result["human_verified_labels"]
        == result["defense_experiments"]
        == 0
    )
    count = len(seen)
    assert c.run(out) == result and len(seen) == count
    assert (out / "automated_proposals.jsonl").stat().st_size == 0
