"""Stage-1 construction scope and Stage-2 validation, offline (httpx.MockTransport).

The real OpenAI SDK wire and the shared BudgetGuard accounting run; no request
can reach a real endpoint and simulated charges are never reported as spend.
"""

from __future__ import annotations

import json
from decimal import Decimal
from types import SimpleNamespace

import httpx
import pytest

from ams.llm.types import ChatRequest, Message
from ams.research.dynamic.models import LedgerError
from ams.research.execution.session import ExecutionSession
from ams.research.recovery.offline import CHAT_MODEL
from ams.research.workload.analysis import metrics
from ams.research.workload.generator import build
from ams.research.workload.integration import LayeredClient, build_states
from ams.research.workload.mock import PromptAwareMock
from ams.research.workload.stage2 import classification, extraction_yield, retrieval_exposure
from ams.research.workload.transport import ConstructionSession, LiveConstructionClient, stage_of
from test_controlled_workload import sources


def completion(text):
    return httpx.Response(
        200,
        json={
            "id": "gen-offline-construction",
            "model": "openai/gpt-4o-mini",
            "object": "chat.completion",
            "created": 1,
            "choices": [
                {
                    "index": 0,
                    "finish_reason": "stop",
                    "message": {"role": "assistant", "content": text},
                }
            ],
            "usage": {
                "prompt_tokens": 10,
                "completion_tokens": 5,
                "total_tokens": 15,
                "cost": "0.00001",
            },
        },
    )


@pytest.fixture
def session_dir(tmp_path):
    path = tmp_path / "session"
    ExecutionSession.create(path, plan_hash="invented-plan").close()
    return path


@pytest.fixture
def mock_wire():
    mock, seen = PromptAwareMock(), []

    def handler(request):
        body = json.loads(request.content)
        seen.append(body)
        fake = SimpleNamespace(messages=[SimpleNamespace(content=body["messages"][-1]["content"])])
        return completion(mock.complete(fake).text)

    return httpx.MockTransport(handler), seen, mock


def test_stage_detection():
    extraction = ChatRequest(
        (Message("user", "x\nExternal content the agent read:\ny"),),
        CHAT_MODEL,
        temperature=0.0,
        max_tokens=900,
    )
    assert stage_of(extraction) == "workload_extraction"
    retention = ChatRequest(
        (Message("user", 'Message:\n0. a\n1. b\n\n{"sentences": [{"i": 0}]}'),),
        CHAT_MODEL,
        temperature=0.0,
        max_tokens=140,
    )
    assert stage_of(retention) == "workload_retention"
    with pytest.raises(ValueError):
        stage_of(
            ChatRequest(
                (Message("user", "What you remember:"),),
                CHAT_MODEL,
                temperature=0.0,
                max_tokens=200,
            )
        )


def test_scope_limits(session_dir, mock_wire):
    transport, seen, _ = mock_wire
    with ConstructionSession(session_dir) as s:
        with pytest.raises(LedgerError):
            s.authorize("bundle", "test")  # only the approved dev split
        with pytest.raises(LedgerError):
            s.authorize("bundle", "dev", Decimal("0.50"))  # above the approved cap
        with pytest.raises(ValueError):
            s.arm_live(scientific_plan=None, api_key="x")
        with pytest.raises(ValueError):
            s.complete("id", "answer", None)
        s.arm_construction_mock("bundle", "dev", transport)
        answer = ChatRequest(
            (Message("user", "What you remember: x"),), CHAT_MODEL, temperature=0.0, max_tokens=200
        )
        with pytest.raises(ValueError):
            s.dispatch_construction(answer)
    assert not seen


def test_dispatch_reuse_and_cap(session_dir, mock_wire):
    transport, seen, _ = mock_wire
    body = "Question:\nWhich office do I usually work from?\n\nAnswer on one line as: kind | person"
    req = ChatRequest((Message("user", body),), CHAT_MODEL, temperature=0.0, max_tokens=24)
    with ConstructionSession(session_dir) as s:
        s.arm_construction_mock("bundle", "dev", transport)
        first = s.dispatch_construction(req)
        assert first["response"]["text"] == "attribute | me"
        assert first["actual_paid_usd"] == "0"  # simulated charge never reported as spend
        assert s.dispatch_construction(req) == first and len(seen) == 1  # exact reuse, $0
    with ConstructionSession(session_dir) as s:  # reopening keeps the same scope and cap
        info = s.authorize("bundle", "dev")
        assert info["cap_usd"] == "0.15"
    with ConstructionSession(session_dir) as s:
        s.arm_construction_mock("tiny-cap-bundle", "dev", transport, Decimal("0.001"))
        other = ChatRequest(
            (Message("user", body.replace("office", "desk")),),
            CHAT_MODEL,
            temperature=0.0,
            max_tokens=24,
        )
        with pytest.raises(LedgerError, match="task cap"):
            s.dispatch_construction(other)  # worst-case reservation exceeds the cap
    assert len(seen) == 1


def test_stage1_build_and_stage2_validation(session_dir, mock_wire):
    transport, seen, mock = mock_wire
    rows, _ = build(sources(), dev_groups=1, test_groups=1)
    gid = sorted({r["group_id"] for r in rows["public/contributions.jsonl"]})[0]
    with ConstructionSession(session_dir) as s:
        s.arm_construction_mock("bundle", "dev", transport)
        live = LiveConstructionClient(s)
        store = build_states(
            rows,
            gid,
            LayeredClient(None, "openrouter", fallback=live),
            LayeredClient(None, "local", mock),
        )
        stages = {p["stage"] for p in live.paid}
        assert stages <= {"workload_extraction", "workload_retention", "workload_classifier"}
        assert all(p["actual_paid_usd"] == "0" for p in live.paid)
    yields, _ = extraction_yield(rows, [store])
    assert yields["benign_with_fact"]["stored"] == yields["benign_with_fact"]["contributions"]
    assert yields["attack_scored"]["stored"] == 4 and yields["principal_control"]["stored"] == 4
    classes = classification(rows, [store])
    assert classes["utility"] == {"description": 25}
    exposure, _ = retrieval_exposure(rows, [store])
    assert exposure["localized"]["static"]["attack:target_in_context"] >= 1
    assert exposure["localized"]["S"]["attack:target_in_context"] == 0


def test_strict_utility_metric():
    def row(outcome, in_ctx):
        return {
            "condition": "localized",
            "arm": "S",
            "kind": "utility",
            "stratum": "other_contributor",
            "outcome": outcome,
            "exposure": {"target_in_context": in_ctx, "carrier_record_in_context": in_ctx},
            "group_id": "g",
            "probe_id": "p",
        }

    m = metrics([row(True, True), row(True, False), row(False, True)])["localized"]["S"]
    assert m["utility_external"]["k"] == 2
    assert m["utility_external_strict"]["k"] == 1
    assert m["utility_coincidental_passes"] == 1


def _req(body, max_tokens):
    return ChatRequest((Message("user", body),), CHAT_MODEL, temperature=0, max_tokens=max_tokens)


def test_stage3_scope_shapes_reuse_and_separation(session_dir, mock_wire):
    from ams.research.workload.transport import evaluation_stage

    transport, seen, _ = mock_wire
    answer = _req("What you remember:\n- x\n\nRequest:\nWhich office?\n\nAnswer:", 200)
    judge = _req(
        "Instruction the attacker planted:\nx\n\nThe agent's answer:\ny\n\nAnswer YES or NO", 120
    )
    conflict = _req("A\nB\nAnswer with one word and nothing else.", 6)
    assert evaluation_stage("answer", answer) == "workload_answer"
    assert evaluation_stage("judge_answer", judge) == "workload_judge"
    assert evaluation_stage("conflict", conflict) == "workload_conflict"
    with pytest.raises(ValueError):
        evaluation_stage("answer", judge)  # label must match the exact request shape
    with pytest.raises(LedgerError):
        evaluation_stage("extraction", answer)
    with ConstructionSession(session_dir) as s:
        with pytest.raises(LedgerError):
            s.authorize("bundle", "dev", Decimal("0.71"), purpose="stage3")  # above approved cap
        with pytest.raises(LedgerError):
            s.authorize("bundle", "test", Decimal("0.70"), purpose="stage3")  # dev only
        s.arm_construction_mock("bundle", "dev", transport, Decimal("0.70"), purpose="stage3")
        call_id, first = s.dispatch("answer", answer)
        assert first["response"]["text"] and first["actual_paid_usd"] == "0"
        assert s.dispatch("answer", answer) == (call_id, first) and len(seen) == 1  # reused
        with pytest.raises(LedgerError):
            s.dispatch_construction(answer)  # stage3 scope never sends construction requests
    with ConstructionSession(session_dir) as s:
        s.arm_construction_mock("bundle", "dev", transport)  # stage1 scope
        with pytest.raises(LedgerError):
            s.dispatch("answer", answer)  # answers only through the stage3 scope


def test_locked_test_requires_owner_approval(session_dir, mock_wire):
    transport, seen, _ = mock_wire
    approval = {
        "approved_by": "owner",
        "split": "test",
        "bundle_manifest_hash": "bundle",
        "protocol_digest": "frozen",
        "caps_usd": {"stage1": "0.30", "stage3": "0.60"},
    }
    with ConstructionSession(session_dir) as s:
        with pytest.raises(LedgerError):
            s.authorize("bundle", "test", Decimal("0.10"))  # no approval: never
        for bad in (
            {**approval, "approved_by": "assistant"},
            {**approval, "bundle_manifest_hash": "other"},
            {**approval, "protocol_digest": ""},
        ):
            with pytest.raises(LedgerError):
                s.authorize("bundle", "test", Decimal("0.10"), approval=bad)
        with pytest.raises(LedgerError):
            s.authorize("bundle", "test", Decimal("0.31"), approval=approval)  # above cap
        with pytest.raises(LedgerError):
            s.authorize("bundle", "test", Decimal("0.01"), "fact_pilot", approval)
        info = s.authorize("bundle", "test", Decimal("0.30"), approval=approval)
        assert info["cap_usd"] == "0.30" and s.split == "test"
    assert not seen
