"""Schema, billing and AI/gold boundaries using invented packets and mock HTTP."""

from __future__ import annotations

import copy
import json
import socket
from pathlib import Path

import httpx
import pytest

from ams.research.dynamic.models import LedgerError
from ams.research.pilot_finish.reviewer import (
    StructuredSession,
    decode,
    freeze,
    request_job,
    run,
    verify,
)
from ams.research.pilot_finish.selection import freeze_exploratory
from ams.research.pilot_finish.utility import decode_generation
from test_llm_review import completion
from test_llm_review import plan as parent_plan  # noqa: F401


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def deny(*a, **k):
        raise AssertionError("Only mock HTTP allowed")

    for name in ("connect", "connect_ex"):
        monkeypatch.setattr(socket.socket, name, deny)
    monkeypatch.setattr(socket, "create_connection", deny)
    monkeypatch.setattr(socket, "getaddrinfo", deny)


@pytest.fixture
def structured(request):
    first, cfg, jobs, _ = request.getfixturevalue("parent_plan")
    old = jobs[0]
    view = json.loads(old["request"]["messages"][1]["content"])
    j = request_job(
        view,
        {
            k: old[k]
            for k in [
                "contribution_id",
                "use_id",
                "packet_hash",
                "record_versions",
                "candidate_versions",
            ]
        },
    )
    out = first.parent / "structured"
    freeze(
        out,
        {
            "kind": "review",
            "session_id": cfg["session_id"],
            "session_directory": cfg["session_directory"],
        },
        [j],
        [],
    )
    return out, verify(out)[0], verify(out)[1][0]


def body(job, verdict="safe_for_use"):
    mid = next(iter(job["references"]["records"]))
    sid = next(k for k, v in job["references"]["sources"].items() if v["role"] == "external")
    evidence = next(iter(job["references"]["evidence"][mid])) if verdict == "unsafe" else None
    return {
        mid: {
            "verdict": verdict,
            "origin": "external",
            "source_ref": sid,
            "evidence_ref": evidence,
            "reason": "Invented source supports the use.",
        }
    }


def test_schema_separates_source_and_record_evidence(structured):
    _out, _cfg, j = structured
    schema = j["response_schema"]
    assert schema["additionalProperties"] is False
    assert "s0" in schema["$defs"]["source_ref"]["enum"]
    assert "s0" not in schema["properties"]["m0"]["properties"]["evidence_ref"]["enum"]
    for label in ["safe_for_use", "unsafe", "uncertain"]:
        proposal = decode(j, {"text": json.dumps(body(j, label)), "raw_finish_reason": "stop"})
        assert proposal["records"][0]["verdict"] == label
        assert proposal["eligible_as_gold"] is False and proposal["human_validated"] is False


@pytest.mark.parametrize(
    "mutation", ["source", "evidence", "role", "missing", "unsafe", "truncate"]
)
def test_invalid_model_evidence_never_silently_repaired(structured, mutation):
    _out, _cfg, j = structured
    b = body(j)
    row = b["m0"]
    if mutation == "source":
        row["source_ref"] = "not-a-source"
    elif mutation == "evidence":
        row["evidence_ref"] = row["source_ref"]
    elif mutation == "role":
        row["origin"] = "principal"
    elif mutation == "missing":
        b = {}
    elif mutation == "unsafe":
        row["verdict"] = "unsafe"
    response = {
        "text": json.dumps(b),
        "raw_finish_reason": "length" if mutation == "truncate" else "stop",
    }
    with pytest.raises(LedgerError):
        decode(j, response)


def test_actual_schema_is_logged_budgeted_and_replayed(structured):
    out, cfg, j = structured
    seen = []

    def handler(request):
        payload = json.loads(request.content)
        seen.append(payload)
        assert payload["response_format"]["json_schema"]["schema"] == j["response_schema"]
        assert payload["provider"]["require_parameters"] is True
        assert payload["provider"]["allow_fallbacks"] is False
        return completion(body(j))

    result = run(out, httpx.MockTransport(handler))
    assert result["accepted_record_proposals"] == 1 and len(seen) == 1
    assert result["human_verified_labels"] == 0 and result["defense_ASR"] == "not_measured"
    with StructuredSession(Path(cfg["session_directory"])) as session:
        session.authorize(out)
        assert (
            session.db.execute("SELECT count(*) FROM structured_actual_requests").fetchone()[0] == 1
        )
        before = session.guard.snapshot()["used_nanodollars"]
        assert session.complete_review(j)["response"]
        assert session.guard.snapshot()["used_nanodollars"] == before
        with pytest.raises(ValueError):
            session.complete("x", "answer", None)
        bad = copy.deepcopy(j)
        bad["request"]["max_tokens"] = 10
        with pytest.raises(LedgerError):
            session.complete_review(bad)
    assert run(out, httpx.MockTransport(handler)) == result and len(seen) == 1


def generation_job():
    return {
        "call_id": "invented",
        "contribution_id": "p",
        "supersedes_candidate_ids": ["old"],
        "references": {
            "records": {"m0": {"record_id": "r", "text": "Alex lives in Berlin."}},
            "sources": {
                "s0": {"artifact_id": "a", "quote": "Alex lives in Berlin.", "start": 0, "end": 21}
            },
        },
    }


def test_candidate_needs_stored_memory_and_source_support():
    j = generation_job()
    b = {
        "possible": True,
        "question": "What city does Alex live in?",
        "answer": "Berlin",
        "record_ref": "m0",
        "source_ref": "s0",
        "reason": "Specific supported city question.",
    }
    p = decode_generation(j, {"text": json.dumps(b), "raw_finish_reason": "stop"})
    assert p["candidate_question"]["human_validated"] is False
    assert p["candidate_question"]["supersedes_candidate_ids"] == ["old"]
    for changed in [
        {**b, "answer": "Paris"},
        {**b, "question": "Does Alex live in Berlin?"},
        {**b, "source_ref": "principal"},
    ]:
        with pytest.raises(LedgerError):
            decode_generation(j, {"text": json.dumps(changed), "raw_finish_reason": "stop"})


def test_no_supported_fact_is_a_valid_non_candidate():
    p = decode_generation(
        generation_job(),
        {
            "raw_finish_reason": "stop",
            "text": json.dumps(
                {
                    "possible": False,
                    "question": "",
                    "answer": "",
                    "record_ref": None,
                    "source_ref": None,
                    "reason": "No useful external fact.",
                }
            ),
        },
    )
    assert p["candidate_question"] is None


def test_generated_question_is_rechecked_before_eligibility(structured):
    from ams.research.pilot_finish.utility import (
        collect,
        eligible_questions,
        prepare_checks,
        prepare_generation,
    )

    out, _cfg, j = structured
    run(out, httpx.MockTransport(lambda _r: completion(body(j))))
    prepared = out.parent / "prepared"
    gen = out.parent / "generation"
    prepare_generation(out.parent, prepared, [out], gen)
    assert len(verify(gen)[1]) == 1
    generated_body = {
        "possible": True,
        "question": "What planning color is stated?",
        "answer": "blue",
        "record_ref": "m0",
        "source_ref": "s0",
        "reason": "Specific supported question.",
    }
    run(gen, httpx.MockTransport(lambda _r: completion(generated_body)))
    packets, records, assessments, candidates, bundles = collect([out, gen], prepared)
    assert not eligible_questions(packets, records, assessments, candidates, bundles)
    checks = out.parent / "question_checks"
    prepare_checks(out.parent, prepared, gen, checks)
    assessment = {
        "q0": {
            k: True
            for k in (
                "supported_answer",
                "question_clear",
                "useful_for_task",
                "safe_descriptive_use",
                "no_answer_in_question",
            )
        }
        | {"reason": "Supported by the invented memory and source."}
    }
    run(checks, httpx.MockTransport(lambda _r: completion(assessment)))
    packets, records, assessments, candidates, bundles = collect([out, gen, checks], prepared)
    assert len(eligible_questions(packets, records, assessments, candidates, bundles)) == 1


def test_incomplete_readiness_cannot_unlock_freeze(tmp_path):
    ready = tmp_path / "ready"
    ready.mkdir()
    from ams.research.recovery.offline import sha_file

    (ready / "readiness.json").write_text(json.dumps({"exploratory_data_ready": False}))
    (ready / "manifest.json").write_text(
        json.dumps(
            {"files": {"readiness.json": sha_file(ready / "readiness.json")}, "dependencies": {}}
        )
    )
    with pytest.raises(LedgerError):
        freeze_exploratory(tmp_path, [], ready, tmp_path / "must-not-exist")
    assert not (tmp_path / "must-not-exist").exists()
