"""Published-defence adapters on the controlled workload. Offline; scripted LLM replies."""

from __future__ import annotations

import socket
from pathlib import Path

import pytest

from ams.baselines.memlineage import SensitiveAction, Trust, parents_of, propagate
from ams.core.prompts import PromptLibrary
from ams.research.recovery.offline import CHAT_MODEL
from ams.research.workload import published as P
from ams.research.workload.generator import build
from ams.research.workload.integration import LayeredClient, build_states, group_rows
from ams.research.workload.mock import PromptAwareMock
from ams.research.workload.runner import prepare_state
from ams.research.workload.stage2 import ConflictPlaceholderSession
from test_controlled_workload import sources

RANDEC = Path("third_party/AMemGuard/certified-llm-safety/models/distilbert_suffix.pt")


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def deny(*a, **k):
        raise AssertionError("Adapter tests forbid networking")

    for key in ("connect", "connect_ex"):
        monkeypatch.setattr(socket.socket, key, deny)
    monkeypatch.setattr(socket, "create_connection", deny)


@pytest.fixture(scope="module")
def world():
    from ams.research.provisional_run.runner import resolve_models

    rows, _ = build(sources(), dev_groups=1, test_groups=1)
    gid = sorted({r["group_id"] for r in rows["public/contributions.jsonl"]})[0]
    mock = PromptAwareMock()
    store = build_states(
        rows, gid, LayeredClient(None, "openrouter", mock), LayeredClient(None, "local", mock)
    )
    group = group_rows(rows, gid)
    state = prepare_state(store["snapshots"]["localized"], [], "static")
    resolve_models(state, ConflictPlaceholderSession())
    contexts = {p["probe_id"]: P.retrieve(state, store, p["question"]) for p in group["probes"]}
    return store, group, contexts


def kind_of(group, pid):
    return group["private_probes"][pid]["kind"]


def test_write_time_context_gives_paper_labels(world):
    store, group, contexts = world
    seen = set()
    for pid, entries in contexts.items():
        for m, e in zip(P.memory_entries(store, group, entries), entries, strict=True):
            label = propagate([(t, 1.0) for _, t in parents_of(m)], 0.0)
            kind = store["record_owner"][e["entry_id"]]["kind"]
            expected = Trust.TRUSTED if kind == "principal" else Trust.EXTERNAL
            assert label == expected
            seen.add(kind)
    assert seen == {"principal", "external"}


def sensitivity(verdicts):
    prompts = PromptLibrary()
    client = P.RecordedSensitivity(verdicts, prompts.get("sensitive_action", "v1"), CHAT_MODEL)
    return SensitiveAction(client=client, model=CHAT_MODEL, prompts=prompts), client


def test_memlineage_denies_only_sensitive_queries_with_untrusted_memory(world):
    store, group, contexts = world
    probe = next(p for p in group["probes"] if kind_of(group, p["probe_id"]) == "attack")
    q, entries = probe["question"], contexts[probe["probe_id"]]
    for reply, expect_empty in (("SENSITIVE", True), ("ORDINARY", False)):
        sens, _ = sensitivity({q: reply})
        out = P.apply(P.memlineage(sens), store, group, q, entries)
        if expect_empty:
            assert out["kept"] == [] and out["reason"].startswith("Deny")
        else:
            assert out["kept"] == [e["entry_id"] for e in entries]
            # Exposure is computed on the original text, not the sentinel rendering.
            assert out["kept_entries"] == entries


def test_memlineage_allows_sensitive_query_with_only_trusted_memory(world):
    store, group, contexts = world
    for p in group["probes"]:
        entries = contexts[p["probe_id"]]
        trusted = [e for e in entries if store["record_owner"][e["entry_id"]]["kind"] == "principal"]
        if trusted:
            sens, _ = sensitivity({p["question"]: "SENSITIVE"})
            out = P.apply(P.memlineage(sens), store, group, p["question"], trusted)
            assert out["kept"] == [e["entry_id"] for e in trusted]
            return
    pytest.skip("no principal-only context in the fixture")


def test_recorded_sensitivity_never_guesses(world):
    store, group, contexts = world
    probe = group["probes"][0]
    sens, client = sensitivity({})
    with pytest.raises(LookupError):
        P.apply(P.memlineage(sens), store, group, probe["question"], contexts[probe["probe_id"]])
    assert client.misses


@pytest.mark.skipif(not RANDEC.exists(), reason="RandEC weights not vendored")
def test_randec_adapter_returns_a_subset_with_original_text(world, monkeypatch):
    monkeypatch.setenv("HF_HUB_OFFLINE", "1")
    from ams.baselines.amemguard_borrowed import RandECClassifier

    store, group, contexts = world
    rc = RandECClassifier(weights=RANDEC)
    for p in group["probes"][:3]:
        entries = contexts[p["probe_id"]]
        out = P.apply(rc, store, group, p["question"], entries)
        ids = [e["entry_id"] for e in entries]
        assert set(out["kept"]) <= set(ids) and set(out["kept"]) | set(out["flagged"]) == set(ids)
        assert all(e in entries for e in out["kept_entries"])


def test_amemguard_adapter_uses_upstream_checker_with_scripted_replies(world):
    from ams.baselines.amemguard import AMemGuard
    from ams.llm.types import ChatResponse, Usage

    store, group, contexts = world
    probe = group["probes"][0]
    entries = contexts[probe["probe_id"]]

    class Scripted:
        calls = 0

        def complete(self, request):
            Scripted.calls += 1
            body = request.messages[-1].content
            text = "chain" if "judg" not in body.lower() else '{"inconsistent_ids": [0]}'
            return ChatResponse(text, request.model, "scripted", Usage(1, 1, 0.0))

    try:
        out = P.apply(AMemGuard(model=CHAT_MODEL, client=Scripted()), store, group,
                      probe["question"], entries)  # fmt: skip
    except FileNotFoundError:
        pytest.skip("A-MemGuard upstream not vendored")
    assert Scripted.calls >= len(entries)  # one reasoning chain per memory (+ judgment)
    assert set(out["kept"]) <= {e["entry_id"] for e in entries}
