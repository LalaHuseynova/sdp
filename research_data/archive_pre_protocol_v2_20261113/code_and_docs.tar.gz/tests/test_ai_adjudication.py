"""One-round control gates, preserved uncertainty and no live network in tests."""

import json
import socket
from dataclasses import asdict

import httpx
import pytest

from ams.llm.types import ChatRequest, Message
from ams.research.ai_pilot.adjudication import (
    CONTRACT,
    KEYS,
    PROMPT,
    assess,
    controls,
    run,
    schema,
)
from ams.research.dynamic.models import LedgerError, canonical, digest
from ams.research.llm_review.design import MODEL, OUTPUT_LIMIT
from ams.research.pilot_finish.reviewer import SCHEMA, StructuredSession, freeze
from test_llm_review import completion
from test_llm_review import plan as parent_plan  # noqa: F401


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def deny(*a, **kw):
        raise AssertionError("Only mock HTTP allowed")

    monkeypatch.setattr(socket.socket, "connect", deny)
    monkeypatch.setattr(socket.socket, "connect_ex", deny)
    monkeypatch.setattr(socket, "create_connection", deny)
    monkeypatch.setattr(socket, "getaddrinfo", deny)


def positive():
    return {
        **{k: "yes" for k in KEYS},
        "answer_leakage": "absent",
        "reason": "Supported descriptive fact.",
    }


def test_uncertainty_is_retained_and_literal_answer_leak_vetoes_pass():
    q = "According to the note, what revenue was reported?"
    assert (
        assess({**positive(), "answer_leakage": "uncertain"}, q, ["$12.4 million"])[
            "no_answer_in_question"
        ]
        is None
    )
    assert (
        assess(positive(), "Was revenue $12.4 million?", ["$12.4 million"])["no_answer_in_question"]
        is False
    )
    assert (
        assess({**positive(), "support_in_source": "uncertain"}, q, ["$12.4 million"])[
            "supported_answer"
        ]
        is None
    )


@pytest.mark.parametrize(
    "change", [{"extra": True}, {"support_in_source": True}, {"answer_leakage": "no"}]
)
def test_malformed_vote_is_rejected(change):
    with pytest.raises(LedgerError):
        assess({**positive(), **change}, "What city is stated?", ["Rome"])


@pytest.mark.parametrize("fail_control", [False, True])
def test_controls_gate_promotion_and_completed_round_never_redispatches(
    request, monkeypatch, fail_control
):
    original, cfg, _jobs, _ = request.getfixturevalue("parent_plan")
    jobs = []
    for i, fixture in enumerate(controls()):
        jobs.append(
            {
                "purpose": "synthetic_control",
                "control_index": i,
                "expected": fixture["expected"],
                "body": {k: v for k, v in fixture.items() if k != "expected"},
            }
        )
    for i in range(8):
        jobs.append(
            {
                "purpose": "real_control",
                "contribution_id": f"control_{i}",
                "body": {
                    "source": f"Note {i} says Rome.",
                    "memory": f"Note {i} says Rome.",
                    "question": f"What city does note {i} state?",
                    "answers": ["Rome"],
                },
            }
        )
    jobs.append(
        {
            "purpose": "target",
            "contribution_id": "p",
            "use_id": "use",
            "parent_candidate_id": "old_q",
            "candidate_copy": {
                "candidate_id": "old_q",
                "contribution_id": "p",
                "question": "What city is in the final note?",
                "answers": ["Rome"],
                "human_validated": False,
            },
            "body": {
                "source": "The final note says Rome.",
                "memory": "The final note says Rome.",
                "question": "What city is in the final note?",
                "answers": ["Rome"],
            },
        }
    )
    for job in jobs:
        request = ChatRequest(
            (
                Message("system", PROMPT + "\n" + canonical(schema())),
                Message("user", canonical(job.pop("body"))),
            ),
            MODEL,
            temperature=0.0,
            max_tokens=OUTPUT_LIMIT,
        )
        key = request.cache_key("openrouter")
        job.update(
            request=asdict(request),
            request_key=key,
            call_id=digest([SCHEMA, key]),
            response_schema=schema(),
        )
    out = original.parent / "adjudication"
    freeze(
        out,
        {
            "kind": CONTRACT,
            "session_id": cfg["session_id"],
            "session_directory": cfg["session_directory"],
            "rounds": 1,
            "max_attempts_each": 1,
            "targets": 1,
            "real_controls": 8,
            "synthetic_controls": 4,
        },
        jobs,
        [],
    )
    seen = []

    def handler(request):
        payload = json.loads(request.content)
        body = json.loads(payload["messages"][1]["content"])
        seen.append(body)
        assert not {"purpose", "expected", "prior_vote", "quota"} & set(body)
        answer = positive()
        for control in controls():
            if body == {k: v for k, v in control.items() if k != "expected"}:
                answer.update(control["expected"])
        if fail_control and body["answers"] == ["Berlin"]:
            answer.update(support_in_memory="yes", support_in_source="yes")
        return completion(answer)

    transport = httpx.MockTransport(handler)
    monkeypatch.setenv("OPENROUTER_API_KEY", "offline-key")

    def arm_mock(self, plan, key):
        self.arm_annotation_mock(plan, transport)
        self.provider_preflight = {"test_only": True}

    monkeypatch.setattr(StructuredSession, "arm_annotation", arm_mock)
    summary = run(out)
    assert summary["synthetic_control_gate_passed"] is not fail_control
    assert summary["targets_passing"] == (0 if fail_control else 1)
    assert summary["human_verified_labels"] == summary["human_validated_questions"] == 0
    rows = [json.loads(x) for x in (out / "automated_proposals.jsonl").read_text().splitlines()]
    if rows:
        assert rows[0]["candidate_question"]["candidate_id"].startswith("qadj_")
        assert rows[0]["candidate_question"]["review_contract_parent_candidate_id"] == "old_q"
        assert rows[0]["eligible_as_gold"] is False
    assert len(seen) == 13
    assert run(out) == summary and len(seen) == 13
