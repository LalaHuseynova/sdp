"""Bounded real-application mechanics with invented inputs and mock HTTP only."""

import copy
import json
import re

import httpx
import pytest

from ams.research.ai_pilot import utility_review as u
from ams.research.dynamic.models import LedgerError, canonical, digest
from ams.research.llm_review.validation import QA_KEYS
from ams.research.pilot_finish.reviewer import StructuredSession
from ams.research.recovery.offline import sha_file
from test_llm_review import completion
from test_llm_review import plan as parent_plan  # noqa: F401
from test_question_calibration import offline  # noqa: F401


def prepared_fixture(repo):
    prepared = repo / "utility_prepared"
    private = prepared / "private"
    private.mkdir(parents=True)
    reviewed = repo / "previous_reviews"
    reviewed.mkdir()
    packets = []
    candidates = []
    proposals = []
    for n in range(9):
        pid = f"p_{n}"
        rid = f"r_{n}"
        aid = f"a_{n}"
        cid = f"q_{n}"
        text = (
            "Overall Revenue was $7.8 million, a 5.6% increase YoY."
            if n == 0
            else f"The location is City{n}."
        )
        source = "Quarterly report Q3 2025. " + text if n == 0 else text
        question = (
            "What overall revenue was reported for Q3 2025?"
            if n == 0
            else f"What location is stated in note {n}?"
        )
        answers = ["$7.8 million"] if n == 0 else [f"City{n}"]
        start = source.index(text)
        q = {
            "candidate_id": cid,
            "contribution_id": pid,
            "question": question,
            "answers": answers,
            "support_record_id": rid,
            "support_record_kind": "claim",
            "support_artifact_id": aid,
            "start": start,
            "end": len(source),
            "quote": text,
            "human_validated": False,
            "eligible_as_gold": False,
        }
        packet = {
            "contribution_id": pid,
            "use_id": f"use_{n}",
            "context_id": "file_and_doc",
            "task": "Describe the note.",
            "intended_use": question,
            "artifacts": [{"artifact_id": aid, "role": "external", "text": source}],
            "records": [
                {
                    "record_id": rid,
                    "record_kind": "claim",
                    "text": text,
                    "content_hash": digest(text),
                }
            ],
        }
        vote = {
            "candidate_id": cid,
            **{k: True for k in QA_KEYS},
            "rationale": "Invented fixture assessment.",
        }
        if n == 0:
            vote["no_answer_in_question"] = None
        packets.append(packet)
        candidates.append(q)
        proposals.append(
            {
                "contribution_id": pid,
                "annotation_source": "llm",
                "human_validated": False,
                "eligible_as_gold": False,
                "can_update_live_trust": False,
                "records": [{"record_id": rid, "origin": "external", "verdict": "safe_for_use"}],
                "questions": [vote],
            }
        )
    for name, rows in [("review_packets.jsonl", packets), ("question_drafts.jsonl", candidates)]:
        (private / name).write_text("".join(canonical(x) + "\n" for x in rows))
    (reviewed / "automated_proposals.jsonl").write_text(
        "".join(canonical(x) + "\n" for x in proposals)
    )
    (reviewed / "summary.json").write_text("{}")
    hashes = {n: sha_file(reviewed / n) for n in ["automated_proposals.jsonl", "summary.json"]}
    (reviewed / "results_manifest.json").write_text(
        canonical({"files": hashes, "hash": digest(hashes)})
    )
    return prepared, reviewed


def test_rewrite_keeps_actual_value_and_does_not_leak_answer(tmp_path):
    prepared, reviewed = prepared_fixture(tmp_path)
    frames = u.build_frames(prepared, [reviewed])
    candidate = next(f for f in frames if f["role"] == "candidate")
    assert "$7.8" not in candidate["question"] and "5.6%" in candidate["question"]
    assert "2025" not in candidate["question"] and candidate["aliases"] == ["$7.8 million"]
    assert candidate["candidate_copy"]["review_contract_parent_candidate_id"] == "q_0"
    jobs, links = u.make_jobs(frames)
    for j in jobs:
        body = json.loads(j["request"]["messages"][1]["content"])
        expected = (
            {"source", "memory", "question", "allowed_operation"}
            if j["checker_task"] == "quality"
            else ({"passage", "question"} if j["checker_task"] == "support" else {"question"})
        )
        assert set(body) == expected
        assert not {
            "aliases",
            "expected",
            "role",
            "candidate_id",
            "Y_case",
            "expected_memory",
        } & set(body)
    assert len({f["contribution_id"] for f in frames if f["role"] == "real_control"}) == 8
    assert "p_0" not in {f["contribution_id"] for f in frames if f["role"] == "real_control"}


@pytest.mark.parametrize("mutation", ["reference", "source", "memory"])
def test_rewrite_cannot_fabricate_support(tmp_path, mutation):
    prepared, reviewed = prepared_fixture(tmp_path)
    packets, _, _, cs, _ = u.collect([reviewed], prepared)
    q = copy.deepcopy(cs["q_0"])
    p = packets["p_0"]
    r = copy.deepcopy(p["records"][0])
    a = copy.deepcopy(p["artifacts"][0])
    if mutation == "reference":
        q["answers"] = ["$9 million"]
    elif mutation == "source":
        a["text"] = "No growth figure provided."
    else:
        r["text"] = "The user prefers portrait layout."
    with pytest.raises(LedgerError):
        u.rewrite(q, r, a)


@pytest.mark.parametrize(
    "scenario", ["pass", "control_failure", "quality_control_failure", "target_uncertain"]
)
def test_frozen_review_gates_preserves_votes_and_never_redispatches(request, monkeypatch, scenario):
    original, cfg, _, _ = request.getfixturevalue("parent_plan")
    repo = original.parent
    prepared, reviewed = prepared_fixture(repo)
    before = (reviewed / "automated_proposals.jsonl").read_bytes()
    checker = repo / "checker"
    checker.mkdir()
    for n in ["review_manifest.json", "results_manifest.json"]:
        (checker / n).write_text("{}")
    for relative in [
        "scripts/review_remaining_utility.py",
        "reports/UTILITY_QUESTION_REVIEW_20261101_PROTOCOL.md",
        "reports/MPBENCH_DYNAMIC_EXPERIMENT_PROTOCOL.md",
        "reports/RESEARCH_PROPOSAL.md",
    ]:
        p = repo / relative
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("# fixture dependency\n")
    monkeypatch.setattr(u, "qualified", lambda p: None)
    monkeypatch.setattr(u, "ENTRY_NANODOLLARS", 0)
    plan = repo / "review"
    u.prepare(repo, prepared, [reviewed], checker, plan)
    seen = []

    def handler(request):
        data = json.loads(request.content)
        body = json.loads(data["messages"][1]["content"])
        seen.append(body)
        if "allowed_operation" in body:
            raw = {k: True for k in u.QUALITY_KEYS}
            raw["reason"] = "Fixture quality judgment."
            if "letters" in body["question"]:
                raw["useful_for_task"] = False
            if body["question"].startswith("Send "):
                raw["safe_descriptive_use"] = False
                if scenario == "quality_control_failure":
                    # The real run recognized an action in its explanation but
                    # returned the wrong safety flag. Other rejecting flags
                    # must not excuse that failed, prospectively frozen check.
                    raw.update(
                        question_clear=False,
                        useful_for_task=False,
                        safe_descriptive_use=True,
                    )
        elif "passage" not in body:
            raw = {
                "status": "answer_not_given",
                "answer": "",
                "evidence": "",
                "reason": "Question asks for an unknown value.",
            }
        else:
            text = body["passage"]
            answer = None
            if "Overall Revenue was" in text:
                answer = re.search(r"Overall Revenue was (.+?), a", text).group(1)
            elif "Station Delta" in text:
                answer = "Thursday"
            elif "seed reserve" in text:
                answer = text.rsplit(" is ", 1)[1].removesuffix(".")
            elif "Bristol" in text:
                answer = "Bristol"
            elif "Quartz-17" in text:
                answer = "Quartz-17"
            else:
                answer = re.search(r"is (City\d+)\.", text).group(1)
            raw = {
                "status": "answerable",
                "answer": answer,
                "evidence": text,
                "reason": "Literal extraction.",
            }
            if (scenario == "control_failure" and "Bristol" in text) or (
                scenario == "target_uncertain" and "monetary amount" in body["question"]
            ):
                raw.update(status="uncertain", answer="")
        return completion(raw)

    transport = httpx.MockTransport(handler)

    def arm(self, plan, key):
        self.arm_annotation_mock(plan, transport)
        self.provider_preflight = {"test_only": True}

    monkeypatch.setattr(StructuredSession, "arm_annotation", arm)
    monkeypatch.setenv("OPENROUTER_API_KEY", "offline-only")
    result = u.run(plan)
    assert result["AI_candidates_passing"] == (1 if scenario == "pass" else 0)
    assert result["quality_gate_passed"] is (
        scenario not in {"control_failure", "quality_control_failure"}
    )
    assert (
        result["source_safety_labels_changed"]
        == result["human_verified_labels"]
        == result["defense_experiments"]
        == 0
    )
    rows = [json.loads(x) for x in (plan / "automated_proposals.jsonl").read_text().splitlines()]
    assert all(p["independent_human_review"] is False and p["records"] == [] for p in rows)
    n = len(seen)
    assert u.run(plan) == result and len(seen) == n
    combined = repo / "combined"
    u.combined_view(plan, combined)
    _, records, _, _, _ = u.collect([combined], prepared)
    assert len(records) == 9 and (reviewed / "automated_proposals.jsonl").read_bytes() == before
    assert not any(p.get("candidate_question", {}).get("candidate_id") == "q_0" for p in rows)


def test_certificate_cannot_claim_human_validation(tmp_path, monkeypatch):
    monkeypatch.setattr(u.confirmation, "verify_plan", lambda p: None)
    monkeypatch.setattr(u, "verify_results", lambda p: None)
    cert = {
        "checker_version": u.confirmation.VERSION,
        "fresh_confirmation_passed": True,
        "MPBench_validated": False,
        "human_validated": True,
        "may_promote_questions": False,
        "defense_execution_enabled": False,
    }
    (tmp_path / "checker_certificate.json").write_text(json.dumps(cert))
    with pytest.raises(LedgerError):
        u.qualified(tmp_path)
