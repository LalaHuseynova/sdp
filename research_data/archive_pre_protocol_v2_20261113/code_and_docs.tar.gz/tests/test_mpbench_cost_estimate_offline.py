"""Cost accounting checks: no clients, keys, or network calls are used."""

from __future__ import annotations

import importlib.util
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "mpbench_estimator_under_test", ROOT / "scripts/estimate_mpbench_cost.py"
)
ESTIMATOR = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ESTIMATOR)


class CostEstimateChecks(unittest.TestCase):
    def setUp(self):
        self.block = patch(
            "socket.socket.connect", side_effect=AssertionError("Cost planning must stay offline")
        )
        self.block.start()
        self.addCleanup(self.block.stop)
        self.cases = [
            SimpleNamespace(
                is_adversarial=True,
                retrieval_query="Which destination?",
                expected_memory="Use an untrusted destination.",
                user_query="Summarize this.",
                context="An external document.",
                legitimate_memory_write=None,
            ),
            SimpleNamespace(
                is_adversarial=False,
                retrieval_query="What do I prefer?",
                expected_memory="Concise answers.",
                user_query="Remember my preference.",
                context="An external document.",
                legitimate_memory_write=True,
            ),
        ]
        self.catalog = {
            "models": [
                {"id": "example/test", "pricing": {"prompt": "0.000001", "completion": "0.000002"}}
            ]
        }

    def job(self, defense="no_defence"):
        return {
            "id": f"test/{defense}",
            "backbone": "test",
            "method": defense,
            "source_config": "test-only",
            "config": {
                "models": dict.fromkeys(("memory", "agent", "judge"), "openrouter:example/test"),
                "pool_size": 2,
                "retrieve_k": 4,
                "defences": [defense],
            },
        }

    def test_simple_calls_totals_and_role_token_pricing(self):
        report = ESTIMATOR.estimate_jobs([self.job()], self.catalog, self.cases)
        row = report["jobs"][0]
        scenario = row["scenarios"]["typical"]
        self.assertEqual(scenario["logical_chat_requests"], 10)
        self.assertEqual(scenario["assumed_uncached_paid_requests"], 10)
        self.assertEqual(scenario["cache_discount_requests"], 0)
        self.assertEqual(row["local_embeddings"]["estimated_usd"], 0)
        for stage in scenario["stages"]:
            expected = stage["input_tokens"] * 1e-6 + stage["output_tokens"] * 2e-6
            self.assertAlmostEqual(stage["estimated_usd"], expected, places=6)
        self.assertEqual(report["by_job"][row["id"]], row)
        self.assertEqual(report["totals"]["typical"]["logical_chat_requests"], 10)

    def test_sanitizer_counts_rewrites_and_conservative_scenario(self):
        report = ESTIMATOR.estimate_jobs([self.job("llm_sanitiser")], self.catalog, self.cases)
        scenarios = report["jobs"][0]["scenarios"]
        self.assertEqual(scenarios["typical"]["logical_chat_requests"], 20)
        self.assertEqual(scenarios["conservative"]["logical_chat_requests"], 26)
        self.assertGreater(
            scenarios["conservative"]["estimated_usd"], scenarios["typical"]["estimated_usd"]
        )

    def test_missing_price_or_reduced_memory_pool_fails_closed(self):
        with self.assertRaisesRegex(ValueError, "Unpriced model"):
            ESTIMATOR.estimate_jobs([self.job()], {"models": []}, self.cases)
        reduced = self.job()
        reduced["config"]["pool_size"] = 1
        with self.assertRaisesRegex(ValueError, "pool_size must match"):
            ESTIMATOR.estimate_jobs([reduced], self.catalog, self.cases)


if __name__ == "__main__":
    unittest.main()
