"""Artificial audit fixtures only: these are not human reviews or MPBench results."""

from __future__ import annotations

import json
import socket
from dataclasses import asdict, replace

import pytest

from ams.research.dynamic import (
    Audit,
    Candidate,
    EvidenceLedger,
    EvidenceSnapshot,
    Finding,
    LedgerError,
    Policy,
    Provenance,
    Register,
    Retract,
    StoredRecord,
)
from ams.research.dynamic.models import canonical, digest, event_dict, parse_event


@pytest.fixture(autouse=True)
def forbid_network(monkeypatch):
    def denied(*args, **kwargs):
        raise AssertionError("No network or model fallback allowed")

    monkeypatch.setattr(socket.socket, "connect", denied)
    monkeypatch.setattr(socket.socket, "connect_ex", denied)
    monkeypatch.setattr(socket, "create_connection", denied)
    monkeypatch.setattr(socket, "getaddrinfo", denied)


@pytest.fixture
def ledger(tmp_path):
    return EvidenceLedger.create(
        tmp_path / "events.jsonl",
        episode_id="artificial-only",
        audit_limit=50,
        mode="artificial_fixture",
    )


def register(
    ledger,
    root="r1",
    contributor="u",
    context="email",
    batch="b1",
    *,
    records=1,
    at=0,
    attribution="authenticated_external",
    uploader="relay",
    kinds=None,
):
    origin = Provenance(
        root,
        context,
        batch,
        contributor,
        attribution,
        uploader,
        "user" if attribution == "principal" else None,
    )
    memories = tuple(
        StoredRecord(
            f"{root}-m{i}", digest([root, i]), (kinds or ["claim"] * records)[i], f"{root}-artifact"
        )
        for i in range(records)
    )
    ledger.append(Register(f"ingest-{root}", at, origin, memories))
    return origin, memories


def audit(
    root,
    records,
    verdict="unsafe",
    *,
    event="a1",
    at=1,
    use="describe",
    policy="v1",
    complete=True,
    supersedes=None,
    findings=None,
    **kwargs,
):
    if findings is None:
        findings = tuple(
            Finding(r.record_id, r.content_hash, verdict, "fixture://span") for r in records
        )
    return Audit(
        event,
        at,
        f"ticket-{event}",
        root,
        use,
        policy,
        verdict,
        tuple(findings),
        complete,
        "artificial-verifier",
        "artificial_fixture",
        "fixture://review",
        supersedes,
        **kwargs,
    )


def candidate(record, *, use="describe", policy="v1", acl=True, authority=True, score=0.8):
    return Candidate(record.record_id, record.content_hash, use, policy, score, acl, authority)


def test_equal_initialization_and_original_scores(ledger):
    _, a = register(ledger)
    _, b = register(ledger, "r2", "different")
    snap = ledger.snapshot()
    for arm in "RCMS":
        assert Policy(arm).decide(candidate(a[0]), snap).adjusted_score == 0.8
        assert Policy(arm).decide(candidate(b[0]), snap).penalty == 0
    assert snap.group("source", "u").risk == 0.5
    assert snap.usage.tickets == 0


def test_claims_chunks_and_copies_share_one_vote_but_spend_tickets(ledger):
    _, memories = register(ledger, records=6, kinds=["claim"] * 3 + ["evidence_chunk"] * 3)
    ledger.append(audit("r1", memories))
    # Known copies share the original root; matching text alone never creates an edge.
    copies = tuple(
        StoredRecord(f"copy-{i}", memories[0].content_hash, "claim", f"copy-art-{i}")
        for i in range(3)
    )
    ledger.append(Register("copies", 2, ledger.snapshot().roots["r1"], copies))
    ledger.append(audit("r1", copies, event="copy-review", at=3, complete=False))
    snap = ledger.snapshot()
    assert snap.group("source", "u").unsafe == 1
    assert snap.group("context", "u", "email").unsafe == 1
    assert snap.group("batch", "u", "email", "b1").unsafe == 1
    assert snap.usage.tickets == 2
    for record in (*memories, *copies):
        assert not Policy("R").decide(candidate(record), snap).eligible


def test_independent_equal_text_is_not_deduplicated(ledger):
    _, first = register(ledger)
    origin, _ = register(ledger, "r2")
    same_text = StoredRecord("independent", first[0].content_hash, "claim", "other-artifact")
    ledger.append(Register("independent-version", 0, origin, (same_text,)))
    ledger.append(audit("r1", first))
    ledger.append(audit("r2", (same_text,), event="a2", at=2, complete=False))
    assert ledger.snapshot().group("source", "u").unsafe == 2


def test_unsafe_bundle_does_not_label_every_child(ledger):
    _, memories = register(ledger, records=3, kinds=["claim", "claim", "evidence_chunk"])
    finding = (
        Finding(
            memories[0].record_id, memories[0].content_hash, "unsafe", "fixture://specific-span"
        ),
    )
    ledger.append(audit("r1", memories, complete=False, findings=finding))
    snap = ledger.snapshot()
    assert not Policy("R").decide(candidate(memories[0]), snap).eligible
    assert Policy("R").decide(candidate(memories[1]), snap).eligible
    assert (
        snap.local_status(memories[2].record_id, memories[2].content_hash, "describe", "v1")
        == "unreviewed"
    )


def test_local_unsafe_is_use_and_content_and_policy_specific(ledger):
    origin, old = register(ledger)
    repaired = replace(old[0], content_hash=digest("repaired"))
    ledger.append(Register("repair", 0, origin, (repaired,)))
    ledger.append(audit("r1", old, complete=False))
    snap = ledger.snapshot()
    assert not Policy("R").decide(candidate(old[0]), snap).eligible
    assert Policy("R").decide(candidate(old[0], use="other-use"), snap).eligible
    assert Policy("R").decide(candidate(old[0], policy="v2"), snap).eligible
    assert Policy("R").decide(candidate(repaired), snap).eligible


def test_unknown_origin_and_principal_never_damage_relay(ledger):
    _, unknown = register(ledger, contributor=None, attribution="unknown")
    _, principal = register(ledger, "principal", contributor=None, attribution="principal")
    _, relay = register(ledger, "relay-source", contributor="relay")
    ledger.append(audit("r1", unknown))
    ledger.append(audit("principal", principal, event="a2", at=2))
    snap = ledger.snapshot()
    assert snap.observations() == ()
    assert not Policy("R").decide(candidate(unknown[0]), snap).eligible
    assert not Policy("R").decide(candidate(principal[0]), snap).eligible
    assert Policy("M").decide(candidate(relay[0]), snap).penalty == 0


def test_authenticated_origin_not_innocent_uploader_receives_penalty(ledger):
    _, bad = register(ledger, contributor="culprit", uploader="innocent")
    _, innocent = register(ledger, "innocent", contributor="innocent")
    ledger.append(audit("r1", bad))
    snap = ledger.snapshot()
    assert snap.group("source", "culprit").unsafe == 1
    assert snap.group("source", "innocent").unsafe == 0
    assert Policy("M").decide(candidate(innocent[0]), snap).penalty == 0


def test_safe_other_use_cannot_erase_independent_unsafe(ledger):
    _, memories = register(ledger)
    ledger.append(audit("r1", memories))
    ledger.append(audit("r1", memories, "safe_for_use", event="safe", at=2, use="quotation"))
    snap = ledger.snapshot()
    assert snap.group("source", "u").unsafe == 1
    assert snap.group("source", "u").safe == 0
    assert not Policy("R").decide(candidate(memories[0]), snap).eligible
    assert Policy("R").decide(candidate(memories[0], use="quotation"), snap).eligible


def test_unresolved_is_spent_and_not_safe(ledger):
    _, memories = register(ledger)
    ledger.append(
        audit(
            "r1",
            memories,
            "unresolved",
            attempts=2,
            input_tokens=101,
            output_tokens=7,
            cost_microusd=42,
        )
    )
    snap = ledger.snapshot()
    assert snap.group("source", "u").safe == snap.group("source", "u").unsafe == 0
    assert snap.usage.tickets == 1 and snap.usage.attempts == 2
    assert snap.usage.input_tokens == 101 and snap.usage.cost_microusd == 42
    assert (
        snap.local_status(memories[0].record_id, memories[0].content_hash, "describe", "v1")
        == "unresolved"
    )


def test_incomplete_safe_bundle_rejected_but_partial_safe_exception_supported(ledger):
    _, memories = register(ledger, records=2)
    partial = audit("r1", memories[:1], "safe_for_use")
    before = ledger.path.read_bytes()
    with pytest.raises(LedgerError, match="cover all"):
        ledger.append(partial)
    assert ledger.path.read_bytes() == before
    ledger.append(replace(partial, outcome="unresolved", complete_bundle=False))
    snap = ledger.snapshot()
    assert snap.group("source", "u").safe == 0
    assert (
        snap.local_status(memories[0].record_id, memories[0].content_hash, "describe", "v1")
        == "safe_for_use"
    )


def test_idempotence_event_collision_and_ticket_reuse(ledger):
    _, memories = register(ledger)
    event = audit("r1", memories)
    assert ledger.append(event)
    before = ledger.path.read_bytes()
    assert ledger.append(event) is False
    assert ledger.path.read_bytes() == before
    with pytest.raises(LedgerError, match="Event ID reused"):
        ledger.append(replace(event, outcome="unresolved", findings=()))
    with pytest.raises(LedgerError, match="Ticket already consumed"):
        ledger.append(replace(event, event_id="different-event", revealed_at=2))
    assert ledger.snapshot().usage.tickets == 1


def test_false_accusation_correction_equals_correct_control_and_keeps_cost(ledger, tmp_path):
    _, memories = register(ledger)
    wrong = audit("r1", memories)
    ledger.append(wrong)
    prior = ledger.snapshot()
    ledger.append(audit("r1", memories, "safe_for_use", event="review", at=4, supersedes="a1"))
    corrected = ledger.snapshot()
    control = EvidenceLedger.create(
        tmp_path / "control", episode_id="control", audit_limit=50, mode="artificial_fixture"
    )
    register(control)
    control.append(
        replace(
            wrong,
            outcome="safe_for_use",
            findings=(replace(wrong.findings[0], verdict="safe_for_use"),),
        )
    )
    control.append(audit("r1", memories, "safe_for_use", event="review", at=4, supersedes="a1"))
    assert corrected.observations() == control.snapshot().observations()
    assert corrected.usage == control.snapshot().usage
    assert corrected.usage.tickets == 2 and corrected.group("source", "u").unsafe == 0
    assert corrected.group("source", "u").safe == 1
    for arm in "RCMS":
        assert Policy(arm).decide(candidate(memories[0]), corrected).eligible
        assert not Policy(arm).decide(candidate(memories[0]), prior).eligible


def test_retraction_rebuilds_counts_and_does_not_revive_superseded_claim(ledger):
    _, memories = register(ledger)
    ledger.append(audit("r1", memories))
    ledger.append(audit("r1", memories, "safe_for_use", event="review", at=2, supersedes="a1"))
    ledger.append(Retract("invalid-review", 3, "review", "fixture://invalid", "curator"))
    snap = ledger.snapshot()
    assert snap.observations() == ()
    assert snap.usage.tickets == 2
    assert (
        snap.local_status(memories[0].record_id, memories[0].content_hash, "describe", "v1")
        == "unreviewed"
    )
    with pytest.raises(LedgerError, match="active audit"):
        ledger.append(Retract("double", 4, "a1", "fixture://invalid", "curator"))


def test_safe_repair_keeps_true_historical_incident(ledger):
    origin, old = register(ledger)
    ledger.append(audit("r1", old))
    repaired = replace(old[0], content_hash=digest("new content"))
    ledger.append(Register("new-version", 2, origin, (repaired,)))
    partial_safe = audit(
        "r1",
        (repaired,),
        "unresolved",
        event="repair-review",
        at=3,
        complete=False,
        findings=(
            Finding(repaired.record_id, repaired.content_hash, "safe_for_use", "fixture://repair"),
        ),
    )
    with pytest.raises(LedgerError, match="historical incident"):
        ledger.append(replace(partial_safe, supersedes="a1"))
    ledger.append(partial_safe)
    snap = ledger.snapshot()
    assert snap.group("source", "u").unsafe == 1
    for arm in "RCMS":
        assert Policy(arm).decide(candidate(repaired), snap).eligible
        assert not Policy(arm).decide(candidate(old[0]), snap).eligible


def test_safe_without_supersession_does_not_clear_unsafe_for_same_use(ledger):
    _, memories = register(ledger)
    ledger.append(audit("r1", memories))
    ledger.append(audit("r1", memories, "safe_for_use", event="independent-safe", at=2))
    assert not Policy("R").decide(candidate(memories[0]), ledger.snapshot()).eligible
    assert ledger.snapshot().group("source", "u").unsafe == 1


def test_future_events_and_same_time_cursors_cannot_rewrite_predictions(ledger):
    _, memories = register(ledger)
    frozen = ledger.snapshot(as_of=3)
    ledger.append(audit("r1", memories, at=10))
    assert ledger.snapshot(as_of=9).usage.tickets == 0
    assert frozen.usage.tickets == 0
    assert Policy("R").decide(candidate(memories[0]), frozen).eligible
    assert not Policy("R").decide(candidate(memories[0]), ledger.snapshot()).eligible
    assert ledger.snapshot(as_of=10, cursor=frozen.cursor).usage.tickets == 0
    with pytest.raises(LedgerError, match="backdated"):
        ledger.append(Retract("backdate", 9, "a1", "fixture://invalid", "curator"))


def test_snapshot_restart_has_exact_cursor_and_no_automatic_future_replay(ledger, tmp_path):
    _, memories = register(ledger)
    ledger.append(audit("r1", memories))
    before = ledger.snapshot()
    path = tmp_path / "snapshot.json"
    before.save(path)
    correction = audit("r1", memories, "safe_for_use", event="correct", at=5, supersedes="a1")
    ledger.append(correction)
    assert EvidenceSnapshot.load(path) == before
    restarted = EvidenceLedger.restore(path, tmp_path / "resumed.jsonl")
    assert restarted.snapshot() == before
    for arm in "RCMS":
        assert Policy(arm).decide(candidate(memories[0]), restarted.snapshot()) == Policy(
            arm
        ).decide(candidate(memories[0]), before)
    restarted.append(correction)
    assert restarted.snapshot() == ledger.snapshot()
    assert EvidenceLedger(ledger.path).snapshot() == ledger.snapshot()
    with pytest.raises(FileExistsError):
        before.save(path)
    with pytest.raises(FileExistsError):
        EvidenceLedger.restore(path, restarted.path)


def test_snapshot_and_journal_tampering_fail_closed(ledger, tmp_path):
    _, memories = register(ledger)
    ledger.append(audit("r1", memories))
    path = tmp_path / "snapshot.json"
    ledger.snapshot().save(path)
    body = json.loads(path.read_text())
    body["events"][-1]["outcome"] = "safe_for_use"
    path.write_text(json.dumps(body))
    with pytest.raises(LedgerError, match="Corrupt snapshot"):
        EvidenceSnapshot.load(path)
    journal = ledger.path.read_bytes()
    ledger.path.write_bytes(journal[:-2])
    with pytest.raises(LedgerError, match="Truncated"):
        EvidenceLedger(ledger.path)
    ledger.path.write_bytes(journal.replace(b'"outcome":"unsafe"', b'"outcome":"unresolved"'))
    with pytest.raises(LedgerError, match="hash mismatch"):
        EvidenceLedger(ledger.path)


def test_stale_writer_is_rejected_without_lost_events(ledger):
    second = EvidenceLedger(ledger.path)
    _, memories = register(ledger)
    origin = Provenance("other", "email", "b1", "u", "authenticated_external")
    record = StoredRecord("other-m", digest("other"), "claim", "artifact")
    with pytest.raises(LedgerError, match="reload"):
        second.append(Register("stale", 0, origin, (record,)))
    ledger.append(audit("r1", memories))
    assert EvidenceLedger(ledger.path).snapshot().usage.tickets == 1


@pytest.mark.parametrize(
    "cap,usage,message",
    [
        ({"audit_limit": 0}, {}, "audit budget"),
        ({"audit_limit": 2, "token_limit": 3}, {"input_tokens": 4}, "token budget"),
        ({"audit_limit": 2, "cost_limit_microusd": 3}, {"cost_microusd": 4}, "dollar budget"),
    ],
)
def test_budget_rejection_is_atomic(tmp_path, cap, usage, message):
    book = EvidenceLedger.create(
        tmp_path / "limited", episode_id="limited", mode="artificial_fixture", **cap
    )
    _, memories = register(book)
    before = book.path.read_bytes()
    with pytest.raises(LedgerError, match=message):
        book.append(audit("r1", memories, **usage))
    assert book.path.read_bytes() == before and book.snapshot().usage.tickets == 0


def test_pending_case_labels_and_fixture_evidence_rejected_at_real_boundary(tmp_path, ledger):
    _, memories = register(ledger)
    body = json.loads(canonical(event_dict(audit("r1", memories))))
    for field in ("expected_memory", "Y_case", "source_split", "hidden_profile"):
        with pytest.raises(LedgerError, match="fields"):
            parse_event({**body, field: "must-not-reach-defense"})
    with pytest.raises(LedgerError, match="verdict"):
        parse_event({**body, "outcome": None})
    with pytest.raises(LedgerError, match="Unknown evidence event"):
        parse_event({"kind": "audit_request_pending", "verdict": None})
    real = EvidenceLedger.create(tmp_path / "real", episode_id="real", audit_limit=5)
    register(real)
    with pytest.raises(LedgerError, match="Fixture findings"):
        real.append(audit("r1", memories))


def test_conflicting_provenance_and_foreign_findings_rejected(ledger):
    origin, memories = register(ledger)
    _, foreign = register(ledger, "foreign")
    with pytest.raises(LedgerError, match="Conflicting trusted provenance"):
        ledger.append(
            Register("wrong-origin", 0, replace(origin, contributor_id="innocent"), memories)
        )
    with pytest.raises(LedgerError, match="registered version"):
        ledger.append(audit("r1", foreign))
    with pytest.raises(LedgerError, match="cannot change origin"):
        ledger.append(
            Register("record-reassignment", 0, ledger.snapshot().roots["foreign"], memories)
        )


def test_scope_gates_require_independent_roots_in_distinct_batches_and_contexts(ledger):
    specs = [
        ("a", "email", "b1"),
        ("a2", "email", "b1"),
        ("b", "email", "b2"),
        ("c", "file", "b1"),
        ("d", "file", "b2"),
    ]
    catalog = {r: register(ledger, r, context=c, batch=b)[1] for r, c, b in specs}
    target = ledger.snapshot().roots["a"]
    ledger.append(audit("a", catalog["a"]))
    assert ledger.snapshot().active_scopes(target) == ("batch",)
    ledger.append(audit("a2", catalog["a2"], event="a2", at=2))
    assert ledger.snapshot().active_scopes(target) == ("batch",)
    ledger.append(audit("b", catalog["b"], event="b", at=3))
    assert ledger.snapshot().active_scopes(target) == ("batch", "context")
    ledger.append(audit("c", catalog["c"], event="c", at=4))
    assert ledger.snapshot().active_scopes(target) == ("batch", "context")
    ledger.append(audit("d", catalog["d"], event="d", at=5))
    assert ledger.snapshot().active_scopes(target) == ("batch", "context", "source")
    ledger.append(Retract("retract-d", 6, "d", "fixture://invalid", "curator"))
    assert ledger.snapshot().active_scopes(target) == ("batch", "context")
    ledger.append(Retract("retract-b", 7, "b", "fixture://invalid", "curator"))
    assert ledger.snapshot().active_scopes(target) == ("batch",)


def test_contextual_vs_multiscope_vs_selective_is_same_metadata_comparison(ledger):
    _, bad = register(ledger)
    _, same_batch = register(ledger, "same-batch")
    _, other_batch = register(ledger, "other-batch", batch="b2")
    _, other_context = register(ledger, "other-context", context="file")
    _, unrelated = register(ledger, "unrelated", contributor="peer")
    ledger.append(audit("r1", bad))
    snap = ledger.snapshot()
    # One unsafe observation: d=1/6, score penalty=1/12; no .25 gate yet.
    assert Policy("R").decide(candidate(same_batch[0]), snap).penalty == 0
    assert Policy("C").decide(candidate(other_batch[0]), snap).penalty == pytest.approx(1 / 6)
    assert Policy("M").decide(candidate(other_context[0]), snap).penalty == pytest.approx(1 / 6)
    assert Policy("S").decide(candidate(same_batch[0]), snap).adjusted_score == pytest.approx(
        0.8 - 1 / 12
    )
    assert Policy("S").decide(candidate(other_batch[0]), snap).penalty == 0
    assert Policy("S").decide(candidate(other_context[0]), snap).penalty == 0
    for arm in "RCMS":
        assert Policy(arm).decide(candidate(unrelated[0]), snap).penalty == 0
        assert Policy(arm).decide(candidate(other_batch[0]), snap).consumed_tickets == 1
    # Decisions do not create any new evidence or votes.
    assert ledger.snapshot() == snap


def test_inclusive_gate_ranking_only_and_verified_safe_override(ledger):
    _, a = register(ledger, "a")
    _, b = register(ledger, "b", batch="b2")
    _, target = register(ledger, "target", batch="b3")
    ledger.append(audit("a", a))
    ledger.append(audit("b", b, event="b", at=2))
    snap = ledger.snapshot()
    for arm in "CMS":
        decision = Policy(arm).decide(candidate(target[0]), snap)
        assert decision.penalty == 0.25 and not decision.eligible
        assert decision.adjusted_score is None and decision.reason == "source_risk_gate"
        rank_only = Policy(arm, threshold=None).decide(candidate(target[0]), snap)
        assert rank_only.eligible and rank_only.adjusted_score == pytest.approx(0.675)
    # A complete safe audit is not necessary for an explicit record/use safe exception.
    safe = Finding(target[0].record_id, target[0].content_hash, "safe_for_use", "fixture://safe")
    ledger.append(
        audit(
            "target",
            target,
            "unresolved",
            event="target-safe",
            at=3,
            complete=False,
            findings=(safe,),
        )
    )
    for arm in "RCMS":
        safe_decision = Policy(arm).decide(candidate(target[0]), ledger.snapshot())
        assert safe_decision.eligible and safe_decision.penalty == 0
        assert safe_decision.reason == "verified_safe_for_use"
        assert not Policy(arm).decide(candidate(target[0], acl=False), ledger.snapshot()).eligible
        assert (
            not Policy(arm)
            .decide(candidate(target[0], authority=False), ledger.snapshot())
            .eligible
        )
        if arm != "R":
            assert (
                Policy(arm).decide(candidate(target[0], use="different"), ledger.snapshot()).reason
                == "source_risk_gate"
            )


def test_recent_benign_history_does_not_bypass_direct_compromise_containment(ledger):
    safe_records = [register(ledger, f"old-{i}")[1] for i in range(8)]
    _, new = register(ledger, "compromised", batch="new")
    for i, records in enumerate(safe_records):
        ledger.append(audit(f"old-{i}", records, "safe_for_use", event=f"safe-{i}", at=i + 1))
    ledger.append(audit("compromised", new, event="caught", at=10))
    snap = ledger.snapshot()
    assert snap.group("source", "u").penalty == 0
    for arm in "RCMS":
        assert not Policy(arm).decide(candidate(new[0]), snap).eligible
        assert Policy(arm).decide(candidate(safe_records[0][0]), snap).eligible


def test_policy_and_evidence_versions_are_recorded_without_evaluator_fields(ledger):
    _, records = register(ledger)
    snap = ledger.snapshot()
    decision = Policy("S").decide(candidate(records[0]), snap)
    body = asdict(decision)
    assert body["evidence_revision"] == snap.revision
    assert body["evidence_cursor"] == snap.cursor
    assert body["policy_hash"] != Policy("S", threshold=None).fingerprint
    assert "expected_memory" not in body and "Y_case" not in body
    assert body["local_status"] == "unreviewed"
    with pytest.raises(TypeError):
        snap.roots["r1"] = replace(snap.roots["r1"], contributor_id="other")
    with pytest.raises(LedgerError, match="Unknown/unavailable"):
        Policy("S").decide(
            replace(candidate(records[0]), content_hash=digest("not available")), snap
        )


def test_global_gate_with_exactly_four_roots_and_context_boundary(ledger):
    specs = (("a", "email", "b1"), ("b", "email", "b2"), ("c", "file", "b1"), ("d", "file", "b2"))
    known = {r: register(ledger, r, context=c, batch=b)[1] for r, c, b in specs}
    _, future_context = register(ledger, "target", context="third-context")
    for i, (root, _, _) in enumerate(specs, 1):
        ledger.append(audit(root, known[root], event=f"audit-{i}", at=i))
    snap = ledger.snapshot()
    target = candidate(future_context[0])
    assert snap.active_scopes(snap.roots["target"]) == ("source",)
    assert Policy("C").decide(target, snap).penalty == 0
    assert Policy("M").decide(target, snap).penalty == pytest.approx(1 / 3)
    assert Policy("S").decide(target, snap).penalty == pytest.approx(1 / 3)


def test_mixed_findings_preserve_reviewed_clean_child(ledger):
    _, records = register(ledger, records=2, kinds=["claim", "evidence_chunk"])
    findings = (
        Finding(records[0].record_id, records[0].content_hash, "unsafe", "fixture://bad"),
        Finding(
            records[1].record_id, records[1].content_hash, "safe_for_use", "fixture://clean-span"
        ),
    )
    ledger.append(audit("r1", records, findings=findings))
    for arm in "RCMS":
        assert not Policy(arm).decide(candidate(records[0]), ledger.snapshot()).eligible
        assert Policy(arm).decide(candidate(records[1]), ledger.snapshot()).eligible
    assert ledger.snapshot().group("source", "u").unsafe == 1


def test_correction_cannot_erase_unrelated_use_or_origin(ledger):
    _, records = register(ledger)
    ledger.append(audit("r1", records))
    for changes in ({"use_id": "another"}, {"policy_version": "v2"}):
        bad = replace(
            audit("r1", records, "safe_for_use", event="review", at=2, supersedes="a1"), **changes
        )
        with pytest.raises(LedgerError, match="another origin/use/policy"):
            ledger.append(bad)
    assert ledger.snapshot().usage.tickets == 1


def test_example_is_repeatable_and_refuses_overwrite(tmp_path):
    from ams.research.dynamic.fixture import write_example

    a, b = tmp_path / "a", tmp_path / "b"
    result = write_example(a)
    assert result == write_example(b)
    assert result["model_requests"] == result["genuine_human_reviews_created"] == 0
    assert result["final_usage_per_policy"]["tickets"] == 5
    assert result["policy_decisions"] == 432
    for p in a.iterdir():
        assert p.read_bytes() == (b / p.name).read_bytes()
    rows = [json.loads(line) for line in (a / "decisions.jsonl").read_text().splitlines()]
    final = [row for row in rows if row["stage"] == "after-5"]
    assert {row["consumed_tickets"] for row in final} == {5}
    assert {row["evidence_revision"] for row in final} == {result["checkpoints"][-1]["revision"]}
    with pytest.raises(LedgerError, match="overwrite"):
        write_example(a)


def test_package_imports_no_model_clients_or_evaluator():
    import ast
    from pathlib import Path

    package = Path(__file__).resolve().parents[1] / "src/ams/research/dynamic"
    imports = []
    for path in package.glob("*.py"):
        for node in ast.walk(ast.parse(path.read_text())):
            if isinstance(node, ast.Import):
                imports.extend(alias.name for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                imports.append(node.module)
    assert not any(
        name.startswith(
            (
                "ams.llm",
                "ams.eval",
                "ams.data",
                "openai",
                "sentence_transformers",
                "transformers",
                "requests",
            )
        )
        for name in imports
    )


@pytest.mark.parametrize(
    "change",
    [
        {"outcome": "pending"},
        {"verification_basis": "target_judge"},
        {"verification_basis": "detector_warning"},
        {"attempts": 3},
        {"input_tokens": -1},
        {"complete_bundle": "true"},
        {"revealed_at": True},
    ],
)
def test_invalid_audits_fail_closed(ledger, change):
    _, records = register(ledger)
    with pytest.raises(LedgerError):
        replace(audit("r1", records), **change)
