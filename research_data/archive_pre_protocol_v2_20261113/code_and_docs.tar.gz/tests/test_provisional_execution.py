"""Invented fixtures only. No genuine reviews, API calls or measured outcomes."""

import copy
import json
import sqlite3

import pytest

from ams.research import provisional_execution as p
from ams.research.dynamic.models import LedgerError, digest
from ams.research.execution.session import ExecutionSession, new_json
from ams.research.provisional.episodes import recode
from ams.research.recovery.offline import sha_file
from ams.research.sequential.state import RuntimeState
from test_dynamic_native import build as build_native
from test_dynamic_native import example, offline  # noqa: F401
from test_mpbench_provisional import episode


def pricing():
    return {
        "schema": "dynamic-pricing-observation-v1",
        "provider": "openrouter",
        "model": "openai/gpt-4o-mini",
        "currency": "USD",
        "input_usd_per_million": "0.15",
        "output_usd_per_million": "0.60",
        "checked_on": "2026-11-01",
        "model_page": "https://openrouter.ai/openai/gpt-4o-mini",
    }


def cell(scenario="strong_localized"):
    value, pool = episode(scenario)
    public = {k: value[k] for k in ["overlay", "events", "shared_arm_inputs", "status"]}
    row = {
        "episode_token": "ep_fixture_" + scenario,
        "bag_id": "D00",
        "scenario": scenario,
        "shared_arm_inputs": public["shared_arm_inputs"],
    }
    order = [e["contribution_id"] for e in public["events"] if e["event"] == "ingest"]
    return row, public, value["private"], pool, order


def contract(scenario="strong_localized"):
    return p.cell_contract(*cell(scenario), "a" * 64)


def test_native_exact_crosswalk_and_query_catalog_without_retrieval(example):  # noqa: F811
    snapshot, crosswalk = build_native(example)
    state = RuntimeState.load(snapshot)
    key = bytes(range(32))
    source = example["source"]
    pid = recode(source["contribution_id"], key)
    pool = {
        pid: {
            **recode(source, key),
            "records": [
                {
                    **{k: r[k] for k in ["record_id", "content_hash", "text"]},
                    "record_kind": "claim" if kind == "claims" else "evidence_chunk",
                }
                for kind in ["claims", "chunks"]
                for r in example[kind]
            ],
        }
    }
    for record in pool[pid]["records"]:
        record["record_id"] = recode(record["record_id"], key)
    result = p.check_store(state, crosswalk, pool, key)
    assert result["claims"] == result["chunks"] == 3 and result["audit_tickets_consumed"] == 0
    assert result["unknown_external_roots"] == 1 and result["human_verified_memory_labels"] == 0
    check = p.query_coverage(state, [example["query"]])
    assert check["classifier_misses"] == check["embedding_misses"] == 0
    assert all(not c.history for c in state.clients)
    with pytest.raises(LedgerError, match="classifier"):
        p.query_coverage(state, ["Missing fixture query"])
    assert all(not c.history for c in state.clients)
    pool[pid]["records"][0]["text"] += " changed"
    with pytest.raises(LedgerError, match="mismatch"):
        p.check_store(state, crosswalk, pool, key)


def test_same_inputs_pending_audits_and_diagnostic_static_contract():
    runtime, evaluator = contract()
    assert set(runtime["arms"]) == set(p.ARMS)
    assert len(runtime["queries"]) == 27 and len(runtime["audit_requests"]) == 5
    assert {a["initial_snapshot_sha256"] for a in runtime["arms"].values()} == {"a" * 64}
    assert {a["input_schedule_hash"] for a in runtime["arms"].values()} == {
        next(iter(runtime["arms"].values()))["input_schedule_hash"]
    }
    assert all(
        a["audit_ticket_limit"] == a["scheduled_audit_opportunities"] == 5
        for a in runtime["arms"].values()
    )
    assert runtime["arms"]["static"]["effects_enabled"] is False
    assert runtime["arms"]["static"]["consumes_revealed_audits"] is False
    assert all(runtime["arms"][a]["consumes_revealed_audits"] for a in "RCMS")
    assert all(a["verdict"] is None for a in runtime["audit_requests"])
    assert "PRIVATE TARGET" not in json.dumps(runtime)
    assert evaluator["memory_safety_label_basis"] == "unknown"
    assert sum(evaluator["metric_counts"].values()) == 27
    assert runtime["execution_enabled"] is False


@pytest.mark.parametrize("mutation", ["order", "arm", "audit", "gold"])
def test_changed_order_inputs_or_labels_do_not_become_a_qualified_plan(mutation):
    row, public, private, pool, order = cell()
    if mutation == "order":
        order.reverse()
    elif mutation == "arm":
        row["shared_arm_inputs"]["S"] = "b" * 64
    elif mutation == "audit":
        next(e for e in public["events"] if e["event"] == "audit_request_pending")["verdict"] = (
            "unsafe"
        )
    else:
        next(iter(private["case_targets"].values()))["Y_case"] = "unsafe"
    with pytest.raises(ValueError):
        p.cell_contract(row, public, private, pool, order, "a" * 64)


def test_costs_use_actual_probes_include_static_and_do_not_treat_verification_as_free():
    cells = [contract(s) for s in p.REGIMES]
    budget = {"remaining_usd": "28.00465620", "total_limit_usd": "30.00"}
    costs = p.cost_estimate(cells, [], pricing(), budget)
    counts = costs["exact_scheduled_counts"]
    assert counts["memory_answers"] == 405
    assert counts["scheduled_audit_tickets_each_RCMS"] == 15
    assert counts["scheduled_audit_tickets_all_RCMS"] == 60
    assert counts["shared_pending_audit_jobs"] == 15 and counts["static_completed_audits"] == 0
    assert counts["no_memory_answers"] == len(
        {t["contribution_id"] for _, c in cells for t in c["targets"].values()}
    )
    assert counts["answer_judgments"] == 405 + counts["no_memory_answers"]
    assert costs["audit_verifier_inference_cost_usd"] is None
    assert costs["unknown_audit_cost_is_not_zero"] is True
    assert costs["paid_execution_enabled"] is False and costs["cache_discount_assumed"] is False
    assert costs["physical_attempts_each"] == 1 and costs["automatic_retries"] == 0
    high = copy.deepcopy(pricing())
    high["input_usd_per_million"] = "1"
    with pytest.raises(LedgerError, match="price exceeds"):
        p.cost_estimate(cells, [], high, budget)
    poor = p.cost_estimate(cells, [], pricing(), {"remaining_usd": "0.001"})
    assert poor["scenarios"]["working"]["fits_remaining_allowance_on_assumptions"] is False


def test_budget_reuses_readonly_shared_session_without_resetting_spend(tmp_path):
    directory = tmp_path / "session"
    with ExecutionSession.create(directory, plan_hash="fixture"):
        pass
    with sqlite3.connect(directory / "budget.sqlite") as db:
        db.execute("UPDATE budget_config SET used_nanodollars='1995343800'")
    files = [directory / n for n in ["session.json", "budget.sqlite", "dispatch.sqlite"]]
    before = {str(n): sha_file(n) for n in files}
    result = p.budget_snapshot(directory)
    assert result["used_usd"] == "1.9953438" and result["remaining_usd"] == "28.0046562"
    assert result["new_allowance_created"] is False
    assert before == {str(n): sha_file(n) for n in files}
    with sqlite3.connect(directory / "budget.sqlite") as db:
        db.execute("UPDATE budget_config SET held_nanodollars='10'")
    with pytest.raises(LedgerError, match="Unsettled"):
        p.budget_snapshot(directory)


def publish_fixture(tmp_path):
    root = tmp_path / "plan"
    root.mkdir()
    (root / "public").mkdir()
    (root / "private").mkdir()
    runtime, evaluator = contract()
    new_json(root / "public/cell.json", runtime)
    new_json(root / "private/cell.json", evaluator)
    new_json(
        root / "preparation_report.json",
        {
            "human_verified_memory_labels": 0,
            "human_validated_questions": 0,
            "new_audit_verdicts": 0,
            "paid_execution_enabled": False,
        },
    )
    files = {str(n.relative_to(root)): sha_file(n) for n in root.rglob("*.json")}
    new_json(
        root / "manifest.json",
        {
            "schema": p.SCHEMA,
            "files": files,
            "hash": digest(files),
            "dependencies": {},
            "execution_enabled": False,
            "human_validation_deferred": True,
        },
    )
    return root


@pytest.mark.parametrize("mutation", ["budget", "query", "verdict", "enable", "leak"])
def test_plan_verifier_rejects_rehashed_contract_changes(tmp_path, mutation):
    root = publish_fixture(tmp_path)
    assert p.verify(root)["status"] == "passed"
    path = root / "public/cell.json"
    value = json.loads(path.read_text())
    if mutation == "budget":
        value["arms"]["S"]["audit_ticket_limit"] = 6
    elif mutation == "query":
        value["queries"][0]["text"] += " edited"
    elif mutation == "verdict":
        value["audit_requests"][0]["verdict"] = "unsafe"
    elif mutation == "enable":
        value["execution_enabled"] = True
    else:
        value["expected_memory"] = "leaked target"
    path.write_text(json.dumps(value))
    m = json.loads((root / "manifest.json").read_text())
    m["files"]["public/cell.json"] = sha_file(path)
    m["hash"] = digest(m["files"])
    (root / "manifest.json").write_text(json.dumps(m))
    with pytest.raises(ValueError):
        p.verify(root)


def test_existing_output_is_never_overwritten(tmp_path):
    with pytest.raises(LedgerError, match="overwrite"):
        p.prepare(tmp_path, tmp_path, tmp_path, tmp_path, tmp_path, tmp_path)


def test_missing_embedding_and_changed_source_span_fail_without_inference(example):  # noqa: F811
    snapshot, crosswalk = build_native(example)
    state = RuntimeState.load(snapshot)
    state.memory.embed_client.embeddings.clear()
    with pytest.raises(LedgerError, match="query embedding"):
        p.query_coverage(state, [example["query"]])
    assert all(not client.history for client in state.clients)

    state = RuntimeState.load(snapshot)
    source = example["source"]
    key = bytes(range(32))
    pid = source["contribution_id"]
    pool = {
        pid: {
            **recode(source, key),
            "records": [
                {
                    **{k: r[k] for k in ["record_id", "content_hash", "text"]},
                    "record_kind": "claim" if kind == "claims" else "evidence_chunk",
                }
                for kind in ["claims", "chunks"]
                for r in example[kind]
            ],
        }
    }
    next(iter(crosswalk["source_spans"].values()))["quote"] += " altered"
    with pytest.raises(LedgerError, match="source span"):
        p.check_store(state, crosswalk, pool, key)


def test_changed_budget_dependency_invalidates_the_old_plan(tmp_path):
    root = publish_fixture(tmp_path)
    dependency = tmp_path / "old_budget_snapshot.json"
    dependency.write_text('{"used":"1.00"}')
    manifest = json.loads((root / "manifest.json").read_text())
    manifest["dependencies"] = {str(dependency): sha_file(dependency)}
    (root / "manifest.json").write_text(json.dumps(manifest))
    assert p.verify(root)["status"] == "passed"
    dependency.write_text('{"used":"2.00"}')
    with pytest.raises(LedgerError, match="dependency changed"):
        p.verify(root)
