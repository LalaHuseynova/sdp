"""Offline launch-scope and original-request canary checks; no paid calls."""

from __future__ import annotations

import contextlib
import io
import json
import os
import random
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import httpx
import yaml
from openai import OpenAI

from ams.core.prompts import PromptLibrary
from ams.data.mpbench import load_mpbench
from ams.llm import ChatResponse, ManagedClient, ResponseCache
from ams.llm.budget import BudgetAccountingError, BudgetGuard
from ams.llm.providers.openai_client import OpenAIClient as RealOpenAIClient
from ams.memory.typed import classify_retention_sentences

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import prepare_full_mpbench as prepare  # noqa: E402 - repository experiment entry point
import run_full_mpbench as runner  # noqa: E402 - repository experiment entry point

MODEL = "openai/gpt-4o-mini"


class RecordingClient:
    provider = "openrouter"

    def __init__(self, inner=None):
        self.inner = inner
        self.requests = []

    def complete(self, request):
        self.requests.append(request)
        if self.inner is not None:
            return self.inner.complete(request)
        return ChatResponse('{"sentences":[]}', request.model, self.provider)


class SafeMemOnlyLauncherTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cases, _ = load_mpbench(ROOT / "data/mpbench")

    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)
        environment = patch.dict(os.environ, {"OPENROUTER_API_KEY": "offline-test-key"}, clear=True)
        environment.start()
        self.addCleanup(environment.stop)
        blocked = patch(
            "socket.socket.connect", side_effect=AssertionError("External network forbidden")
        )
        blocked.start()
        self.addCleanup(blocked.stop)

    def plan(self, methods=("safe_mem",)):
        jobs = prepare.build_jobs(["4omini"], list(methods))
        for job in jobs:
            path = self.directory / (job["method"] + ".yaml")
            path.write_text(yaml.safe_dump(job["config"]))
            job.update(
                config_path=str(path),
                config_sha256=prepare.sha256(path),
                command=["never-execute", "--require-full", "--yes"],
            )
        official = json.loads((ROOT / "reports/mpbench_official_byte_validation.json").read_text())
        plan = {
            "repository": str(ROOT),
            "source_sha256": {},
            "dataset": {
                "counts": {
                    "ingestions": 6240,
                    "attack_ingestions": 3241,
                    "attack_reads": 2999,
                    "benign_reads": 2997,
                },
                "official_validation": official,
            },
            "jobs": jobs,
            "cache_path": str(self.directory / "responses.sqlite"),
            "results_root": str(self.directory / "temporary-outputs"),
        }
        path = self.directory / "plan.json"
        path.write_text(json.dumps(plan))
        return plan, path

    def test_no_execute_means_no_credentials_provider_check_or_process(self):
        _, path = self.plan()
        with (
            patch.object(runner, "load_env", side_effect=AssertionError("credential access")),
            patch.object(runner, "current_key_budget", side_effect=AssertionError("provider GET")),
            patch.object(runner, "billing_preflight", side_effect=AssertionError("canary")),
            patch.object(runner.subprocess, "Popen", side_effect=AssertionError("process launch")),
            contextlib.redirect_stdout(io.StringIO()),
        ):
            self.assertEqual(runner.main(["--plan", str(path)]), 0)

    def test_execution_still_requires_finite_positive_approval(self):
        _, path = self.plan()
        for budget in (None, "NaN", "Infinity", "-Infinity", "0", "-1"):
            arguments = ["--plan", str(path), "--execute"]
            if budget is not None:
                arguments.append(f"--approved-budget-usd={budget}")
            with (
                self.subTest(budget=budget),
                patch.object(runner, "load_env", side_effect=AssertionError("credentials")),
                patch.object(runner, "current_key_budget", side_effect=AssertionError("provider")),
                contextlib.redirect_stdout(io.StringIO()),
                contextlib.redirect_stderr(io.StringIO()),
                self.assertRaises(SystemExit) as raised,
            ):
                runner.main(arguments)
            self.assertEqual(raised.exception.code, 2)

    def test_invalid_maximum_or_three_dollar_margin_rejected_before_provider_and_sdk(self):
        _, path = self.plan()
        pairs = (
            ("30", "28"),
            ("31", "27"),
            ("29", "27"),
            ("30", "27.000001"),
            ("30", "NaN"),
            ("30", "Infinity"),
            ("30", "-1"),
            ("30", "0"),
        )
        for maximum, stop in pairs:
            with (
                self.subTest(maximum=maximum, stop=stop),
                patch.object(runner, "load_env"),
                patch.object(runner, "current_key_budget", side_effect=AssertionError("provider")),
                patch.object(runner, "billing_preflight", side_effect=AssertionError("canary")),
                patch.object(runner.subprocess, "Popen", side_effect=AssertionError("process")),
                contextlib.redirect_stdout(io.StringIO()),
                contextlib.redirect_stderr(io.StringIO()),
                self.assertRaises(SystemExit) as raised,
            ):
                runner.main(
                    [
                        "--plan",
                        str(path),
                        "--execute",
                        f"--approved-budget-usd={maximum}",
                        f"--stop-at-usd={stop}",
                    ]
                )
            self.assertEqual(raised.exception.code, 2)

    def test_simple_memory_is_not_in_the_latest_paid_scope(self):
        _, path = self.plan(("safe_mem", "no_defence"))
        for selection in ("4omini/no_defence", "4omini/safe_mem,4omini/no_defence"):
            with (
                self.subTest(selection=selection),
                patch.object(runner, "load_env"),
                patch.object(runner, "current_key_budget", side_effect=AssertionError("provider")),
                patch.object(runner, "billing_preflight", side_effect=AssertionError("canary")),
                contextlib.redirect_stdout(io.StringIO()),
                contextlib.redirect_stderr(io.StringIO()),
                self.assertRaises(SystemExit) as raised,
            ):
                runner.main(
                    [
                        "--plan",
                        str(path),
                        "--jobs",
                        selection,
                        "--execute",
                        "--approved-budget-usd",
                        "30",
                        "--stop-at-usd",
                        "27",
                    ]
                )
            self.assertEqual(raised.exception.code, 2)

    def test_existing_uncapped_key_is_allowed_and_27_allowance_is_persisted(self):
        plan, path = self.plan()
        ordinary_key = {
            "limit": None,
            "limit_remaining": None,
            "limit_reset": None,
            "usage": 0.1,
            "is_management_key": False,
        }
        with (
            patch.object(runner, "load_env"),
            patch.object(runner, "current_key_budget", return_value=ordinary_key) as key_check,
            patch.object(runner, "billing_preflight", return_value={"status": "offline-mock"}),
            patch.object(runner, "run_job", return_value=(17, "offline-test-stop")) as run,
            patch.object(runner.subprocess, "Popen", side_effect=AssertionError("process")),
            contextlib.redirect_stdout(io.StringIO()),
        ):
            result = runner.main(
                [
                    "--plan",
                    str(path),
                    "--execute",
                    "--approved-budget-usd",
                    "30",
                    "--stop-at-usd",
                    "27",
                    "--approval-note",
                    "Offline unit-test fixture",
                ]
            )
        self.assertEqual(result, 17)
        key_check.assert_called_once_with("offline-test-key")
        run.assert_called_once()
        self.assertEqual(run.call_args.args[4], 27)
        guard_path = Path(run.call_args.kwargs["strict_budget_path"])
        guard = BudgetGuard(guard_path, 27)
        self.assertEqual(guard.snapshot()["limit_usd"], 27)
        record = json.loads(next(Path(plan["results_root"]).glob("*/execution.json")).read_text())
        self.assertFalse(record["account_limit_required"])
        self.assertEqual(record["software_stop_usd"], 27)
        self.assertEqual(record["approved_budget_usd"], 30)
        self.assertEqual(set(record["jobs"]), {"4omini/safe_mem"})
        self.assertEqual(record["jobs"]["4omini/safe_mem"]["status"], "incomplete")

    def mock_adapter_factory(self, guard, *, cost="0.000021", content='{"sentences":[]}'):
        bodies = []

        def handler(request):
            bodies.append(json.loads(request.content))
            self.assertEqual(guard.snapshot()["counts"]["pending"], 1)
            usage = {"prompt_tokens": 100, "completion_tokens": 10, "total_tokens": 110}
            if cost is not None:
                usage["cost"] = cost
            return httpx.Response(
                200,
                json={
                    "id": "gen-offline-retention",
                    "object": "chat.completion",
                    "created": 1,
                    "model": MODEL,
                    "choices": [
                        {
                            "index": 0,
                            "finish_reason": "stop",
                            "message": {"role": "assistant", "content": content},
                        }
                    ],
                    "usage": usage,
                },
            )

        sdk = OpenAI(
            api_key="offline-test-key",
            base_url="https://openrouter.ai/api/v1",
            max_retries=4,
            http_client=httpx.Client(transport=httpx.MockTransport(handler)),
        )
        self.addCleanup(sdk.close)
        raw = RealOpenAIClient(provider="openrouter", sdk_client=sdk, budget_guard=guard)
        self.addCleanup(raw._client.close)
        recorded = RecordingClient(raw)

        def factory(**kwargs):
            self.assertIs(kwargs["budget_guard"], guard)
            self.assertEqual(kwargs["provider"], "openrouter")
            return recorded

        return factory, recorded, bodies

    def test_canary_is_exact_original_first_seeded_request_and_bulk_reuses_cache(self):
        plan, _ = self.plan()
        guard = BudgetGuard(self.directory / "budget.sqlite", 27)
        factory, recorded, bodies = self.mock_adapter_factory(guard)
        root = self.directory / "canary-artifacts"
        root.mkdir()
        with patch("ams.llm.providers.openai_client.OpenAIClient", side_effect=factory):
            report = runner.billing_preflight(plan, self.cases, guard, root)
        order = list(self.cases)
        random.Random(plan["jobs"][0]["config"].get("seed", 0)).shuffle(order)
        first = order[0]
        original = RecordingClient()
        classify_retention_sentences(original, MODEL, PromptLibrary(), first.user_query)
        self.assertEqual(len(recorded.requests), 1)
        self.assertEqual(
            recorded.requests[0].cache_payload("openrouter"),
            original.requests[0].cache_payload("openrouter"),
        )
        self.assertEqual(report["cid"], first.cid)
        self.assertEqual(report["status"], "passed_live")
        self.assertFalse(report["cached"])
        self.assertAlmostEqual(report["reported_cost_usd"], 0.000021)
        self.assertEqual(len(bodies), 1)
        before_bulk = guard.snapshot()
        cache = ResponseCache(plan["cache_path"])
        try:
            bulk = ManagedClient(recorded, cache=cache)
            labels = classify_retention_sentences(bulk, MODEL, PromptLibrary(), first.user_query)
        finally:
            cache.close()
        self.assertTrue(labels)
        self.assertEqual(len(bodies), 1, "the bulk request must be a zero-new-HTTP cache hit")
        self.assertEqual(guard.snapshot(), before_bulk)
        self.assertEqual(before_bulk["counts"]["settled"], 1)
        self.assertEqual(before_bulk["held_nanodollars"], 0)
        self.assertEqual(before_bulk["used_nanodollars"], 21_000)
        with sqlite3.connect(guard.path) as conn:
            metadata = json.loads(conn.execute("SELECT metadata FROM reservations").fetchone()[0])
        self.assertEqual(metadata["generation_id"], "gen-offline-retention")
        self.assertEqual(metadata["model"], MODEL)
        self.assertEqual(metadata["input_tokens"], 100)
        self.assertEqual(metadata["output_tokens"], 10)
        self.assertFalse((root / "mpbench_summary.json").exists())
        with patch("ams.llm.providers.openai_client.OpenAIClient", side_effect=factory):
            replay = runner.billing_preflight(plan, self.cases, guard, root)
        self.assertEqual(replay["status"], "passed_cached_replay")
        self.assertTrue(replay["cached"])
        self.assertEqual(len(bodies), 1)
        self.assertEqual(guard.snapshot(), before_bulk)

    def test_unverified_imported_cache_does_not_count_as_live_billing_verification(self):
        plan, _ = self.plan()
        guard = BudgetGuard(self.directory / "fresh-budget.sqlite", 27)
        order = list(self.cases)
        random.Random(plan["jobs"][0]["config"].get("seed", 0)).shuffle(order)
        original = RecordingClient()
        classify_retention_sentences(original, MODEL, PromptLibrary(), order[0].user_query)
        cache = ResponseCache(plan["cache_path"])
        try:
            cache.put(
                original.requests[0].cache_key("openrouter"),
                provider="openrouter",
                model=MODEL,
                kind="chat",
                payload={
                    "text": '{"sentences":[]}',
                    "model": MODEL,
                    "provider": "openrouter",
                    "usage": {"input_tokens": 100, "output_tokens": 10, "cost_usd": 0.000021},
                    "raw_finish_reason": "stop",
                },
            )
        finally:
            cache.close()
        factory, _, bodies = self.mock_adapter_factory(guard)
        root = self.directory / "unverified-cache-artifacts"
        root.mkdir()
        with patch("ams.llm.providers.openai_client.OpenAIClient", side_effect=factory):
            with self.assertRaisesRegex(RuntimeError, "cached response alone"):
                runner.billing_preflight(plan, self.cases, guard, root)
        self.assertEqual(bodies, [])
        self.assertEqual(guard.snapshot()["counts"]["total"], 0)
        self.assertFalse((root / "billing_preflight.json").exists())

    def test_unverified_canary_cost_halts_without_bulk_or_passed_report(self):
        for index, cost in enumerate((None, "NaN", "-0.1")):
            with self.subTest(cost=cost):
                plan, _ = self.plan()
                plan["cache_path"] = str(self.directory / f"bad-cache-{index}.sqlite")
                guard = BudgetGuard(self.directory / f"bad-budget-{index}.sqlite", 27)
                factory, _, bodies = self.mock_adapter_factory(guard, cost=cost)
                root = self.directory / f"bad-canary-{index}"
                root.mkdir()
                with patch("ams.llm.providers.openai_client.OpenAIClient", side_effect=factory):
                    with self.assertRaises(BudgetAccountingError):
                        runner.billing_preflight(plan, self.cases, guard, root)
                self.assertEqual(len(bodies), 1)
                self.assertTrue(guard.snapshot()["blocked"])
                self.assertEqual(guard.snapshot()["counts"]["unknown"], 1)
                self.assertFalse((root / "billing_preflight.json").exists())

    def test_original_memory_governance_baseline_and_prompt_sources_remain_unchanged(self):
        integrity = prepare.original_method_integrity()
        self.assertTrue(integrity["all_original"], integrity["changed_files"])
        self.assertGreaterEqual(integrity["files_compared"], 60)


if __name__ == "__main__":
    unittest.main()
