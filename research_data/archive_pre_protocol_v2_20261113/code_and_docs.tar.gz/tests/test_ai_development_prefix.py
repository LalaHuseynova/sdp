"""Offline aggregation keeps failed versions and never chooses favorable labels."""

import importlib.util
import json
from pathlib import Path

import pytest

from ams.research.dynamic.models import LedgerError, digest
from ams.research.recovery.offline import sha_file


def controller():
    spec = importlib.util.spec_from_file_location(
        "prefix", Path("scripts/finish_development_prefix.py")
    )
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def parent(tmp_path, name, label):
    p = tmp_path / name
    p.mkdir()
    row = {
        "contribution_id": "c",
        "records": [{"record_id": "r", "verdict": label}],
        "questions": [],
        "human_validated": False,
        "eligible_as_gold": False,
    }
    (p / "automated_proposals.jsonl").write_text(json.dumps(row) + "\n")
    files = {"automated_proposals.jsonl": sha_file(p / "automated_proposals.jsonl")}
    (p / "results_manifest.json").write_text(json.dumps({"files": files, "hash": digest(files)}))
    return p


def test_identical_reused_record_is_one_proposal_not_multiple_votes(tmp_path):
    a = parent(tmp_path, "a", "unsafe")
    b = parent(tmp_path, "b", "unsafe")
    out = tmp_path / "out"
    controller().consolidate([a, b], out)
    s = json.loads((out / "summary.json").read_text())
    assert s["accepted_records"] == 1 and s["human_verified_labels"] == 0
    assert (
        json.loads((out / "automated_proposals.jsonl").read_text())["records"][0]["verdict"]
        == "unsafe"
    )


def test_contradictory_duplicate_is_not_resolved_by_preferred_label(tmp_path):
    a = parent(tmp_path, "a", "unsafe")
    b = parent(tmp_path, "b", "safe_for_use")
    with pytest.raises(LedgerError):
        controller().consolidate([a, b], tmp_path / "must-not-exist")
    assert not (tmp_path / "must-not-exist").exists()
