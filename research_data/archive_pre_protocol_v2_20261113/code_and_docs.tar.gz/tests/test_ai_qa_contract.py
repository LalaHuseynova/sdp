"""Explicit presence flag has the opposite polarity to a no-leak quality pass."""

import importlib.util
import json
from pathlib import Path

import pytest

from ams.research.dynamic.models import LedgerError, digest
from ams.research.pilot_finish.reviewer import request_job


def module():
    spec = importlib.util.spec_from_file_location(
        "qa_contract", Path("scripts/recheck_ai_questions.py")
    )
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def job(question):
    q = {
        "candidate_id": "newq",
        "question": question,
        "answers": ["Berlin"],
        "support_record_id": "r",
        "support_artifact_id": "a",
        "quote": "Alex lives in Berlin.",
    }
    v = {
        "task": "Read the note.",
        "intended_use": "A new descriptive question.",
        "context_id": "email",
        "artifacts": [{"artifact_id": "a", "role": "external", "text": "Alex lives in Berlin."}],
        "records": [],
        "questions": [q],
    }
    return request_job(
        v,
        {
            "contribution_id": "c",
            "use_id": "u",
            "packet_hash": "p",
            "record_versions": {},
            "candidate_versions": {"newq": digest(q)},
            "candidate_copies": {"newq": q},
        },
    )


@pytest.mark.parametrize(
    "question,presence,expected",
    [
        ("What city does Alex live in?", False, True),
        ("Does Alex live in Berlin?", True, False),
        ("Does Alex live in Berlin?", False, False),
        ("What city does Alex live in?", None, None),
    ],
)
def test_presence_normalization_and_literal_veto(question, presence, expected):
    raw = {
        "q0": {
            "supported_answer": True,
            "question_clear": True,
            "useful_for_task": True,
            "safe_descriptive_use": True,
            "answer_is_given_in_question": presence,
            "reason": "Invented test question about a stated city.",
        }
    }
    result = module().decode_questions(
        job(question), {"text": json.dumps(raw), "raw_finish_reason": "stop"}
    )
    assert result[0]["questions"][0]["no_answer_in_question"] is expected
    assert result[0]["answer_presence_checks"]["model_answer_presence"] is presence
    assert result[0]["human_validated"] is False and result[0]["eligible_as_gold"] is False


def test_old_ambiguous_flag_is_not_reinterpreted():
    raw = {
        "q0": {
            "supported_answer": True,
            "question_clear": True,
            "useful_for_task": True,
            "safe_descriptive_use": True,
            "no_answer_in_question": False,
            "reason": "Legacy test.",
        }
    }
    with pytest.raises(LedgerError):
        module().decode_questions(
            job("What city does Alex live in?"),
            {"text": json.dumps(raw), "raw_finish_reason": "stop"},
        )
