"""A formatting amendment preserves semantic decisions and protects unused test data."""

import json

import httpx
import pytest

from ams.research.ai_pilot import calibration as base
from ams.research.ai_pilot import calibration_v2 as revised
from ams.research.ai_pilot.quote_alignment import align
from ams.research.dynamic.models import LedgerError
from ams.research.pilot_finish.reviewer import StructuredSession
from test_llm_review import completion
from test_llm_review import plan as parent_plan  # noqa: F401
from test_question_calibration import offline, oracle  # noqa: F401


def raw(evidence):
    return {
        "status": "answerable",
        "answer": "North",
        "evidence": evidence,
        "reason": "Specific stated direction.",
    }


def test_nonobject_model_output_is_rejected():
    with pytest.raises(LedgerError):
        align("support", {"passage": "North", "question": "Which direction?"}, [])


def test_one_quote_pair_alignment_keeps_original_values_and_real_quotes():
    body = {"passage": "The direction is North.", "question": "What direction is stated?"}
    original = raw('"North"')
    clean, proof = align("support", body, original)
    assert original["evidence"] == '"North"' and clean["evidence"] == "North"
    assert {k: clean[k] for k in ["status", "answer", "reason"]} == {
        k: original[k] for k in ["status", "answer", "reason"]
    }
    assert (
        proof["raw_evidence"] == '"North"'
        and proof["method"] == "removed_one_outer_ascii_quote_pair"
    )
    assert (
        body["passage"][
            proof["exact_input_spans"][0]["start"] : proof["exact_input_spans"][0]["end"]
        ]
        == "North"
    )
    literal = {"passage": 'The tag is "North".', "question": "What tag is stated?"}
    kept, proof = align("support", literal, original)
    assert kept["evidence"] == '"North"' and proof["method"] == "exact"


@pytest.mark.parametrize(
    "bad", ['"north"', '""North""', '"South"', " North ", "“North”", '"North!"']
)
def test_alignment_never_repairs_case_words_whitespace_or_arbitrary_punctuation(bad):
    with pytest.raises(LedgerError):
        align(
            "support",
            {"passage": "The direction is North.", "question": "Which direction?"},
            raw(bad),
        )


@pytest.mark.parametrize("fail_validation", [False, True])
def test_development_reuse_and_locked_confirmation_cannot_be_retried(
    request, monkeypatch, fail_validation
):
    original, _, _, _ = request.getfixturevalue("parent_plan")
    repo = original.parent
    for relative in [
        "scripts/calibrate_question_checker.py",
        "scripts/validate_question_checker.py",
        "reports/QUESTION_CHECKER_CALIBRATION_20261101_PROTOCOL.md",
        "reports/QUESTION_CHECKER_CALIBRATION_20261101_QUOTE_AMENDMENT.md",
    ]:
        p = repo / relative
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("# fixture dependency\n")
    monkeypatch.setattr(base, "ENTRY_NANODOLLARS", 0)
    state = {"fail": False}
    seen = []

    def handler(request):
        payload = json.loads(request.content)
        body = json.loads(payload["messages"][1]["content"])
        seen.append(body)
        kind = "support" if "passage" in body else "leakage"
        reply = oracle(kind, body, state["fail"])
        if reply["evidence"]:
            reply["evidence"] = '"' + reply["evidence"] + '"'
        return completion(reply)

    transport = httpx.MockTransport(handler)

    def arm(self, plan, key):
        self.arm_annotation_mock(plan, transport)
        self.provider_preflight = {"mock": True}

    monkeypatch.setattr(StructuredSession, "arm_annotation", arm)
    monkeypatch.setenv("OPENROUTER_API_KEY", "offline-only")
    parent = repo / "strict_checker"
    base.prepare(repo, parent)
    failed = base.run(parent)
    assert (
        not failed["development_passed"]
        and failed["splits_run"] == ["development"]
        and len(seen) == 54
    )
    revised_plan = repo / "quote_checker"
    revised.prepare(repo, parent, revised_plan)
    assert len(seen) == 54
    dev = json.loads((revised_plan / "development_recheck.json").read_text())
    assert dev["result"]["passed"] and dev["new_API_calls"] == 0
    state["fail"] = fail_validation
    result = revised.run(revised_plan)
    assert result["certificate_issued"] is not fail_validation and len(seen) == 108
    assert (
        result["new_development_calls"]
        == result["human_verified_labels"]
        == result["questions_promoted"]
        == 0
    )
    assert revised.run(revised_plan) == result and len(seen) == 108
    with pytest.raises(LedgerError, match="already been used"):
        revised.prepare(repo, parent, repo / "forbidden_retune")
    assert not (repo / "forbidden_retune").exists()
