"""Original character offsets survive presentation differences; fresh data stays fresh."""

import json
import re

import httpx
import pytest

from ams.research.ai_pilot import calibration as base
from ams.research.ai_pilot import calibration_v2 as second
from ams.research.ai_pilot import confirmation as final
from ams.research.ai_pilot.whitespace_alignment import align
from ams.research.dynamic.models import LedgerError
from ams.research.pilot_finish.reviewer import StructuredSession
from test_llm_review import completion
from test_llm_review import plan as parent_plan  # noqa: F401
from test_question_calibration import offline, oracle  # noqa: F401


@pytest.mark.parametrize("space", ["\u00a0", "\u202f", "\u2009", "\t", "\n  "])
def test_whitespace_maps_to_original_unicode_character_spans(space):
    text = "α: the mass is 9.6" + space + "MB."
    raw = {
        "status": "answerable",
        "answer": "9.6 MB",
        "evidence": '"the mass is 9.6 MB."',
        "reason": "Literal amount.",
    }
    extracted, proof = align("support", {"passage": text, "question": "What mass?"}, raw)
    assert raw["evidence"] == '"the mass is 9.6 MB."'
    assert extracted["answer"] == raw["answer"] and extracted["status"] == raw["status"]
    assert extracted["evidence"] == "the mass is 9.6" + space + "MB."
    for span in proof["exact_input_spans"]:
        assert text[span["start"] : span["end"]] == span["quote"]
        assert span["start"] == 3


@pytest.mark.parametrize("evidence", ["9,6 MB", "9.7 MB", "9.6 Mb", "9.6 GB", "“9.6 MB”"])
def test_content_is_never_repaired(evidence):
    raw = {
        "status": "answerable",
        "answer": "9.6 MB",
        "evidence": evidence,
        "reason": "Unsupported quote.",
    }
    with pytest.raises(LedgerError):
        align("support", {"passage": "9.6\u2009MB", "question": "Which size?"}, raw)


@pytest.mark.parametrize("semantic_failure", [False, True])
def test_final_confirmation_is_new_and_cannot_be_recycled(request, monkeypatch, semantic_failure):
    original, _, _, _ = request.getfixturevalue("parent_plan")
    repo = original.parent
    for relative in [
        "scripts/calibrate_question_checker.py",
        "scripts/validate_question_checker.py",
        "scripts/confirm_question_checker.py",
        "reports/QUESTION_CHECKER_CALIBRATION_20261101_PROTOCOL.md",
        "reports/QUESTION_CHECKER_CALIBRATION_20261101_QUOTE_AMENDMENT.md",
        "reports/QUESTION_CHECKER_CALIBRATION_20261101_FRESH_CONFIRMATION.md",
    ]:
        p = repo / relative
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("# fixture dependency\n")
    monkeypatch.setattr(base, "ENTRY_NANODOLLARS", 0)
    state = {"replace_spaces": False, "semantic_failure": False}
    seen = []

    def handler(request):
        data = json.loads(request.content)
        body = json.loads(data["messages"][1]["content"])
        seen.append(body)
        kind = "support" if "passage" in body else "leakage"
        match = re.search(r"day immediately before (\w+)", body["question"])
        if kind == "leakage" and match:
            days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
            reply = {
                "status": "answer_given",
                "answer": days[(days.index(match.group(1)) - 1) % 7],
                "evidence": match.group(0),
                "reason": "Inverse day clue.",
            }
        else:
            reply = oracle(kind, body)
        if state["semantic_failure"] and kind == "support" and "not open" in body["passage"]:
            reply = {
                "status": "answerable",
                "answer": "open",
                "evidence": body["passage"],
                "reason": "Deliberately false fixture confirmation.",
            }
        if reply["evidence"]:
            if state["replace_spaces"]:
                reply["evidence"] = " ".join(reply["evidence"].split())
            reply["evidence"] = '"' + reply["evidence"] + '"'
        return completion(reply)

    transport = httpx.MockTransport(handler)

    def arm(self, plan, key):
        self.arm_annotation_mock(plan, transport)
        self.provider_preflight = {"mock": True}

    monkeypatch.setattr(StructuredSession, "arm_annotation", arm)
    monkeypatch.setenv("OPENROUTER_API_KEY", "offline-only")
    parent = repo / "strict"
    base.prepare(repo, parent)
    assert not base.run(parent)["development_passed"]
    decoder = repo / "quotes"
    second.prepare(repo, parent, decoder)
    state["replace_spaces"] = True
    assert not second.run(decoder)["validation_passed"]
    assert len(seen) == 108
    fresh = repo / "fresh"
    final.prepare(repo, parent, decoder, fresh)
    _, jobs, rows, _ = final.verify_plan(fresh)
    assert len(jobs) == 54 and len(rows) == 24 and len(seen) == 108
    state["semantic_failure"] = semantic_failure
    result = final.run(fresh)
    assert result["certificate_issued"] is not semantic_failure and len(seen) == 162
    assert (
        result["new_development_calls"]
        == result["questions_promoted"]
        == result["human_verified_labels"]
        == 0
    )
    if result["certificate_issued"]:
        cert = json.loads((fresh / "checker_certificate.json").read_text())
        assert not cert["MPBench_validated"] and not cert["defense_execution_enabled"]
    assert final.run(fresh) == result and len(seen) == 162
    with pytest.raises(LedgerError, match="already been consumed"):
        final.prepare(repo, parent, decoder, repo / "forbidden_repeat")
    assert not (repo / "forbidden_repeat").exists()
