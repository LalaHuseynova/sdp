"""Offline interruption/restart checks on invented data, not benchmark evaluation."""

from __future__ import annotations

import json
import socket
import sqlite3
import subprocess
import sys
from dataclasses import replace

import pytest

from ams.research.dynamic.models import LedgerError, canonical
from ams.research.retrieval.fixture import SESSION
from ams.research.sequential import RuntimeState, SequentialRun, Step
from ams.research.sequential.fixture import build_state, query, sequence, write_step
from ams.research.sequential.state import access_dump, graph_dump


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def deny(*args, **kwargs):
        raise AssertionError("Sequential validation forbids networking")

    for key in ("connect", "connect_ex"):
        monkeypatch.setattr(socket.socket, key, deny)
    monkeypatch.setattr(socket, "create_connection", deny)
    monkeypatch.setattr(socket, "getaddrinfo", deny)


class Crash(BaseException):
    pass


class CrashOnce:
    def __init__(self, stage, occurrence=1):
        self.stage, self.left = stage, occurrence

    def __call__(self, stage):
        if stage == self.stage:
            self.left -= 1
            if self.left == 0:
                raise Crash(stage)


def create(tmp_path, name="run", *, arm="S", classifier=False):
    state, fixture = build_state(tmp_path / f"{name}-evidence", arm, classifier=classifier)
    return SequentialRun.create(tmp_path / name, state), fixture


def test_full_state_round_trip_preserves_scores_counter_aliases_and_classifier(tmp_path):
    state, _ = build_state(tmp_path / "e", classifier=True)
    with SequentialRun.create(tmp_path / "run", state) as run:
        result = run.step(query("q", 1, answer=False, k=2))
        assert result["status"] == "completed"
        body = run.state.dump()
        restored = RuntimeState.load(body)
        assert restored.dump() == body
        assert restored.memory.client is restored.answer_client
        assert restored.memory.use_type.client is restored.memory.client
        assert restored.memory.prompts is restored.memory.use_type.prompts
        assert restored.memory.use_type._cache == run.state.memory.use_type._cache
        assert restored.memory.use_type._subjects == run.state.memory.use_type._subjects
        assert restored.memory._vectors[SESSION].scores((1.0, 0.0)) == run.state.memory._vectors[
            SESSION
        ].scores((1.0, 0.0))
        assert (
            restored.memory._graph(SESSION).new_source_id()
            == run.state.memory._graph(SESSION).new_source_id()
        )
        assert restored.memory._graph(SESSION).claim("c0").contested


@pytest.mark.parametrize("arm", list("RCMS"))
@pytest.mark.parametrize("cut", [0, 2, 3, 6, 8])
def test_checkpoint_tail_matches_uninterrupted_execution(tmp_path, arm, cut):
    whole, f = create(tmp_path, "whole", arm=arm, classifier=True)
    actions = sequence(whole.state, f)
    try:
        expected = [whole.step(action) for action in actions]
        expected_state = whole.state.dump()
    finally:
        whole.close()
    prefix, _ = create(tmp_path, "prefix", arm=arm, classifier=True)
    try:
        for action in actions[:cut]:
            prefix.step(action)
        prefix.checkpoint(tmp_path / "checkpoint")
        # A later source tail must never contaminate restoration from the older checkpoint.
        for action in actions[cut:]:
            prefix.step(action)
    finally:
        prefix.close()
    with SequentialRun.restore(tmp_path / "checkpoint", tmp_path / "restored") as run:
        assert run.cursor == cut
        for action in actions[cut:]:
            run.step(action)
        assert run.results() == expected
        assert run.state.dump() == expected_state
        assert run.state.usage() == expected[-1]["resources"]


@pytest.mark.parametrize(
    "stage,occurrence",
    [
        ("after_intent", 1),
        ("after_call", 1),
        ("after_call", 2),
        ("before_commit", 1),
        ("after_commit", 1),
    ],
)
def test_crash_recovery_uses_completed_call_prefix_once(tmp_path, stage, occurrence):
    reference, _ = create(tmp_path, "reference")
    action = query("q", 0, answer=False, k=2)
    try:
        expected = reference.step(action)
        state = reference.state.dump()
    finally:
        reference.close()
    run, _ = create(tmp_path, "crashed")
    run.fault = CrashOnce(stage, occurrence)
    with pytest.raises(Crash):
        run.step(action)
    run.close()
    with SequentialRun(tmp_path / "crashed") as resumed:
        actual = resumed.step(action)
        assert actual == expected and resumed.state.dump() == state
        assert resumed.db.execute("SELECT count(*) FROM calls").fetchone()[0] == 2
        assert resumed.state.usage()["inference"]["replay_attempts"] == 2
        assert resumed.step(action) == expected
        assert resumed.cursor == 1


def test_pending_checkpoint_restores_and_finishes_in_new_process(tmp_path):
    run, _ = create(tmp_path)
    run.fault = CrashOnce("after_call", 2)
    with pytest.raises(Crash):
        run.step(query("q", 1, answer=False, k=2))
    manifest = run.checkpoint(tmp_path / "cp")
    assert manifest["pending_steps"] == 1 and manifest["committed_cursor"] == 0
    assert run.resources()["committed"]["inference"]["replay_attempts"] == 0
    assert run.resources()["recorded_inference_including_pending"]["replay_attempts"] == 2
    run.close()
    code = """
import json,sys
from pathlib import Path
from ams.research.sequential import SequentialRun
from ams.research.recovery.offline import no_network
with no_network(), SequentialRun.restore(Path(sys.argv[1]),Path(sys.argv[2])) as run:
    result=run.recover()
    print(json.dumps({'status':result['status'],'cursor':run.cursor,'resources':run.state.usage()}))
"""
    result = subprocess.run(
        [sys.executable, "-c", code, str(tmp_path / "cp"), str(tmp_path / "new")],
        check=True,
        capture_output=True,
        text=True,
    )
    saved = json.loads(result.stdout)
    assert saved["status"] == "completed" and saved["cursor"] == 1
    assert saved["resources"]["inference"]["replay_attempts"] == 2


def test_response_text_finish_reason_and_200_token_request_are_saved(tmp_path):
    run, _ = create(tmp_path)
    try:
        result = run.step(query("q", 0))
        assert result["status"] == "completed" and result["value"]["truncated"]
        assert result["value"]["answer"]["text"] == "Artificial answer for c0."
        assert result["value"]["answer"]["raw_finish_reason"] == "length"
        calls = [json.loads(v[0]) for v in run.db.execute("SELECT record FROM calls ORDER BY seq")]
        answer = calls[-1]
        assert answer["request"]["max_tokens"] == 200
        assert answer["response"] == result["value"]["answer"]
        assert "- [BEGIN MEMORY" in answer["request"]["messages"][0]["content"]
        assert result["resources"]["inference"]["reported_input_tokens"] == 17
        assert result["resources"]["inference"]["reported_equivalent_cost_usd"] == "0.0000024"
        assert result["resources"]["inference"]["actual_paid_usd"] == "0"
    finally:
        run.close()


def test_delayed_evidence_order_and_equal_time_queries_are_causal(tmp_path):
    run, f = create(tmp_path)
    try:
        before = run.step(query("before", 5, answer=False))
        with pytest.raises(LedgerError, match="backdate"):
            run.step(Step.reveal("late-backdate", 4, f.audit("root-0", at=4)))
        run.step(Step.reveal("now", 5, f.audit("root-0", at=5)))
        after = run.step(query("after", 5, answer=False))
        b = before["value"]["retrieval"]["trace"]
        a = after["value"]["retrieval"]["trace"]
        assert b["selected_ids"] == ["c0"] and a["selected_ids"] != ["c0"]
        assert b["evidence_cursor"] < a["evidence_cursor"]
        assert run.results()[0] == before
        assert b["available_at"] == a["available_at"] == 5
    finally:
        run.close()


def test_failures_are_not_defense_success_and_resources_are_retained(tmp_path):
    run, _ = create(tmp_path)
    try:
        before = graph_dump(run.state.memory._graph(SESSION))
        # A two-claim answer was not cached; retrieval performs a conflict call first.
        failed = run.step(query("uncached-answer", 0, k=2, answer=True))
        assert (
            failed["status"] == "failed"
            and "Offline chat replay miss" in failed["error"]["message"]
        )
        assert failed["partial"]["retrieval"]["trace"]["contested_after"][0][1]
        assert graph_dump(run.state.memory._graph(SESSION)) == before
        assert failed["resources"]["inference"]["replay_attempts"] == 3
        assert failed["resources"]["inference"]["failed_replay_attempts"] == 1
        assert failed["resources"]["inference"]["unknown_usage_attempts"] == 1
        run.checkpoint(tmp_path / "failed-cp")
    finally:
        run.close()
    with SequentialRun.restore(tmp_path / "failed-cp", tmp_path / "resumed") as run:
        assert run.results()[0] == failed
        assert run.step(query("ok", 1))["status"] == "completed"
        assert run.state.usage()["inference"]["replay_attempts"] == 5


def test_audit_budget_failure_is_logged_without_losing_prior_containment(tmp_path):
    state, f = build_state(tmp_path / "e")
    state.evidence = replace(state.evidence, config=replace(state.evidence.config, audit_limit=1))
    with SequentialRun.create(tmp_path / "run", state) as run:
        first = run.step(Step.reveal("first", 1, f.audit("root-0", at=1)))
        second = run.step(Step.reveal("second", 2, f.audit("root-1", event="a2", at=2)))
        assert first["status"] == "completed" and second["status"] == "failed"
        assert run.state.evidence.usage.tickets == 1
        result = run.step(query("read", 2, answer=False))
        assert result["value"]["retrieval"]["trace"]["selected_ids"] != ["c0"]


def test_permission_versions_and_stale_context_cannot_override_runner_state(tmp_path):
    run, _ = create(tmp_path)
    try:
        access = replace(
            run.state.access,
            version="v2",
            grants=tuple(
                replace(g, readers=("R1",)) if g.artifact_id == "artifact-0" else g
                for g in run.state.access.grants
            ),
        )
        run.step(Step.make("revocation", 1, "policy", {"access": access_dump(access)}))
        result = run.step(query("q", 1, answer=False))
        assert result["value"]["retrieval"]["trace"]["selected_ids"] != ["c0"]
        assert result["value"]["retrieval"]["trace"]["policy_version"] == "v2"
        reused = run.step(Step.make("reuse", 2, "policy", {"access": access_dump(access)}))
        assert reused["status"] == "failed"
        body = query("injected", 2).payload
        with pytest.raises(LedgerError, match="Unexpected action"):
            Step.make("injected", 2, "query", {**body, "evidence": "older-snapshot"})
    finally:
        run.close()


def test_original_write_ids_vectors_and_links_match_after_restart(tmp_path):
    original, _ = create(tmp_path, "original")
    action = write_step(original.state, 5)
    try:
        original.step(query("prefix", 1, answer=False, k=2))
        prefix_state = original.state.dump()
        original.checkpoint(tmp_path / "cp")
        expected = original.step(action)
        assert expected["status"] == "completed"
        final = original.state.dump()
    finally:
        original.close()
    with SequentialRun.restore(tmp_path / "cp", tmp_path / "restart") as run:
        assert run.state.dump() == prefix_state
        assert run.step(action) == expected
        assert run.state.dump() == final
        graph = run.state.memory._graph(SESSION)
        assert graph.new_claim_id() == "c1003"
        assert run.state.evidence.roots["incoming-root"].contributor_id == "u1"


def test_denied_write_and_failed_binding_validation_do_not_mutate_graph(tmp_path):
    run, _ = create(tmp_path)
    action = write_step(run.state)
    try:
        before = graph_dump(run.state.memory._graph(SESSION))
        denied = run.step(Step.make("denied", 1, "write", {**action.payload, "writer": "outsider"}))
        assert (
            denied["status"] == "failed" and run.state.usage()["inference"]["replay_attempts"] == 0
        )
        invalid = action.payload
        invalid["bindings"]["records"] = invalid["bindings"]["records"][:-1]
        failed = run.step(Step.make("bad-bindings", 5, "write", invalid))
        assert failed["status"] == "failed"
        assert graph_dump(run.state.memory._graph(SESSION)) == before
        assert "incoming-root" not in run.state.evidence.roots
        assert run.state.usage()["inference"]["replay_attempts"] == 2
    finally:
        run.close()


def test_corrupt_or_truncated_checkpoint_and_journal_are_rejected(tmp_path):
    run, _ = create(tmp_path)
    run.step(query("q", 0))
    run.checkpoint(tmp_path / "cp")
    run.close()
    db = tmp_path / "cp/run.sqlite"
    db.write_bytes(db.read_bytes()[:-50])
    with pytest.raises(LedgerError, match="checksum"):
        SequentialRun.restore(tmp_path / "cp", tmp_path / "bad")
    connection = sqlite3.connect(tmp_path / "run/run.sqlite")
    connection.execute("UPDATE calls SET record='{}' WHERE seq=1")
    connection.commit()
    connection.close()
    with pytest.raises(LedgerError, match="Call hash"):
        SequentialRun(tmp_path / "run")


def test_idempotence_conflicting_ids_exclusive_writers_and_unlogged_mutation(tmp_path):
    run, _ = create(tmp_path)
    try:
        action = query("q", 0)
        output = run.step(action)
        assert run.step(action) == output and run.cursor == 1
        with pytest.raises(LedgerError, match="changed action"):
            run.step(query("q", 1))
        with pytest.raises(LedgerError, match="Another sequential writer"):
            SequentialRun(tmp_path / "run")
        run.state.memory._graph(SESSION).claim("c0").text = "unlogged mutation"
        with pytest.raises(LedgerError):
            run.step(query("next", 1))
    finally:
        run.close()


def test_future_gold_fields_and_pending_schedules_cannot_be_actions():
    for field in ("Y_case", "expected_memory", "future_audits", "scenario_profile"):
        with pytest.raises(LedgerError, match="Unexpected action"):
            Step.make("bad", 0, "query", {**query("base", 0).payload, field: "private"})
    with pytest.raises(LedgerError):
        Step.make("pending", 0, "audit_request_pending", {"verdict": None})


def test_checkpoint_and_restore_never_overwrite_prior_outputs(tmp_path):
    run, _ = create(tmp_path)
    try:
        run.checkpoint(tmp_path / "cp")
        with pytest.raises(LedgerError, match="destination exists"):
            run.checkpoint(tmp_path / "cp")
        with pytest.raises(LedgerError, match="Restore destination exists"):
            SequentialRun.restore(tmp_path / "cp", tmp_path / "run")
    finally:
        run.close()


def test_original_sentence_chunks_entity_indexes_and_next_edges_survive_write_restart(tmp_path):
    from ams.memory.index import VectorIndex

    text = "Artificial project has color blue. Its fixture owner is Cedar."
    state, _ = build_state(tmp_path / "e", incoming_text=text)
    state.memory.evidence_slots = 4
    entity_index = VectorIndex()
    entity_index.add([0], [(1.0, 0.0)])
    state.memory._entity_names[SESSION] = (["existing alias"], entity_index)
    action = write_step(state, at=1, incoming_text=text)
    with SequentialRun.create(tmp_path / "run", state) as run:
        result = run.step(action)
        assert result["status"] == "completed"
        graph = run.state.memory._graph(SESSION)
        assert graph._after and graph._prev
        assert len(run.state.memory._chunks[SESSION]) == 11
        run.checkpoint(tmp_path / "cp")
        expected = run.state.dump()
    with SequentialRun.restore(tmp_path / "cp", tmp_path / "restart") as run:
        assert run.state.dump() == expected
        assert run.state.memory._entity_names[SESSION][1].scores((1.0, 0.0)) == {0: 1.0}
        assert run.step(query("read", 2, answer=False))["status"] == "completed"


@pytest.mark.parametrize("field,value", [("code", {}), ("environment", {})])
def test_code_and_environment_drift_are_refused_before_models(tmp_path, field, value):
    run, _ = create(tmp_path)
    run.close()
    db = sqlite3.connect(tmp_path / "run/run.sqlite")
    db.execute("UPDATE metadata SET value=? WHERE key=?", (canonical(value), field))
    db.commit()
    db.close()
    with pytest.raises(LedgerError, match="changed"):
        SequentialRun(tmp_path / "run")


def test_prompt_drift_is_refused_without_modifying_original_prompts(tmp_path):
    import shutil

    from ams.core.prompts import PromptLibrary

    state, _ = build_state(tmp_path / "e")
    shutil.copytree(state.memory.prompts.root, tmp_path / "copied-prompts")
    state.memory.prompts = PromptLibrary(tmp_path / "copied-prompts")
    with SequentialRun.create(tmp_path / "run", state):
        pass
    prompt = tmp_path / "copied-prompts/answer_typed/v2.txt"
    prompt.write_text(prompt.read_text() + "\nchanged fixture only\n")
    with pytest.raises(LedgerError, match="Prompt files changed"):
        SequentialRun(tmp_path / "run")


def test_saved_response_overrides_a_later_cache_value():
    from dataclasses import asdict

    from ams.llm.types import ChatRequest, ChatResponse, Message, Usage
    from ams.research.sequential.clients import RecordedReplayClient

    req = ChatRequest((Message("user", "fixture request"),), "fixture")
    first = ChatResponse(
        "actual saved text",
        "fixture",
        "fixture",
        Usage(4, 2, 0.01),
        cached=True,
        raw_finish_reason="length",
    )
    client = RecordedReplayClient("fixture", {req.cache_key("fixture"): asdict(first)}, {})
    client.client_id = "0"
    assert client.complete(req) == first
    saved = client.history[0]
    client.chats[req.cache_key("fixture")] = asdict(replace(first, text="different cache winner"))
    client.resolver = lambda request, lookup: saved
    assert client.complete(req) == first


def test_malformed_cached_response_is_a_recorded_failure_not_free_work(tmp_path):
    state, _ = build_state(tmp_path / "e")
    client = state.memory.embed_client
    key = next(iter(client.embeddings))
    client.embeddings[key] = {**client.embeddings[key], "vectors": []}
    with SequentialRun.create(tmp_path / "run", state) as run:
        result = run.step(query("q", 0, answer=False))
        assert result["status"] == "failed"
        assert result["resources"]["inference"]["replay_attempts"] == 1
        assert result["resources"]["inference"]["failed_replay_attempts"] == 1
        calls = run.db.execute("SELECT record FROM calls").fetchall()
        assert json.loads(calls[0][0])["error"]["message"] == "Replay embedding shape mismatch"


def test_pending_request_divergence_is_refused_without_new_calls(tmp_path):
    from ams.llm.types import EmbedRequest
    from ams.research.dynamic.models import digest
    from ams.research.sequential.clients import ReplayDivergence

    run, _ = create(tmp_path)
    run.fault = CrashOnce("after_call")
    with pytest.raises(Crash):
        run.step(query("q", 0, answer=False))
    run.close()
    db = sqlite3.connect(tmp_path / "run/run.sqlite")
    row = db.execute("SELECT * FROM calls WHERE seq=1").fetchone()
    record = json.loads(row[3])
    record["request"]["texts"] = ["different saved request"]
    record["request_key"] = EmbedRequest(
        ("different saved request",), record["request"]["model"]
    ).cache_key("fixture")
    text = canonical(record)
    db.execute(
        "UPDATE calls SET record=?,hash=? WHERE seq=1",
        (text, digest([row[0], row[1], row[2], text, row[4]])),
    )
    db.commit()
    db.close()
    with SequentialRun(tmp_path / "run") as restored:
        with pytest.raises(ReplayDivergence):
            restored.recover()
        assert restored.cursor == 0
        assert restored.db.execute("SELECT count(*) FROM calls").fetchone()[0] == 1


def test_abrupt_process_exit_releases_writer_and_keeps_completed_calls(tmp_path):
    run, _ = create(tmp_path)
    run.close()
    code = """
import os,sys
from pathlib import Path
from ams.research.sequential import SequentialRun
from ams.research.sequential.fixture import query
from ams.research.recovery.offline import no_network
count=0
def fault(stage):
    global count
    if stage=='after_call':
        count+=1
        if count==2: os._exit(73)
with no_network(), SequentialRun(Path(sys.argv[1]),fault=fault) as run:
    run.step(query('q',1,answer=False,k=2))
"""
    process = subprocess.run(
        [sys.executable, "-c", code, str(tmp_path / "run")], capture_output=True, text=True
    )
    assert process.returncode == 73, process.stderr
    with SequentialRun(tmp_path / "run") as resumed:
        assert resumed.resources()["recorded_inference_including_pending"]["replay_attempts"] == 2
        assert resumed.recover()["status"] == "completed"
        assert resumed.state.usage()["inference"]["replay_attempts"] == 2
        assert resumed.state.memory._graph(SESSION).claim("c0").contested


def test_interrupted_miss_stays_one_failed_attempt_after_recovery(tmp_path):
    run, _ = create(tmp_path)
    action = Step.query(
        "miss", 0, session_id=SESSION, query="not in offline cache", use_id="fixture-use"
    )
    run.fault = CrashOnce("after_call")
    with pytest.raises(Crash):
        run.step(action)
    assert run.resources()["recorded_inference_including_pending"]["failed_replay_attempts"] == 1
    run.close()
    with SequentialRun(tmp_path / "run") as resumed:
        result = resumed.recover()
        assert result["status"] == "failed"
        assert result["resources"]["inference"]["replay_attempts"] == 1
        assert result["resources"]["inference"]["unknown_usage_attempts"] == 1
        assert resumed.step(action) == result and resumed.cursor == 1
