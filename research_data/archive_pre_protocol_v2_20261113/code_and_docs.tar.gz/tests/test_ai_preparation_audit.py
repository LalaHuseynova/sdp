"""The final mechanical audit rejects leakage and false human-validation flags."""

import importlib.util
import json

import pytest

from ams.research.dynamic.models import LedgerError, canonical, digest
from ams.research.recovery.offline import no_network, sha_file


def load_auditor():
    spec = importlib.util.spec_from_file_location(
        "audit_ai_preparation", "scripts/audit_ai_preparation.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.audit


def fixture(tmp_path, mutation=None):
    prepared, reviewed = tmp_path / "prepared", tmp_path / "reviewed"
    private = prepared / "private"
    private.mkdir(parents=True)
    reviewed.mkdir()
    text = "Alex lives in Berlin."
    record = {
        "record_id": "r",
        "record_kind": "claim",
        "text": text,
        "content_hash": digest(text),
        "recovery_status": "directly_recovered",
    }
    packet = {
        "contribution_id": "p",
        "records": [record],
        "artifacts": [{"artifact_id": "a", "role": "external", "text": text}],
    }
    files = {
        "review_packets.jsonl": canonical(packet) + "\n",
        "question_drafts.jsonl": "",
        "evaluator_case_index.jsonl": canonical(
            {
                "contribution_id": "p",
                "group_id": "g",
                "context_id": "email",
                "stratum": "suggestive_benign",
            }
        )
        + "\n",
        "group_selections.json": canonical(
            [{"bag_id": "D08" if mutation == "reserved" else "D00", "source_ids": ["p"]}]
        ),
    }
    for name, content in files.items():
        (private / name).write_text(content)
    row = {
        "record_id": "r",
        "content_hash": digest(text),
        "verdict": "safe_for_use",
        "origin": "external",
        "source_identity_authenticated": False,
        "source_spans": [
            {
                "artifact_id": "a",
                "start": 1 if mutation == "span" else 0,
                "end": len(text),
                "quote": text,
            }
        ],
        "evidence_quote": "",
    }
    proposal = {
        "contribution_id": "p",
        "annotation_source": "llm",
        "human_validated": mutation == "human",
        "eligible_as_gold": False,
        "can_update_live_trust": False,
        "records": [] if mutation == "missing" else [row],
        "questions": [],
    }
    (reviewed / "automated_proposals.jsonl").write_text(canonical(proposal) + "\n")
    (reviewed / "summary.json").write_text("{}")
    hashes = {
        name: sha_file(reviewed / name) for name in ["automated_proposals.jsonl", "summary.json"]
    }
    (reviewed / "results_manifest.json").write_text(
        canonical({"files": hashes, "hash": digest(hashes)})
    )
    return prepared, reviewed


@pytest.mark.parametrize("mutation", ["human", "reserved", "span"])
def test_false_validation_or_source_boundary_is_rejected(tmp_path, mutation):
    prepared, reviewed = fixture(tmp_path, mutation)
    with no_network(), pytest.raises(LedgerError):
        load_auditor()(prepared, [reviewed], tmp_path / "audit")
    assert not (tmp_path / "audit").exists()


def test_missing_reviews_remain_incomplete_without_invented_labels(tmp_path):
    prepared, reviewed = fixture(tmp_path, "missing")
    with no_network():
        result = load_auditor()(prepared, [reviewed], tmp_path / "audit")
    assert result["complete_AI_bundles"] == 0
    assert result["bundle_AI_labels"] == {"incomplete": 1}
    assert result["human_verified_labels"] == 0
    assert len(result["missing_record_reviews"]) == 1
    assert json.loads((tmp_path / "audit/coverage.json").read_text()) == result
