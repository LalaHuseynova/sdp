"""Invented sources and temporary caches. No human gold, model or network access."""

from __future__ import annotations

import copy
import json
import socket
import sqlite3
from dataclasses import asdict, replace

import pytest

from ams.core.prompts import PromptLibrary
from ams.core.spans import segment
from ams.llm.types import ChatRequest, ChatResponse, EmbedRequest, EmbedResponse, Message
from ams.memory.typed import TypedStandingMemory
from ams.research.dynamic import Policy
from ams.research.dynamic.models import LedgerError, digest
from ams.research.execution.session import new_json
from ams.research.native.cache import ConstructionCache
from ams.research.native.construction import ObservedMemory, validate_source
from ams.research.native.pipeline import (
    SCHEMA,
    build_bag,
    load_store,
    make_memory,
    verify,
    write_gzip,
)
from ams.research.phase1_data import source_parts
from ams.research.recovery.offline import (
    CHAT_MODEL,
    EMBED_MODEL,
    OfflineMiss,
    ReadOnlyCache,
    sha_file,
)
from ams.research.recovery.records import span_units, support_candidates
from ams.research.sequential.runner import environment, fingerprints
from ams.research.sequential.state import RuntimeState, graph_dump, index_dump


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def deny(*args, **kwargs):
        raise AssertionError("Native construction tests forbid networking")

    for key in ("connect", "connect_ex"):
        monkeypatch.setattr(socket.socket, key, deny)
    monkeypatch.setattr(socket, "create_connection", deny)
    monkeypatch.setattr(socket, "getaddrinfo", deny)


class FixtureClient:
    """Test author supplies explicit chat replies; artificial vectors have no scientific meaning."""

    def __init__(self, responses, provider):
        self.responses, self.provider, self.payloads = responses, provider, {}

    def complete(self, request):
        value = ChatResponse(
            self.responses[request.cache_key(self.provider)],
            CHAT_MODEL,
            self.provider,
            raw_finish_reason="stop",
        )
        self.payloads[request.cache_key(self.provider)] = ("chat", asdict(value))
        return value

    def embed(self, request):
        value = EmbedResponse(
            tuple((1.0, *([0.0] * 383)) for _ in request.texts), EMBED_MODEL, "local"
        )
        self.payloads[request.cache_key("local")] = ("embed", asdict(value))
        return value


@pytest.fixture
def example(tmp_path):
    pid, session = "p_invented", "old-fixture-store"
    uq = "Remember that I prefer tea."
    context = (
        "Alice says the planning color is blue.\n---\nA separate note says the deadline is Friday."
    )
    source = {
        "contribution_id": pid,
        "context_id": "email",
        "user_query": uq,
        "context": context,
        "artifacts": source_parts(pid, uq, context),
        "payload_hash": digest([uq, context]),
    }
    prompts = PromptLibrary()

    def extraction(ctx):
        return ChatRequest(
            (
                Message(
                    "user",
                    prompts.get("extract_typed_claims", "v1").render(
                        query=uq, context=ctx, max_claims=6
                    ),
                ),
            ),
            CHAT_MODEL,
            temperature=0.0,
            max_tokens=900,
        )

    texts = [s.text for s in segment(uq)]
    retention = ChatRequest(
        (
            Message(
                "user",
                prompts.get("retention_sentence", "v1").render(
                    sentences="\n".join(f"{i}. {t}" for i, t in enumerate(texts))
                ),
            ),
        ),
        CHAT_MODEL,
        temperature=0.0,
        max_tokens=60 + 40 * len(texts),
    )
    query = "What planning color was stated?"
    classifier = ChatRequest(
        (Message("user", prompts.get("classify_use_type", "v2").render(query=query)),),
        CHAT_MODEL,
        temperature=0.0,
        max_tokens=24,
    )
    chats = {
        retention.cache_key("openrouter"): json.dumps(
            {"sentences": [{"i": 0, "keep": True, "scope": "self", "kind": "preference"}]}
        ),
        extraction("").cache_key("openrouter"): json.dumps(
            {
                "claims": [
                    {
                        "text": "I prefer tea.",
                        "type": "preference",
                        "subject": "I",
                        "object": "tea",
                        "relation": "prefers",
                    }
                ]
            }
        ),
        extraction(context).cache_key("openrouter"): json.dumps(
            {
                "claims": [
                    {
                        "text": "The planning color is blue.",
                        "type": "description",
                        "subject": "planning",
                        "relation": "color",
                        "object": "blue",
                    },
                    {
                        "text": "The deadline is Friday.",
                        "type": "description",
                        "subject": "deadline",
                        "object": "Friday",
                        "relation": "day",
                    },
                ]
            }
        ),
        classifier.cache_key("openrouter"): "description | none",
    }
    chat, embed = FixtureClient(chats, "openrouter"), FixtureClient({}, "local")
    m = make_memory(chat, embed, prompts)
    # Remove the observer for the independent original-write reference.
    plain = TypedStandingMemory(
        **{k: getattr(m, k) for k in m.__dataclass_fields__ if not k.startswith("_")}
    )
    written = plain.write(session_id=session, user_query=uq, context=context).written
    graph = plain._graph(session)
    # Fixture has one input and unique source labels; production NEVER joins on labels.
    roots = list(graph._sources.values())[: len(source["artifacts"])]
    artifact_by_label = {r.artifact: a for r, a in zip(roots, source["artifacts"], strict=True)}
    expected_claims = [
        {
            "record_id": f"r_fixture_{i}",
            "text": e.metadata["raw_text"],
            "content_hash": digest(e.metadata["raw_text"]),
            "legacy_parent_artifact_id": artifact_by_label[
                graph.source(e.metadata["source_id"]).artifact
            ]["artifact_id"],
            "proposed_support_spans": support_candidates(
                e.metadata["raw_text"], source["artifacts"], None
            ),
        }
        for i, e in enumerate(written)
    ]
    expected_chunks = []
    for i, c in enumerate(plain._chunks[session]):
        artifact = artifact_by_label[c.label]
        expected_chunks.append(
            {
                "record_id": f"e_fixture_{i}",
                "text": c.text,
                "content_hash": digest(c.text),
                "source_artifact_id": artifact["artifact_id"],
                "source_spans": span_units(artifact),
            }
        )
    chat.complete(classifier)
    embed.embed(EmbedRequest((query,), EMBED_MODEL))
    path = tmp_path / "cache.sqlite"
    with sqlite3.connect(path) as db:
        db.execute(
            "CREATE TABLE responses(key TEXT PRIMARY KEY,provider TEXT,"
            "model TEXT,kind TEXT,payload TEXT)"
        )
        for client in (chat, embed):
            for key, (kind, payload) in client.payloads.items():
                # Exercise lean historical cache response formats.
                payload.pop("cached", None)
                db.execute(
                    "INSERT INTO responses VALUES (?,?,?,?,?)",
                    (key, client.provider, payload["model"], kind, json.dumps(payload)),
                )
    return {
        "source": source,
        "plain": plain,
        "written": written,
        "claims": expected_claims,
        "chunks": expected_chunks,
        "cache": path,
        "query": query,
        "prompts": prompts,
        "session": session,
    }


def build(example):
    e = example
    pid = e["source"]["contribution_id"]
    with_cache = ReadOnlyCache([e["cache"]])
    try:
        return build_bag(
            {"bag_id": "fixture", "bag_token": "opaque_fixture", "source_ids": [pid]},
            {pid: e["source"]},
            {pid: e["claims"]},
            {pid: e["chunks"]},
            {pid: [asdict(v) for v in e["written"]]},
            [e["query"]],
            with_cache,
            e["prompts"],
        )
    finally:
        with_cache.close()


def test_original_write_and_observer_have_identical_native_state(example):
    e = example
    cache = ReadOnlyCache([e["cache"]])
    try:
        memory = make_memory(
            ConstructionCache(cache, "openrouter"), ConstructionCache(cache, "local"), e["prompts"]
        )
        assert type(memory) is ObservedMemory
        memory.begin_contribution(e["session"], e["source"])
        result = memory.write(
            session_id=e["session"],
            user_query=e["source"]["user_query"],
            context=e["source"]["context"],
        )
        assert result.written == e["written"]
        assert graph_dump(memory._graph(e["session"])) == graph_dump(
            e["plain"]._graph(e["session"])
        )
        assert index_dump(memory._vectors[e["session"]]) == index_dump(
            e["plain"]._vectors[e["session"]]
        )
        assert memory._chunks == e["plain"]._chunks
    finally:
        cache.close()


def test_verified_native_bindings_restart_without_safety_votes(example):
    snapshot, crosswalk = build(example)
    state = RuntimeState.load(snapshot)
    assert len(state.bindings.records) == 6
    assert state.evidence.usage.tickets == 0
    assert all(event.kind == "register" for event in state.evidence.events)
    assert len([p for p in state.evidence.roots.values() if p.attribution == "principal"]) == 1
    assert len([p for p in state.evidence.roots.values() if p.attribution == "unknown"]) == 1
    assert not state.evidence.observations()
    assert all(p.contributor_id is None for p in state.evidence.roots.values())
    for binding in state.bindings.records:
        if binding.origin_class == "ambiguous":
            assert set(binding.artifact_ids) == {
                a["artifact_id"] for a in example["source"]["artifacts"]
            }
    assert crosswalk["prompt_envelope"]["actual_retrieval_executed"] is False
    assert state.usage()["inference"]["actual_paid_usd"] == "0"
    assert state.usage()["inference"]["replay_attempts"] == 0


def test_arm_copies_do_not_share_graphs_clients_or_classifier_cache(example):
    snapshot, _ = build(example)
    a, b = RuntimeState.load(snapshot), RuntimeState.load(snapshot)
    session = next(iter(a.memory._graphs))
    first = next(a.memory._graphs[session].claims())
    first.contested = True
    assert not b.memory._graphs[session].claim(first.claim_id).contested
    assert a.memory.client is not b.memory.client
    a.memory.use_type._subjects["fixture"] = "changed"
    assert "fixture" not in b.memory.use_type._subjects


@pytest.mark.parametrize("mutation", ["text", "standing", "parent", "chunk", "span", "missing"])
def test_mismatched_recovered_records_are_never_published(example, mutation):
    if mutation == "text":
        example["claims"][0]["text"] = "different"
    elif mutation == "standing":
        example["written"] = (
            replace(
                example["written"][0],
                metadata={**example["written"][0].metadata, "standing": "rule@global"},
            ),
            *example["written"][1:],
        )
    elif mutation == "parent":
        example["claims"][0]["legacy_parent_artifact_id"] = "wrong"
    elif mutation == "chunk":
        example["chunks"][0]["text"] = "different"
    elif mutation == "span":
        example["chunks"][0]["source_spans"][0]["start"] = 7
    else:
        example["claims"].pop()
    with pytest.raises(LedgerError):
        build(example)


def test_cache_miss_is_offline_failure_without_model_download(example):
    with sqlite3.connect(example["cache"]) as db:
        db.execute("DELETE FROM responses WHERE kind='chat'")
    with pytest.raises(OfflineMiss):
        build(example)


def test_unverified_source_annotations_cannot_enter_runtime_input(example):
    with pytest.raises(LedgerError, match="allowlisted"):
        validate_source({**example["source"], "Y_case": True})
    source = {**example["source"], "context": "altered"}
    with pytest.raises(LedgerError, match="bytes"):
        validate_source(source)


def test_bad_embedding_dimensions_are_refused(example):
    with sqlite3.connect(example["cache"]) as db:
        rows = db.execute("SELECT key,payload FROM responses WHERE kind='embed'").fetchall()
        for key, payload in rows:
            data = json.loads(payload)
            data["vectors"] = [[1.0] for _ in data["vectors"]]
            db.execute("UPDATE responses SET payload=? WHERE key=?", (json.dumps(data), key))
    with pytest.raises(LedgerError, match="dimensions"):
        build(example)


def test_duplicate_text_and_display_labels_do_not_merge_native_sources(example):
    e = example
    first = e["source"]
    second = {**first, "contribution_id": "p_distinct_independent_input"}
    second["artifacts"] = source_parts(
        second["contribution_id"], second["user_query"], second["context"]
    )
    rename = {
        a["artifact_id"]: b["artifact_id"]
        for a, b in zip(first["artifacts"], second["artifacts"], strict=True)
    }
    claims, chunks = copy.deepcopy(e["claims"]), copy.deepcopy(e["chunks"])
    for row in [*claims, *chunks]:
        row["record_id"] += "_copy"
        for key in ("legacy_parent_artifact_id", "source_artifact_id"):
            if key in row:
                row[key] = rename[row[key]]
        for span in row.get("proposed_support_spans", row.get("source_spans", [])):
            span["artifact_id"] = rename[span["artifact_id"]]
    p, q = first["contribution_id"], second["contribution_id"]
    cache = ReadOnlyCache([e["cache"]])
    try:
        snapshot, crosswalk = build_bag(
            {"bag_id": "fixture", "bag_token": "opaque_fixture", "source_ids": [p, q]},
            {p: first, q: second},
            {p: e["claims"], q: claims},
            {p: e["chunks"], q: chunks},
            {p: [asdict(v) for v in e["written"]], q: [asdict(v) for v in e["written"]]},
            [e["query"]],
            cache,
            e["prompts"],
        )
    finally:
        cache.close()
    assert len(snapshot["bindings"]["records"]) == 12
    assert len({s["artifact_id"] for s in snapshot["bindings"]["sources"]}) == 6
    assert len({r["native_id"] for r in crosswalk["record_links"]}) == 12
    assert len({r["record_id"] for r in crosswalk["record_links"]}) == 12


def test_classifier_catalog_miss_does_not_trigger_paid_preparation(example):
    req = ChatRequest(
        (
            Message(
                "user",
                example["prompts"].get("classify_use_type", "v2").render(query=example["query"]),
            ),
        ),
        CHAT_MODEL,
        temperature=0.0,
        max_tokens=24,
    )
    with sqlite3.connect(example["cache"]) as db:
        db.execute("DELETE FROM responses WHERE key=?", (req.cache_key("openrouter"),))
    with pytest.raises(LedgerError, match="catalog incomplete"):
        build(example)


def test_read_only_construction_never_changes_cache(example):
    before = sha_file(example["cache"])
    build(example)
    assert sha_file(example["cache"]) == before


def test_compressed_native_artifact_validation_and_independent_arm_loading(example, tmp_path):
    snapshot, _ = build(example)
    out = tmp_path / "bundle"
    token = "opaque_store"
    target = out / "private" / token
    target.mkdir(parents=True)
    path = target / "initial_state.json.gz"
    write_gzip(path, snapshot)
    with pytest.raises(FileExistsError):
        write_gzip(path, snapshot)
    new_json(
        target / "arms.json",
        {
            a: {
                "base_snapshot_sha256": sha_file(path),
                "policy": asdict(Policy(a)),
                "separate_graph_instance_required": True,
            }
            for a in "RCMS"
        },
    )
    body = {
        "schema": SCHEMA,
        "files": {str(p.relative_to(out)): sha_file(p) for p in target.iterdir()},
        "dependencies": {},
        "runtime_fingerprints": fingerprints(),
        "environment": environment(),
        "execution_enabled": False,
    }
    new_json(out / "native_manifest.json", {**body, "manifest_hash": digest(body)})
    assert verify(out)["status"] == "passed"
    a, b = load_store(out, token, "R"), load_store(out, token, "S")
    assert a.policy.arm == "R" and b.policy.arm == "S"
    session = next(iter(a.memory._graphs))
    assert a.memory._graphs[session] is not b.memory._graphs[session]
    with pytest.raises(LedgerError):
        load_store(out, "../elsewhere", "R")
    with pytest.raises(LedgerError):
        load_store(out, token, "invalid")
    path.write_bytes(path.read_bytes() + b"tampered")
    with pytest.raises(LedgerError, match="modified"):
        verify(out)
    with pytest.raises(LedgerError, match="changed"):
        load_store(out, token, "R")
