"""Boundary checks for the SDK 1.7.2 / OpenRouter function-call bridge."""

import copy
import json
import unittest

import httpx
from openai import OpenAI

from ams.llm.openrouter_legacy import install


class LegacyOpenRouterTests(unittest.TestCase):
    def setUp(self):
        install()
        self.requests = []

    def client(self, *, base_url="https://openrouter.ai/api/v1", multiple=False):
        def handle(request):
            payload = json.loads(request.content)
            self.requests.append(payload)
            calls = [
                {
                    "id": "server-call-1",
                    "type": "function",
                    "function": {"name": "python", "arguments": '{"cell":"answer=42"}'},
                }
            ]
            if multiple:
                calls.append({**calls[0], "id": "server-call-2"})
            finished = payload["messages"][-1]["role"] == "tool"
            message = {"role": "assistant", "content": "42" if finished else None}
            if not finished:
                message["tool_calls"] = calls
            return httpx.Response(
                200,
                json={
                    "id": "test-completion",
                    "object": "chat.completion",
                    "created": 1,
                    "model": "openai/gpt-4o-mini",
                    "choices": [
                        {
                            "index": 0,
                            "message": message,
                            "finish_reason": "stop" if finished else "tool_calls",
                        }
                    ],
                    "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
                },
            )

        return OpenAI(
            api_key="test-only",
            base_url=base_url,
            http_client=httpx.Client(transport=httpx.MockTransport(handle)),
        )

    def request(self):
        return {
            "model": "openai/gpt-4o-mini",
            "messages": [
                {"role": "system", "content": "Original agent instructions."},
                {
                    "role": "user",
                    "content": "[BEGIN MEMORY usable=description]\n10088\n[END MEMORY]",
                },
            ],
            "functions": [
                {
                    "name": "python",
                    "parameters": {
                        "type": "object",
                        "properties": {"cell": {"type": "string"}},
                    },
                }
            ],
            "function_call": {"name": "python"},
            "temperature": 0,
        }

    def test_schema_translation_preserves_prompts_and_arguments(self):
        request = self.request()
        before = copy.deepcopy(request)
        response = self.client().chat.completions.create(**request)
        wire = self.requests[0]
        self.assertNotIn("functions", wire)
        self.assertNotIn("function_call", wire)
        self.assertEqual(wire["messages"], before["messages"])
        self.assertEqual(wire["tools"][0]["function"], before["functions"][0])
        self.assertEqual(wire["tool_choice"], {"type": "function", "function": {"name": "python"}})
        self.assertFalse(wire["parallel_tool_calls"])
        self.assertEqual(request, before)
        self.assertEqual(response.choices[0].finish_reason, "function_call")
        self.assertEqual(response.choices[0].message.function_call.name, "python")
        self.assertEqual(
            response.choices[0].message.function_call.arguments, '{"cell":"answer=42"}'
        )

    def test_legacy_function_result_round_trip(self):
        client = self.client()
        request = self.request()
        first = client.chat.completions.create(**request)
        request["messages"].extend(
            [
                {
                    "role": "assistant",
                    "content": None,
                    "function_call": first.choices[0].message.function_call.model_dump(),
                },
                {"role": "function", "name": "python", "content": "42"},
            ]
        )
        final = client.chat.completions.create(**request)
        wire = self.requests[-1]["messages"]
        self.assertEqual(wire[-1]["role"], "tool")
        self.assertEqual(wire[-1]["tool_call_id"], wire[-2]["tool_calls"][0]["id"])
        self.assertEqual(wire[-1]["content"], "42")
        self.assertEqual(final.choices[0].message.content, "42")

    def test_other_hosts_are_unchanged(self):
        request = self.request()
        self.client(base_url="https://example.invalid/v1").chat.completions.create(**request)
        self.assertIn("functions", self.requests[0])
        self.assertNotIn("tools", self.requests[0])

    def test_install_is_idempotent(self):
        from openai.resources.chat.completions import Completions

        first = Completions.create
        install()
        self.assertIs(Completions.create, first)

    def test_multiple_calls_are_not_silently_dropped(self):
        with self.assertRaisesRegex(ValueError, "parallel calls"):
            self.client(multiple=True).chat.completions.create(**self.request())


if __name__ == "__main__":
    unittest.main()
