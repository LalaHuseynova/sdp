"""Adaptive-attack conditions and the content-lineage arm. Offline, mock clients only."""

from __future__ import annotations

import socket
from collections import Counter

import pytest

from ams.research.dynamic.models import canonical
from ams.research.retrieval import RetrievalContext
from ams.research.workload import adaptive as AD
from ams.research.workload import design as D
from ams.research.workload import lineage as LN
from ams.research.workload.generator import build
from ams.research.workload.integration import LayeredClient, build_states, group_rows, use_id
from ams.research.workload.mock import PromptAwareMock
from ams.research.workload.runner import prepare_state
from test_controlled_workload import sources


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def deny(*args, **kwargs):
        raise AssertionError("Adaptive tests forbid networking")

    for key in ("connect", "connect_ex"):
        monkeypatch.setattr(socket.socket, key, deny)
    monkeypatch.setattr(socket, "create_connection", deny)


@pytest.fixture(scope="module")
def world():
    rows, _ = build(sources(), dev_groups=1, test_groups=1)
    gid = sorted({r["group_id"] for r in rows["public/contributions.jsonl"]})[0]
    mock = PromptAwareMock()
    store = build_states(
        rows, gid, LayeredClient(None, "openrouter", mock), LayeredClient(None, "local", mock)
    )
    conditions = ("replica_localized", "replica_distributed", *AD.all_conditions(3))
    ext = AD.extend_store(rows, store, conditions)
    return rows, gid, group_rows(rows, gid), store, ext


def decisions(ext, condition, arm, cid_roles, group, gid):
    """{contribution role: Counter(decision reason)} over every candidate of one probe set."""
    state = prepare_state(ext["snapshots"][condition], ext["audits"][condition], arm)
    from ams.research.workload.stage2 import ConflictPlaceholderSession
    from ams.research.provisional_run.runner import resolve_models

    resolve_models(state, ConflictPlaceholderSession())
    owner = ext["record_owner"]
    out = {}
    q = group["probes"][0]["question"]
    ctx = RetrievalContext(state.evidence, state.access, use_id(gid, q), "user", "read")
    res = state.reader().retrieve_with_trace(
        session_id=ext["session_id"], query=q, context=ctx, k=4, principal="user"
    )
    for c in res.trace.candidates:
        rec = owner.get(c.native_id)
        if rec is None or rec["record_kind"] != "claim":
            continue
        role = cid_roles[rec["contribution_id"]]
        out.setdefault(role, Counter())[c.decision.reason] += 1
    return out


def test_replicas_reproduce_stored_conditions(world):
    _, _, _, store, ext = world
    for name in ("localized", "distributed"):
        rep = f"replica_{name}"
        assert canonical(ext["audits"][rep]) == canonical(store["audits"][name])
        assert canonical(ext["snapshots"][rep]["evidence"]) == canonical(
            store["snapshots"][name]["evidence"]
        )


def test_every_condition_validates_with_equal_budget(world):
    _, _, _, _, ext = world
    for condition in ext["unsafe_audited"]:
        for arm in ("R", "C", "M", "S"):
            state = prepare_state(ext["snapshots"][condition], ext["audits"][condition], arm)
            assert state.evidence.usage.tickets == D.AUDIT_TICKETS
        assert len(ext["unsafe_audited"][condition]) == 4


def test_overlays_match_their_definitions(world):
    _, gid, group, _, _ = world
    L = AD.layout(group)
    ov, _ = AD.overlay_and_tickets(group, gid, "shift_batch")
    for k in L["contexts"]:
        c = L["ctx"][k]
        assert all(ov[s] == (L["A"], k, c["a_other_batch"]) for s in c["scored"])
        assert all(ov[s] == (L["A"], k, c["seed_batch"]) for s in c["seeds"])
    ov, _ = AD.overlay_and_tickets(group, gid, "shift_context")
    kx, ky = L["contexts"]
    assert {ov[s][1] for s in L["seeds"]} == {kx} and {ov[s][1] for s in L["scored"]} == {ky}
    ov, _ = AD.overlay_and_tickets(group, gid, "sybil")
    assert len({ov[s][0] for s in L["scored"]}) == 1
    assert ov[L["scored"][0]][0] not in {L["A"], L["B"], L["U"]}
    for name, batches in (("framing_concentrated", 1), ("framing_spread", 2)):
        ov, _ = AD.overlay_and_tickets(group, gid, name)
        for k in L["contexts"]:
            seeds = L["ctx"][k]["seeds"]
            assert {ov[s][0] for s in seeds} == {L["B"]}
            assert len({ov[s][2] for s in seeds}) == batches


def test_random_detection_is_deterministic_two_per_context(world):
    _, gid, group, _, _ = world
    L = AD.layout(group)
    for cond in AD.random_conditions(3):
        a = AD.overlay_and_tickets(group, gid, cond)[1]
        assert a == AD.overlay_and_tickets(group, gid, cond)[1]
        unsafe = [c for _, c, v in a if v == "unsafe"]
        for k in L["contexts"]:
            items = set(L["ctx"][k]["seeds"] + L["ctx"][k]["scored"])
            assert len(items & set(unsafe)) == 2
        assert sum(v == "safe_for_use" for _, _, v in a) == 1


def test_policy_arithmetic_under_adaptive_placement(world):
    _, gid, group, _, ext = world
    roles = {c: p["role"] for c, p in group["private"].items()}
    # Audit-aware batch shift: S sees no evidence in the scored attacks' batch; C does.
    s = decisions(ext, "shift_batch", "S", roles, group, gid)
    c = decisions(ext, "shift_batch", "C", roles, group, gid)
    assert "source_risk_gate" not in s.get("attack_scored", {})
    assert set(c["attack_scored"]) == {"source_risk_gate"} or "authority_denied" in c[
        "attack_scored"
    ]
    # Sybil: no reputation arm has evidence on the second identity.
    for arm in ("C", "M", "S"):
        d = decisions(ext, "sybil", arm, roles, group, gid)
        assert "source_risk_gate" not in d.get("attack_scored", {})


def test_lineage_blocks_near_duplicates_only(world):
    _, gid, group, store, ext = world
    state = prepare_state(ext["snapshots"]["sybil"], ext["audits"]["sybil"], "S")
    blocked, info = LN.blocked_records(state, store["session_id"], 0.8)
    assert info["unsafe_roots"] == 4 and info["blocked"] >= info["source_claims"] > 0
    owner = store["record_owner"]
    by_key = {}
    for native, rec in owner.items():
        if rec["record_kind"] == "claim":
            b = state.bindings.record(store["session_id"], native)
            by_key[(b.record_id, b.content_hash)] = rec
    assert all(by_key[k]["kind"] == "external" for k in blocked)
    # tau above 1 blocks nothing; the wrapped policy then equals the base policy.
    none, _ = LN.blocked_records(state, store["session_id"], 1.01)
    assert none == frozenset()


def test_lineage_arm_keeps_base_decisions_elsewhere(world):
    _, gid, group, store, ext = world
    roles = {c: p["role"] for c, p in group["private"].items()}
    base = decisions(ext, "localized", "S", roles, group, gid)
    state = prepare_state(ext["snapshots"]["localized"], ext["audits"]["localized"], "S")
    from ams.research.workload.stage2 import ConflictPlaceholderSession
    from ams.research.provisional_run.runner import resolve_models

    resolve_models(state, ConflictPlaceholderSession())
    LN.apply(state, store["session_id"], 0.8)
    q = group["probes"][0]["question"]
    ctx = RetrievalContext(state.evidence, state.access, use_id(gid, q), "user", "read")
    res = state.reader().retrieve_with_trace(
        session_id=store["session_id"], query=q, context=ctx, k=4, principal="user"
    )
    lin = {}
    for c in res.trace.candidates:
        rec = store["record_owner"].get(c.native_id)
        if rec is None or rec["record_kind"] != "claim":
            continue
        lin.setdefault(roles[rec["contribution_id"]], Counter())[c.decision.reason] += 1
    assert lin["principal_control"] == base["principal_control"]
    for role in lin:
        moved = lin[role] - base[role]
        assert set(moved) <= {"content_lineage_unsafe"}


def test_followup_keeps_detections_and_budget(world):
    _, gid, group, _, _ = world
    L = AD.layout(group)
    for plain, fu in zip(AD.random_conditions(3), AD.followup_conditions(3)):
        a = AD.overlay_and_tickets(group, gid, plain)[1]
        b = AD.overlay_and_tickets(group, gid, fu)[1]
        assert a[:4] == b[:4] and len(b) == D.AUDIT_TICKETS  # same detections, same budget
        if b[4] != a[4]:  # a follow-up replaced the benign ticket
            ov = AD.overlay_and_tickets(group, gid, fu)[0]
            cid, verdict = b[4][1], b[4][2]
            assert ov[cid][0] == L["A"] and cid not in [t[1] for t in b[:4]]
            flagged = {ov[t[1]] for t in b[:4] if ov[t[1]][1] == ov[cid][1]}
            assert len({x[2] for x in flagged}) == 1 and ov[cid][2] not in {x[2] for x in flagged}
            role = group["private"][cid]["role"]
            assert verdict == ("unsafe" if role.startswith("attack") else "safe_for_use")


def test_evaluation_replay_serves_only_its_scope(tmp_path):
    import json
    import sqlite3

    from ams.llm.types import ChatRequest, Message
    from ams.research.dynamic.models import digest
    from ams.research.recovery.offline import CHAT_MODEL
    from ams.research.workload.replay import EvaluationReplaySession

    req = ChatRequest((Message("user", "q\nWhat you remember:\nx"),), CHAT_MODEL, 0.0, 200)
    key = req.cache_key("openrouter")
    db = tmp_path / "d.sqlite"
    with sqlite3.connect(db) as c:
        c.execute("CREATE TABLE dispatches(call_id,request_key,stage,request,status,"
                  "reservation,result,result_hash)")  # fmt: skip
        for scope, text in (("mine", "A"), ("other", "B")):
            body = {"response": {"text": text, "model": CHAT_MODEL}}
            c.execute("INSERT INTO dispatches VALUES (?,?,?,?,?,?,?,?)",
                      (digest([scope, "workload_answer", key]), key, "workload_answer", "",
                       "completed", None, json.dumps(body), "h"))  # fmt: skip

    class Fail:
        def dispatch(self, stage, request):
            raise AssertionError("must be replayed")

    s = EvaluationReplaySession(db, Fail(), "mine")
    assert s.dispatch("answer", req)[1]["response"]["text"] == "A"
